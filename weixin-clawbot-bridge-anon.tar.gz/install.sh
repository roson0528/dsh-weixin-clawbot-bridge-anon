#!/usr/bin/env bash
# =============================================================================
# DSH ↔ 微信 ClawBot 桥接插件 —— 一键安装脚本
#
# 用法：
#   ./install.sh                      # 安装到 ~/.dsh/profiles/web/ 并重启 DSH 服务（DSH_SERVICE，默认 dsh-web）
#   ./install.sh --no-restart         # 只复制文件，不重启
#   ./install.sh --with-nginx         # 安装并尝试自动配置 nginx /weixin-qr 静态路由（需 sudo）
#
# 说明：
#   - 不会覆盖已存在的 cordis.patch.yml（仅目标不存在时复制 .example）
#   - 重启/写 nginx 配置需要 sudo；无 sudo 时打印手动步骤
# =============================================================================
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROFILE_DIR="${DSH_PROFILE_DIR:-$HOME/.dsh/profiles/web}"
SERVICE="${DSH_SERVICE:-dsh-web}"
RESTART=true
WITH_NGINX=false
for arg in "$@"; do
  case "$arg" in
    --no-restart) RESTART=false ;;
    --with-nginx) WITH_NGINX=true ;;
    *) echo "未知参数: $arg"; exit 2 ;;
  esac
done

echo "==> 目标目录: $PROFILE_DIR"
mkdir -p "$PROFILE_DIR"

echo "==> 复制插件文件…"
cp -v "$DIR/weixin-bridge.mjs"      "$PROFILE_DIR/weixin-bridge.mjs"
cp -v "$DIR/weixin-bridge-lib.mjs"  "$PROFILE_DIR/weixin-bridge-lib.mjs"
cp -v "$DIR/ilink-client.mjs"       "$PROFILE_DIR/ilink-client.mjs"
if [ -f "$DIR/weixin-bridge-lib.test.mjs" ]; then
  cp -v "$DIR/weixin-bridge-lib.test.mjs" "$PROFILE_DIR/weixin-bridge-lib.test.mjs" 2>/dev/null || true
fi

if [ -f "$PROFILE_DIR/cordis.patch.yml" ]; then
  echo "==> 已存在 cordis.patch.yml，跳过（如需启用请手动加入 weixin-bridge 的 insert 段）"
else
  echo "==> 安装示例配置 cordis.patch.yml …"
  cp -v "$DIR/cordis.patch.yml.example" "$PROFILE_DIR/cordis.patch.yml"
fi

echo "==> 语法检查…"
node --check "$PROFILE_DIR/weixin-bridge.mjs"
node --check "$PROFILE_DIR/weixin-bridge-lib.mjs"
node --check "$PROFILE_DIR/ilink-client.mjs"
echo "    OK"

if [ "$WITH_NGINX" = true ]; then
  echo "==> 尝试配置 nginx /weixin-qr 静态路由（可选）…"
  QR_DIR="${DSH_QR_DIR:-/var/www/dsh-qr}"
  CONF=/etc/nginx/conf.d/dsh-weixin-qr.conf
  SUDO=""
  if sudo -n true 2>/dev/null; then SUDO=sudo; fi
  if [ -n "$SUDO" ]; then
    sudo mkdir -p "$QR_DIR" 2>/dev/null || true
    cat <<EOF | sudo tee "$CONF" >/dev/null
# DSH 微信桥接插件：登录二维码静态发布（由 install.sh --with-nginx 生成）
location = /weixin-qr {
    alias $QR_DIR/qr.png;
    add_header Cache-Control "no-store";
}
EOF
    echo "    已写入 $CONF（请确认其被 server {} 块 include，然后 nginx -s reload）"
    echo "    reload: sudo nginx -t && sudo nginx -s reload"
  else
    echo "    ⚠ 无 sudo 权限，跳过 nginx 配置。手动步骤："
    echo "      1. mkdir -p $QR_DIR && chown \$(whoami) $QR_DIR"
    echo "      2. nginx server 块加入:"
    echo "         location = /weixin-qr { alias $QR_DIR/qr.png; add_header Cache-Control \"no-store\"; }"
    echo "      3. sudo nginx -s reload"
  fi
fi

if [ "$RESTART" = true ]; then
  echo "==> 重启 DSH 服务（$SERVICE）…"
  if sudo systemctl restart "$SERVICE" 2>/dev/null; then
    echo "    已重启"
  else
    echo "    ⚠ sudo 不可用或服务名不同，请手动执行:"
    echo "      sudo systemctl restart "$SERVICE""
  fi
fi

echo
echo "==> 安装完成。首次使用："
echo "    1. 扫码：局域网访问 http://<服务器IP>:23600/weixin-qr （需 nginx，见 --with-nginx）"
echo "    2. 扫码后先给 Bot 发一条消息，之后通知才能主动送达"
echo "    3. 配置例行交代内容：打开 http://127.0.0.1:19998/ （SSH 隧道: ssh -L 19998:127.0.0.1:19998 user@server）"
echo "    4. 日志: ~/.dsh/weixin/bridge.log"
