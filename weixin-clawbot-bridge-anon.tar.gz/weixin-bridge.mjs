/**
 * DSH ↔ 微信 ClawBot 桥接插件
 *
 * 功能：
 *  1. 任务失败自动恢复：turn/end reason='error' 自动补发「继续」；按错误类型分级
 *     （任何类型失败均指数退避自动重试，最多 maxAutoRetries 次）；连续失败超阈值停止并告警。
 *  2. 交互转发：user-questions/request 瀑布上的应答器（注册在 userQuestions 服务 ctx，
 *     prepend 抢在网页端转发器之前接管）。默认只接管微信发起的任务，网页任务不受影响。
 *  3. 微信发指令：新任务 / 续聊 / 状态 / 任务列表 / 停止 / 跳过 / 重载 等。
 *  4. 指定任务操作：「在「任务名」中执行：指令」或「在 2 号任务中执行：指令」，
 *     agent 已结束则自动恢复会话。
 *  5. 任务完成通知 + 完成报告（长文本自动分段）。
 *
 * 出站长轮询（getupdates），不需要公网入站端口或域名。
 */

import fs from 'node:fs'
import path from 'node:path'
import http from 'node:http'
import { createRequire } from 'node:module'
import { execFile, spawn } from 'node:child_process'
import { promisify } from 'node:util'
import { randomUUID } from 'node:crypto'
import { StringDecoder } from 'node:string_decoder'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { brandString } from '@deepseek-ai/dsh-brand'
import { ILinkClient, ILinkError, sleep } from './ilink-client.mjs'
import {
  splitText, renderQuestion, parseAnswer, looksLikeOptionReply,
  renderQuestionStep, parseQuestionAnswer, looksLikeStepReply, decideTextRoute,
  classifyError, backoffDelay, parseCommand, humanAge, withBriefing, sessionNumberTag,
  renderApproval, parseApprovalReply,
} from './weixin-bridge-lib.mjs'

const require_ = createRequire(import.meta.url)
const execFileP = promisify(execFile)
let qrcodeTerminal = null
try { qrcodeTerminal = require_('qrcode-terminal') } catch { /* 可选依赖 */ }
let qrcodeLib = null
try { qrcodeLib = require_('qrcode') } catch { /* 可选依赖 */ }

export const name = 'weixin-bridge'
export const inject = [
  'agents',
  'llm',
  'workspaceRegistry',
  'sessionTitle',
  'agentDefaultModel',
  'agentPresets',
  'permissionPresets',
]

const DEFAULTS = {
  continueText: '继续',
  maxAutoRetries: 3,
  retryDelayMs: 8000,
  retryBackoffMaxMs: 120_000,
  askTimeoutMs: 900_000,
  resumeTtlMs: 900_000,          // 「续聊最近会话」有效期（15 分钟）；超时后普通指令只提示、不再静默新建任务
  workspacePath: '',
  agentPreset: 'standard',
  permissionPreset: 'workspace-write',
  notifyOnRecovery: true,
  alwaysSendReport: true,          // true = 任务完成后即使报告与过程回推相同也再发一次完整报告
  pushProgress: false,             // false = 不推送中间过程消息（只发交互/异常/失败/完成报告），true = 逐条回推 assistant 输出
  stateDir: '',
  sessionsDir: '',               // 会话目录（默认自动推导）
  webQrDir: '/var/www/dsh-qr',
  enableFailureTest: false,
  interceptAllSessions: false,   // true = 也接管网页任务的问题（默认只接管微信任务）
  maxLogBytes: 1_000_000,        // 单日志文件上限，超出轮转
  maxLogFiles: 3,
  maxReportBytes: 200_000,       // 单会话累积报告上限
  indexRefreshMs: 60_000,        // 会话标题索引最短刷新间隔
  taskListLimit: 15,             // 「任务」列表最多显示条数
  statusPort: 19998,             // 状态/配置端点端口（0 = 关闭）
  statusHost: '127.0.0.1',       // 状态/配置端点监听地址（局域网访问设 0.0.0.0）
  configToken: '',               // 配置/状态端点访问令牌（空 = 免鉴权；局域网访问强烈建议设置）
  configReloadMs: 30_000,        // config.json 自动重载检查间隔
  sessionBriefing: '',           // 每次新建会话自动向 Agent 交代的例行内容（多行文本，如服务器密码、存储路径）
  briefingOnResume: true,        // 恢复已有会话时是否也注入例行内容
}

export function apply(ctx, config = {}) {
  const cfg = { ...DEFAULTS, ...config }
  const startedAt = Date.now()
  const stateDir = cfg.stateDir
    || path.join(process.env.DSH_HOME || path.join(process.env.HOME || '/root', '.dsh'), 'weixin')
  const workspacePath = cfg.workspacePath || process.cwd()
  const configFile = path.join(stateDir, 'config.json')
  const asksFile = path.join(stateDir, 'asks.json')
  const statusFile = path.join(stateDir, 'status.json')

  // ── 日志（文件 + stderr，按大小轮转）───────────────────
  const logFile = path.join(stateDir, 'bridge.log')
  let logWrites = 0
  let logSizeChecked = 0
  const rotateLogIfNeeded = () => {
    try {
      const size = fs.statSync(logFile).size
      logSizeChecked = size
      if (size <= cfg.maxLogBytes) return
      const keep = Math.max(1, cfg.maxLogFiles - 1)
      for (let i = keep - 1; i >= 1; i--) {
        const from = `${logFile}.${i}`
        const to = `${logFile}.${i + 1}`
        try { if (fs.existsSync(from)) fs.renameSync(from, to) } catch { /* 尽力 */ }
      }
      fs.renameSync(logFile, `${logFile}.1`)
    } catch { /* 文件不存在等，忽略 */ }
  }
  const writeLog = (level, msg) => {
    const line = `${new Date().toISOString()} [${level}] ${msg}\n`
    try {
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      if (logWrites++ % 100 === 0 || logSizeChecked + line.length > cfg.maxLogBytes) rotateLogIfNeeded()
      logSizeChecked += Buffer.byteLength(line)
      fs.appendFileSync(logFile, line, { mode: 0o600 })
    } catch { /* 尽力 */ }
    try { process.stderr.write(`[weixin] ${msg}\n`) } catch { /* 尽力 */ }
  }
  const logger = {
    info: m => writeLog('INFO', m),
    warn: m => writeLog('WARN', m),
    error: m => writeLog('ERROR', m),
  }

  // ── 配置热重载（stateDir/config.json 覆盖 cordis 配置）──
  let lastConfigMtime = 0
  function reloadConfig({ manual = false } = {}) {
    try {
      if (!fs.existsSync(configFile)) {
        return manual ? { ok: true, note: '未找到 config.json，沿用当前配置' } : { ok: true }
      }
      const st = fs.statSync(configFile)
      lastConfigMtime = st.mtimeMs
      const data = JSON.parse(fs.readFileSync(configFile, 'utf8'))
      const applied = []
      for (const [k, v] of Object.entries(data)) {
        if (k in DEFAULTS) { cfg[k] = v; applied.push(k) }
      }
      if (applied.length > 0) logger.info(`配置已重载: ${applied.join(', ')}`)
      return { ok: true, note: `已重载 ${applied.length} 项配置` }
    } catch (e) {
      logger.warn(`配置重载失败: ${e.message}`)
      return { ok: false, note: `配置重载失败：${e.message}` }
    }
  }
  // 启动时立即读一次 config.json，让 statusHost/statusPort/configToken 等也能在重启后生效
  reloadConfig()

  // ── 运行状态 ──────────────────────────────────────────
  /** agentId -> { failures, timer, failTest, stoppedByUser, lastError } */
  const agentState = new Map()
  /** qid -> { resolve, next, request, timer, userId, sessionId, createdAt } */
  const pendingAsks = new Map()
  /** qid -> { resolve, userId, sessionId, timer, toolName }：等待微信答复的审批请求 */
  const pendingApprovals = new Map()
  /** sessionId -> { userId, failingModel? } ；另有 'last:<userId>' -> { sessionId, at } */
  const weixinSessions = new Map()
  /** agentId -> AgentHandle */
  const handles = new Map()
  /** sessionId -> 最后已通知的 turn */
  const notifiedTurns = new Map()
  /** sessionId -> { turn, parts[], bytes } */
  const turnReports = new Map()
  /** 任务运行轨迹（开始时间 / 轮次 / 过程消息），供「04#状态」使用 */
  const taskTrace = new Map()
  /** sessionId -> 最后回推的文本（用于完成报告去重） */
  const lastPushed = new Map()
  /** userId -> Map<序号, sessionId>（「任务」列表快照） */
  const taskListByUser = new Map()
  /** sessionId -> { title, firstUser, size, mtimeMs } 会话标题索引 */
  const sessionIndex = new Map()
  /** sessionId -> 稳定编号（数字，1 起，跨任务递增） */
  const sessionNumbers = new Map()
  const sessionNumbersFile = path.join(stateDir, 'session_numbers.json')
  let nextSessionNumber = 1
  let lastIndexBuiltAt = 0
  let indexBuilding = null
  let sessionsRootCache = ''
  const diskTitleCache = new Map()
  const HEAD_LIMIT_BYTES = 2 * 1024 * 1024
  // 会话元数据缓存（标题/工作目录）：按 size+mtime 判断是否过期，重命名后会重新解析
  const metaCache = new Map()
  const metaCacheFile = path.join(stateDir, 'session_meta.json')
  function loadMetaCache() {
    try {
      const raw = JSON.parse(fs.readFileSync(metaCacheFile, 'utf8'))
      for (const [k, v] of Object.entries(raw ?? {})) {
        if (v && typeof v === 'object') {
          metaCache.set(k, {
            size: Number(v.size) || 0,
            mtime: Number(v.mtime) || 0,
            title: String(v.title ?? ''),
            cwd: String(v.cwd ?? ''),
          })
        }
      }
      if (metaCache.size > 0) logger.info(`会话元数据缓存已载入 ${metaCache.size} 条`)
    } catch { /* 首次无缓存 */ }
  }
  function persistMetaCache() {
    try {
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      fs.writeFileSync(metaCacheFile, JSON.stringify(Object.fromEntries(metaCache)), { mode: 0o600 })
    } catch (e) { logger.warn(`会话元数据缓存写入失败: ${e.message}`) }
  }
  /** 标题占位符：不写入磁盘标题缓存，避免一次失败被永久缓存 */
  const TITLE_PLACEHOLDERS = new Set(['（未命名会话）', '（空会话）', '（会话文件已删除）'])
  /** 单独开启过程跟踪的会话（即使全局 pushProgress=false 也推送中间过程） */
  const trackedSessions = new Set()
  let lastError = ''
  let seq = 0
  let restoreNoticePending = false

  // ── 会话稳定编号（01#、02#…，持久化，跨任务递增）──
  // ── 「上次上文」持久化（重启后仍能判断超时，避免静默新建任务）──
  const lastRoutesFile = path.join(stateDir, 'last_routes.json')
  let lastRoutesSavedAt = 0
  let lastRoutesDirty = false
  function loadLastRoutes() {
    try {
      if (!fs.existsSync(lastRoutesFile)) return
      const data = JSON.parse(fs.readFileSync(lastRoutesFile, 'utf8'))
      let n = 0
      for (const [uid, rec] of Object.entries(data?.users ?? {})) {
        const sid = String(rec?.sessionId ?? '')
        const at = Number(rec?.at ?? 0)
        if (sid === '' || !Number.isFinite(at) || at <= 0) continue
        weixinSessions.set(`last:${uid}`, { sessionId: sid, at })
        n += 1
      }
      if (n > 0) logger.info(`已载入上次上文记录: ${n} 条`)
    } catch (e) { logger.warn(`上次上文读取失败: ${e.message}`) }
  }
  function persistLastRoutes({ force = false } = {}) {
    const now = Date.now()
    if (!force && now - lastRoutesSavedAt < 5_000) return
    lastRoutesSavedAt = now
    try {
      const users = {}
      for (const [k, v] of weixinSessions) {
        if (!k.startsWith('last:')) continue
        if (!v?.sessionId) continue
        users[k.slice(5)] = { sessionId: v.sessionId, at: Number(v.at ?? 0) }
      }
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      fs.writeFileSync(lastRoutesFile, JSON.stringify({ users }, null, 2), { mode: 0o600 })
    } catch (e) { logger.warn(`上次上文写入失败: ${e.message}`) }
  }

  function loadSessionNumbers() {
    try {
      if (!fs.existsSync(sessionNumbersFile)) return
      const data = JSON.parse(fs.readFileSync(sessionNumbersFile, 'utf8'))
      const map = data?.sessions ?? {}
      let max = 0
      for (const [sid, n] of Object.entries(map)) {
        const num = Number(n)
        if (Number.isInteger(num) && num > 0) {
          sessionNumbers.set(sid, num)
          if (num > max) max = num
        }
      }
      nextSessionNumber = max + 1
    } catch (e) { logger.warn(`编号文件读取失败: ${e.message}`) }
  }
  const trackedFile = path.join(stateDir, 'tracked_sessions.json')
  function loadTracked() {
    try {
      if (!fs.existsSync(trackedFile)) return
      const data = JSON.parse(fs.readFileSync(trackedFile, 'utf8'))
      for (const sid of Array.isArray(data?.sessions) ? data.sessions : []) {
        if (typeof sid === 'string' && sid !== '') trackedSessions.add(sid)
      }
      if (trackedSessions.size > 0) logger.info(`已恢复过程跟踪: ${trackedSessions.size} 个任务`)
    } catch (e) { logger.warn(`跟踪文件读取失败: ${e.message}`) }
  }
  function persistTracked() {
    try {
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      fs.writeFileSync(trackedFile, JSON.stringify({ sessions: [...trackedSessions] }, null, 2), { mode: 0o600 })
    } catch (e) { logger.warn(`跟踪文件写入失败: ${e.message}`) }
  }
  function saveSessionNumbers() {
    try {
      const sessions = {}
      for (const [sid, n] of sessionNumbers) sessions[sid] = n
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      fs.writeFileSync(sessionNumbersFile, JSON.stringify({ sessions }, null, 2), { mode: 0o600 })
    } catch (e) { logger.warn(`编号文件写入失败: ${e.message}`) }
  }
  function assignSessionNumber(sessionId) {
    const sid = String(sessionId ?? '')
    if (!sid) return undefined
    const existing = sessionNumbers.get(sid)
    if (existing) return existing
    const n = nextSessionNumber++
    sessionNumbers.set(sid, n)
    saveSessionNumbers()
    return n
  }
  function sessionNumberTagOf(sessionId) {
    return sessionNumberTag(sessionNumbers.get(String(sessionId ?? '')))
  }
  function findSessionByNumber(number) {
    const n = Number(number)
    if (!Number.isInteger(n) || n <= 0) return undefined
    for (const [sid, num] of sessionNumbers) {
      if (num === n) return sid
    }
    return undefined
  }
  loadSessionNumbers()
  loadTracked()
  loadMetaCache()
  loadLastRoutes()

  const CAPS = { notifiedTurns: 200, lastPushed: 200, weixinSessions: 400, turnReports: 100, taskTrace: 200, traceMsgs: 300 }
  function setCapped(map, key, value, max) {
    map.set(key, value)
    while (map.size > max) {
      const first = map.keys().next().value
      if (first === undefined) break
      map.delete(first)
    }
  }

  const client = new ILinkClient({
    stateDir,
    logger,
    onQRCode: ({ url }) => {
      logger.info(`请用微信扫码登录: ${url}`)
      if (qrcodeTerminal) {
        qrcodeTerminal.generate(url, { small: true }, art => logger.info(`微信扫一扫下方二维码：\n${art}`))
      }
      try {
        fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
        fs.writeFileSync(path.join(stateDir, 'last-qr-url.txt'), url, { mode: 0o600 })
        if (qrcodeLib) {
          qrcodeLib.toFile(path.join(stateDir, 'qr.png'), url, { width: 640, margin: 2 }, err => {
            if (err) logger.warn(`二维码 PNG 写入失败: ${err.message}`)
          })
          const webDir = cfg.webQrDir || '/var/www/dsh-qr'
          qrcodeLib.toFile(path.join(webDir, 'qr.png'), url, { width: 640, margin: 2 }, err => {
            if (err) logger.warn(`发布目录二维码写入失败 (${webDir}): ${err.message}`)
          })
        }
      } catch { /* 尽力 */ }
    },
  })

  // ── 通知积压队列：dsh 重启后 iLink 主动推送上下文可能短暂失效，
  //    失败的消息落盘，等链路恢复（用户重新发消息/重登）后自动补发。──
  const outboxFile = path.join(stateDir, 'outbox.json')
  let outbox = []
  let outboxBlockedUntil = 0
  const sleep = ms => new Promise(r => { const t = setTimeout(r, ms); t.unref?.() })
  function persistOutbox() {
    try {
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      fs.writeFileSync(outboxFile, JSON.stringify(outbox), { mode: 0o600 })
    } catch { /* 忽略 */ }
  }
  function loadOutbox() {
    try {
      if (fs.existsSync(outboxFile)) {
        const arr = JSON.parse(fs.readFileSync(outboxFile, 'utf8'))
        if (Array.isArray(arr)) outbox = arr.slice(0, 100)
      }
    } catch { /* 忽略 */ }
  }
  function enqueueOutbox(text, userId = '') {
    if (outbox.length >= 100) outbox.shift()
    outbox.push({ text: String(text ?? ''), userId: String(userId ?? ''), at: Date.now() })
    persistOutbox()
  }
  async function flushOutbox() {
    if (Date.now() < outboxBlockedUntil) return
    if (outbox.length === 0) return
    if (!client.loggedIn || client.knownUsers().length === 0) return
    const pending = outbox.splice(0, outbox.length)
    persistOutbox()
    let failed = 0
    for (const m of pending) {
      try {
        const n = m.userId ? await client.sendText(m.text, { userId: m.userId }) : await client.sendText(m.text)
        if (n > 0) {
          logger.info(`补发积压通知成功: ${String(m.text).slice(0, 40)}`)
        } else {
          failed++
          if (outbox.length < 100) outbox.push(m)
        }
      } catch (e) {
        failed++
        if (outbox.length < 100) outbox.push(m)
        logger.warn(`补发积压通知失败，稍后重试: ${e.message}`)
      }
      await sleep(700)
    }
    persistOutbox()
    // 连续失败时退避 30 秒，避免与 iLink 限流互相冲击
    if (failed > 0) outboxBlockedUntil = Date.now() + 30_000
  }
  loadOutbox()

  /** 统一发送入口：失败按短退避重试，仍失败则进入积压队列 */
  async function pushText(text, opts = {}) {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const n = opts.userId ? await client.sendText(text, opts) : await client.sendText(text)
        if (n > 0) return n
        // n === 0：单用户发送被拒（多为 iLink ret=-2 prepare failed 限流）
        if (attempt < 2) {
          logger.warn(`发送未成功（第 ${attempt + 1} 次），${1000 * (attempt + 1)}ms 后重试`)
          await sleep(1000 * (attempt + 1))
          continue
        }
        logger.warn('发送多次未成功，进入积压队列（链路恢复后自动补发）')
        enqueueOutbox(text, opts.userId ?? '')
        return 0
      } catch (e) {
        logger.warn(`发送异常，进入积压队列: ${e.message}`)
        enqueueOutbox(text, opts.userId ?? '')
        return 0
      }
    }
    return 0
  }

  async function notify(text) {
    if (!client.loggedIn) { enqueueOutbox(text, ''); logger.warn('未登录，通知进入积压队列'); return 0 }
    return pushText(text)
  }

  /** 长文本分段发送，返回成功发送的段数 */
  async function sendLongText(text, { userId } = {}) {
    const sent = []
    if (!client.loggedIn) {
      for (const seg of splitText(text, 1800)) enqueueOutbox(seg, userId ?? '')
      logger.warn('未登录，长文本分段进入积压队列')
      return 0
    }
    const segs = splitText(text, 1800)
    for (let i = 0; i < segs.length; i++) {
      if (i > 0) await sleep(700)
      const n = await pushText(segs[i], { userId })
      if (n === 0) break
      sent.push(segs[i])
    }
    return sent.length
  }

  // ── 1) 任务失败自动恢复 ────────────────────────────────
  const st = (agentId) => {
    let s = agentState.get(agentId)
    if (!s) { s = { failures: 0, timer: null, failTest: false, stoppedByUser: false, lastError: '' }; agentState.set(agentId, s) }
    return s
  }
  const clearTimer = (s) => { if (s.timer) { clearTimeout(s.timer); s.timer = null } }

  function assistantText(message) {
    const content = message?.content
    if (!Array.isArray(content)) return ''
    return content
      .filter(b => b && b.type === 'text' && typeof b.text === 'string')
      .map(b => b.text)
      .join('\n')
      .trim()
  }

  /** 项目名：取 session.header.cwd 的 basename */
  const projectOf = (session) => {
    try {
      const cwd = session?.header?.cwd
      if (cwd && typeof cwd === 'string') return path.basename(cwd)
    } catch { /* fallthrough */ }
    return ''
  }

  const safeTitle = (session) => {
    try {
      const snap = ctx.sessionTitle.get(session)
      if (snap && typeof snap.title === 'string' && snap.title !== '') return snap.title
    } catch { /* fallthrough */ }
    return session?.id || '未命名任务'
  }

  /** 按 sessionId 取标题：live agent 优先，其次索引，最后 sessionId */
  const titleOfSessionId = (sid) => {
    const agent = ctx.agents.get(sid)
    if (agent) {
      const t = safeTitle(agent.session)
      if (t && t !== '未命名任务' && !t.startsWith('session-')) return t
    }
    // 已解析的准确标题（来自会话日志/投影缓存）优先
    const precise = diskTitleCache.get(sid) || metaCache.get(sid)?.title || ''
    if (precise && !TITLE_PLACEHOLDERS.has(precise) && !precise.startsWith('session-')) return precise
    const t = sessionIndex.get(sid)?.title
    if (t && !t.startsWith('session-') && !TITLE_PLACEHOLDERS.has(t)) return t
    const indexed = sessionIndex.get(sid)?.firstUser
    if (indexed) return indexed
    return t || sid
  }

  async function onTurnError(agent, session, reason) {
    const route = weixinSessions.get(session.id)
    const isFailTest = route?.failingModel ? true : false
    const s = st(agent.id)
    const ident = String(agent.id ?? '')
    const isWeixinTask = Boolean(route) || ident.startsWith('weixin-')
    s.failures += 1
    s.failTest = isFailTest
    const title = safeTitle(session)
    const cls = classifyError(reason)
    const detail = cls.message
    const numTag = sessionNumberTagOf(session.id)
    const numberLine = numTag ? `编号：${numTag}` : ''
    s.lastError = `${title}: ${detail}`
    lastError = s.lastError
    logger.warn(`任务失败 #${s.failures}「${title}」${numTag}(${cls.label}): ${detail}`)

    if (isFailTest) {
      clearTimer(s)
      await notify([
        `🧪 失败测试任务已确认失败（${s.failures} 次）`,
        '',
        `任务：${title}`,
        numberLine,
        `错误：${detail}`,
        '',
        '验证目标达成：失败检测 + 微信告警链路工作正常。',
      ].filter(Boolean).join('\n'))
      return
    }

    if (s.stoppedByUser) {
      clearTimer(s)
      logger.info(`任务「${title}」${numTag}已按用户要求停止，不自动恢复`)
      return
    }

    // 任何类型失败都自动重试（最多 maxAutoRetries 次），不再对确定性错误直接放弃
    if (s.failures > cfg.maxAutoRetries) {
      clearTimer(s)
      await notify([
        '⚠️ DSH 任务连续失败，已停止自动重试',
        '',
        `任务：${title}`,
        numberLine,
        `连续失败：${s.failures} 次`,
        `最后错误：${detail}`,
        '',
        isWeixinTask ? '回复「继续」可手动恢复，回复「状态」查看全部任务。' : '',
      ].filter(Boolean).join('\n'))
      return
    }

    clearTimer(s)
    const delay = backoffDelay(cfg.retryDelayMs, s.failures, { maxMs: cfg.retryBackoffMaxMs })
    s.timer = setTimeout(() => {
      s.timer = null
      if (ctx.agents.get(agent.id) !== agent) return
      try {
        agent.followup(createUserMessage({
          content: [{ type: 'text', text: cfg.continueText }],
          source: { kind: 'plugin', plugin: 'weixin-bridge' },
        }))
        logger.info(`已自动补发「${cfg.continueText}」(${s.failures}/${cfg.maxAutoRetries}, 退避 ${delay}ms)`)
      } catch (e) {
        logger.warn(`补发失败: ${e.message}`)
      }
    }, delay)
    s.timer.unref?.()

    if (cfg.notifyOnRecovery) {
      await notify([
        `🔁 任务异常，正在自动恢复（${s.failures}/${cfg.maxAutoRetries}）`,
        '',
        `任务：${title}`,
        numberLine,
        `错误：${detail}`,
        '',
        `下次重试：约 ${Math.round(delay / 1000)} 秒后`,
      ].filter(Boolean).join('\n'))
    }
  }

  /** 任务完成通知 + 完成报告 */
  async function onTaskCompleted(agent, session, turn) {
    try {
      const route = weixinSessions.get(session.id)
      if (route?.failingModel) return
      const title = safeTitle(session)
      if (notifiedTurns.get(session.id) === turn) return
      notifiedTurns.set(session.id, turn)
      const proj = projectOf(session)
      const projPart = proj ? `「${proj}」项目中的` : ''
      const tag = sessionNumberTagOf(session.id)
      const tagPart = tag ? `${tag} ` : ''
      await notify(`✅ ${tagPart}${projPart}「${title}」任务已经完成。`)
      // 与完成通知拉开间隔，避免 iLink 连续发送被 ret=-2 拒绝
      await sleep(1500)

      // 完成报告：该 turn 最后一条 assistant 汇总消息；alwaysSendReport=true 时总是再发一次完整报告
      const rep = turnReports.get(session.id)
      if (rep && rep.turn === turn && rep.parts.length > 0) {
        const final = rep.parts[rep.parts.length - 1].trim()
        if (final) {
          if (!cfg.alwaysSendReport && lastPushed.get(session.id) === final) {
            logger.info('任务完成报告与最近回推内容相同，跳过重复推送')
          } else {
            const reportTarget = route?.userId || client.knownUsers()[0] || ''
            const segCount = await sendLongText(`📋 ${tag}任务完成报告\n\n${final}`, { userId: reportTarget || undefined })
            if (segCount > 0) logger.info(`任务完成报告已推送: ${final.length} 字符 / ${segCount} 段`)
            else logger.warn(`任务完成报告推送失败，已进入积压队列: ${final.length} 字符（请给 Bot 发一条消息触发补发）`)
          }
        }
      }
      turnReports.delete(session.id)
      logger.info(`任务完成通知已推送: ${projPart}「${title}」`)
    } catch (e) {
      logger.warn(`完成通知失败: ${e.message}`)
    }
  }

  // ── 2) 待答交互持久化 ─────────────────────────────────
  function persistAsks() {
    try {
      const list = [...pendingAsks.entries()].map(([qid, p]) => ({
        qid,
        sessionId: p.sessionId ?? '',
        title: p.title ?? '',
        userId: p.userId ?? '',
        createdAt: p.createdAt ?? Date.now(),
        questions: (p.request?.questions ?? []).map(q => ({ id: q.id, question: q.question, header: q.header })),
      }))
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      fs.writeFileSync(asksFile, JSON.stringify(list, null, 2), { mode: 0o600 })
    } catch (e) { logger.warn(`待答交互持久化失败: ${e.message}`) }
  }

  function markRestoreNotice() {
    try {
      if (!fs.existsSync(asksFile)) return
      const list = JSON.parse(fs.readFileSync(asksFile, 'utf8'))
      if (Array.isArray(list) && list.length > 0) restoreNoticePending = true
    } catch { /* 忽略 */ }
  }

  async function sendRestoreNoticeIfNeeded() {
    if (!restoreNoticePending) return
    restoreNoticePending = false
    try {
      const list = JSON.parse(fs.readFileSync(asksFile, 'utf8'))
      if (!Array.isArray(list) || list.length === 0) { fs.rmSync(asksFile, { force: true }); return }
      const lines = ['♻️ dsh-web 重启，以下待确认交互已失效：', '']
      for (const it of list.slice(0, 5)) {
        const rt = sessionNumberTagOf(it.sessionId)
        lines.push(`• ${rt ? `${rt} ` : ''}${it.title || it.sessionId}：${it.questions?.[0]?.question ?? '（交互）'}`)
      }
      lines.push('', '回复「任务」查看任务列表，回复「在 N 号任务中执行：继续」可恢复任务。')
      await notify(lines.join('\n'))
      fs.rmSync(asksFile, { force: true })
      logger.info(`已提示 ${list.length} 个重启后失效的交互`)
    } catch (e) { logger.warn(`重启提示失败: ${e.message}`) }
  }

  // ── 3) 会话索引（标题/首条消息，异步）─────────────────
  const dshHome = () => process.env.DSH_HOME || path.join(process.env.HOME || '/root', '.dsh')

  /** 推导当前工作区对应的会话目录（不再硬编码） */
  function resolveSessionsRoot() {
    if (cfg.sessionsDir) return cfg.sessionsDir
    if (sessionsRootCache) return sessionsRootCache
    const base = path.join(dshHome(), 'sessions')
    let entries = []
    try { entries = fs.readdirSync(base, { withFileTypes: true }).filter(d => d.isDirectory()) } catch { return '' }
    // 解码 --home-<user>-- 形式的目录名
    const decoded = []
    for (const d of entries) {
      const guess = '/' + d.name.replace(/^-+/, '').replace(/-+$/, '').replace(/-/g, '/')
      decoded.push({ dir: path.join(base, d.name), guess })
    }
    const target = path.resolve(workspacePath)
    const exact = decoded.find(c => path.resolve(c.guess) === target)
    if (exact) { sessionsRootCache = exact.dir; return sessionsRootCache }
    // 回退：包含最多 weixin 会话的目录
    let best = ''
    let bestCount = -1
    for (const c of decoded) {
      let n = 0
      try { n = fs.readdirSync(c.dir).filter(x => x.startsWith('weixin-')).length } catch { continue }
      if (n > bestCount) { bestCount = n; best = c.dir }
    }
    sessionsRootCache = bestCount > 0 ? best : ''
    if (sessionsRootCache) logger.info(`会话目录: ${sessionsRootCache}`)
    return sessionsRootCache
  }

  /** 枚举 sessions 根下所有工作区目录（含多 workspace） */
  let allRootsCache = { at: 0, roots: [] }
  function listSessionsRoots() {
    const base = path.join(dshHome(), 'sessions')
    if (Date.now() - allRootsCache.at < 30_000 && allRootsCache.roots.length > 0) return allRootsCache.roots
    const roots = []
    try {
      for (const d of fs.readdirSync(base, { withFileTypes: true })) {
        if (d.isDirectory()) roots.push(path.join(base, d.name))
      }
    } catch { /* ignore */ }
    allRootsCache = { at: Date.now(), roots }
    return roots
  }

  /** 主工作区目录 + 其它所有工作区目录 */
  function allSessionsRoots() {
    const roots = []
    const primary = resolveSessionsRoot()
    if (primary) roots.push(primary)
    for (const r of listSessionsRoots()) if (!roots.includes(r)) roots.push(r)
    return roots
  }

  /** 在所有工作区目录中定位某会话的日志文件 */
  function findSessionFileSync(sid) {
    const name = String(sid ?? '')
    if (!name) return ''
    for (const root of allSessionsRoots()) {
      const file = path.join(root, name, 'session.v3.jsonl.zstd')
      try { if (fs.existsSync(file)) return file } catch { /* next */ }
    }
    return ''
  }

  /**
   * 只解压会话头部（标题 / 首条用户消息 / cwd 都在文件前段），读到 limitBytes 即停止。
   * 避免超大会话（13#/14#/15# 解压后 > 64MB）撑爆 maxBuffer 而丢掉标题。
   */
  function decodeSessionHead(file, limitBytes = 2 * 1024 * 1024) {
    return new Promise((resolve, reject) => {
      let child
      try { child = spawn('zstd', ['-dc', file], { stdio: ['ignore', 'pipe', 'ignore'] }) }
      catch (e) { reject(e); return }
      const chunks = []
      let size = 0
      let settled = false
      const finish = (err) => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        try { child.kill('SIGKILL') } catch { /* ignore */ }
        if (err) reject(err)
        else resolve(Buffer.concat(chunks).toString('utf8'))
      }
      const timer = setTimeout(() => finish(), 15_000)
      timer.unref?.()
      child.stdout.on('data', (c) => {
        chunks.push(c)
        size += c.length
        if (size >= limitBytes) finish()
      })
      child.on('error', (e) => finish(e))
      child.on('close', () => finish())
    })
  }

  /** 只保留会话尾部（最近事件），用于回溯已结束任务的过程消息 */
  function decodeSessionTail(file, limitBytes = 1_500_000) {
    return new Promise((resolve) => {
      let child
      try { child = spawn('zstd', ['-dc', file], { stdio: ['ignore', 'pipe', 'ignore'] }) }
      catch { resolve(''); return }
      const chunks = []
      let total = 0
      let settled = false
      const finish = () => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        try { child.kill('SIGKILL') } catch { /* ignore */ }
        const joined = Buffer.concat(chunks)
        resolve(joined.subarray(Math.max(0, joined.length - limitBytes)).toString('utf8'))
      }
      const timer = setTimeout(finish, 25_000)
      timer.unref?.()
      child.stdout.on('data', (c) => {
        chunks.push(c)
        total += c.length
        while (chunks.length > 1 && total - chunks[0].length >= limitBytes) total -= chunks.shift().length
      })
      child.on('error', finish)
      child.on('close', finish)
    })
  }

  async function decodeSessionFile(file) {
    const { stdout } = await execFileP('zstd', ['-dc', file], { maxBuffer: 64 * 1024 * 1024, encoding: 'buffer' })
    return Buffer.from(stdout).toString('utf8')
  }

  /** 把多行内容压成一行可读标题（去 markdown 装饰、折叠空白） */
  function inlineTitle(raw) {
    const lines = String(raw ?? '')
      .replace(/\r/g, '\n')
      .split('\n')
      .map(x => x.trim())
      .filter(x => x !== '' && !/^[-*+>#]+$/.test(x))
    return lines.join(' ')
      .replace(/^[#>*-\s]+/, '')
      .replace(/\*\*/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 120)
  }

  function parseSessionMeta(text) {
    let title = ''
    let userTitle = ''      // 用户手动重命名（source.kind = user）优先
    const candidates = []
    for (const line of text.split('\n')) {
      if (line === '') continue
      if (line.includes('"type":"session/title"')) {
        const m = line.match(/"title":"((?:[^"\\]|\\.)*)"/)
        if (m) {
          let t = ''
          try { t = JSON.parse(`"${m[1]}"`) } catch { t = m[1] }
          t = t.replace(/^[#>*\-\s]+/, '').trim()      // 去掉 markdown 前缀（#、*、-）
          if (t) {
            title = t                                   // 后出现的标题覆盖前面的（重命名）
            if (line.includes('"kind":"user"')) userTitle = t
          }
        }
        continue
      }
      if (candidates.length < 3 && line.includes('"type":"user/message"')) {
        const re = /"text":"((?:[^"\\]|\\.)*)"/g
        let m
        while ((m = re.exec(line)) !== null) {
          let t = ''
          try { t = JSON.parse(`"${m[1]}"`) } catch { t = m[1] }
          t = inlineTitle(t)
          if (t === '') continue
          // 跳过例行注入与运行时上下文，取真正的第一条用户意图
          if (/runtime context|system-reminder|sandbox:policy|Current runtime context|以下信息为每次新建任务例行|可能用到的服务器信息/i.test(t)) continue
          candidates.push(t)
          break
        }
      }
    }
    return { title: userTitle || title, firstUser: candidates[0] || '', candidates }
  }

  /** 建/刷新会话索引（增量的：按 size+mtime 跳过未变文件） */
  async function buildSessionIndex() {
    const roots = allSessionsRoots()
    if (roots.length === 0) return
    const seen = new Set()
    let updated = 0
    for (const root of roots) {
      let dirs = []
      try { dirs = fs.readdirSync(root) } catch { continue }
      for (const dir of dirs) {
        if (!dir.startsWith('weixin-')) continue
        if (seen.has(dir)) continue
        seen.add(dir)
        const file = path.join(root, dir, 'session.v3.jsonl.zstd')
        let stat
        try { stat = fs.statSync(file) } catch { continue }
        const cached = sessionIndex.get(dir)
        if (cached && cached.size === stat.size && cached.mtimeMs === stat.mtimeMs) continue
        try {
          const text = await decodeSessionHead(file)
          const meta = parseSessionMeta(text)
          sessionIndex.set(dir, { title: meta.title, firstUser: meta.firstUser, size: stat.size, mtimeMs: stat.mtimeMs })
          updated++
        } catch (e) {
          logger.warn(`会话索引读取失败 ${dir}: ${e.message}`)
        }
      }
    }
    for (const key of [...sessionIndex.keys()]) {
      if (!seen.has(key)) sessionIndex.delete(key)
    }
    lastIndexBuiltAt = Date.now()
    if (updated > 0) logger.info(`会话索引已更新: +${updated}（共 ${sessionIndex.size}）`)
  }

  function ensureIndex({ force = false } = {}) {
    if (indexBuilding) return indexBuilding
    if (!force && Date.now() - lastIndexBuiltAt < cfg.indexRefreshMs) return Promise.resolve()
    indexBuilding = buildSessionIndex()
      .catch(e => logger.warn(`会话索引构建失败: ${e.message}`))
      .finally(() => { indexBuilding = null })
    return indexBuilding
  }

  /** 按标题/首条消息查找会话（live 优先；先微信会话，再按需全目录扫描网页/其它会话） */
  async function findSessionByTitle(needle) {
    const low = needle.toLowerCase()
    for (const agent of ctx.agents.list()) {
      const sid = String(agent.session?.id ?? '')
      if (!sid) continue
      const title = safeTitle(agent.session)
      if (title && title.toLowerCase().includes(low)) return { sessionId: sid, live: true }
    }
    await ensureIndex({ force: Date.now() - lastIndexBuiltAt > 10_000 })
    for (const [sid, meta] of sessionIndex) {
      const hay = `${meta.title}\n${meta.firstUser}`.toLowerCase()
      if (hay.includes(low)) return { sessionId: sid, live: false }
    }
    return scanAllSessionsByTitle(needle)
  }

  /** 按需扫描未索引（网页/其它）会话目录，命中后写入索引缓存 */
  async function scanAllSessionsByTitle(needle) {
    const roots = allSessionsRoots()
    if (roots.length === 0) return undefined
    const low = needle.toLowerCase()
    let scanned = 0
    for (const root of roots) {
      let entries = []
      try { entries = fs.readdirSync(root) } catch { continue }
      for (const dir of entries) {
        if (dir.startsWith('weixin-')) continue // 已索引
        const cached = sessionIndex.get(dir)
        if (cached) {
          if (`${cached.title}\n${cached.firstUser}`.toLowerCase().includes(low)) return { sessionId: dir, live: false }
          continue
        }
        const file = path.join(root, dir, 'session.v3.jsonl.zstd')
        let stat
        try { stat = fs.statSync(file) } catch { continue }
        try {
          const text = await decodeSessionHead(file)
          const meta = parseSessionMeta(text)
          sessionIndex.set(dir, { ...meta, size: stat.size, mtimeMs: stat.mtimeMs })
          if (`${meta.title}\n${meta.firstUser}`.toLowerCase().includes(low)) return { sessionId: dir, live: false }
        } catch { /* skip */ }
        if (++scanned >= 200) return undefined
      }
    }
    return undefined
  }

  /** 给存量会话回填稳定编号（按文件 mtime 升序，缺号补号） */
  async function backfillSessionNumbers() {
    const root = resolveSessionsRoot()
    if (!root) return
    let entries = []
    try { entries = fs.readdirSync(root) } catch { return }
    const items = []
    for (const dir of entries) {
      const file = path.join(root, dir, 'session.v3.jsonl.zstd')
      try { const st = fs.statSync(file); items.push({ dir, mtime: st.mtimeMs }) } catch { /* 非会话目录 */ }
    }
    items.sort((a, b) => a.mtime - b.mtime)
    let added = 0
    for (const it of items) {
      if (!sessionNumbers.has(it.dir)) { assignSessionNumber(it.dir); added++ }
    }
    if (added > 0) logger.info(`会话编号回填: +${added}（下一编号 ${sessionNumberTag(nextSessionNumber)}）`)
  }

  /** 任务列表：live agents（含网页任务）+ 历史会话，按时间倒序编号 */
  /** 会话目录：live agents（含网页任务）+ 历史会话，按时间倒序；limit=0 全量 */
  function buildSessionCatalog(limit = 0) {
    const items = []
    const liveIds = new Set()
    for (const agent of ctx.agents.list()) {
      const sid = String(agent.session?.id ?? agent.id ?? '')
      if (!sid) continue
      const isWeixin = sid.startsWith('weixin-')
      if (isWeixin) liveIds.add(sid)
      const s = agentState.get(agent.id)
      const liveTitle = safeTitle(agent.session)
      const shownLive = (liveTitle && !liveTitle.startsWith('session-') && !liveTitle.startsWith('weixin-'))
        ? liveTitle
        : (sessionIndex.get(sid)?.firstUser || diskTitleCache.get(sid) || liveTitle)
      items.push({
        sessionId: sid,
        title: shownLive,
        project: projectOf(agent.session),
        live: true,
        weixin: isWeixin,
        failures: s?.failures ?? 0,
        at: Date.now(),
      })
    }
    for (const [sid, meta] of sessionIndex) {
      if (liveIds.has(sid)) continue
      items.push({
        sessionId: sid,
        title: meta.title || meta.firstUser || sid,
        project: workspacePath ? path.basename(workspacePath) : '',
        live: false,
        weixin: sid.startsWith('weixin-'),
        failures: 0,
        at: meta.mtimeMs ?? 0,
      })
    }
    items.sort((a, b) => (b.live - a.live) || (b.at - a.at))
    return limit > 0 ? items.slice(0, limit) : items
  }

  function buildTaskList() {
    return buildSessionCatalog(Math.max(1, cfg.taskListLimit))
  }

  /** 全量目录：在 buildSessionCatalog 基础上，补上「已有编号但不在 live/索引」的历史会话 */
  /** 全文件流式扫描：取最后一个 session/title（用户重命名优先）与会话 cwd */
  function scanSessionMetaFull(file) {
    return new Promise((resolve) => {
      let child
      try { child = spawn('zstd', ['-dc', file], { stdio: ['ignore', 'pipe', 'ignore'] }) }
      catch { resolve({ title: '', cwd: '' }); return }
      let buf = ''
      let lastTitle = ''
      let userTitle = ''
      let cwd = ''
      let done = false
      const finish = () => {
        if (done) return
        done = true
        clearTimeout(timer)
        try { child.kill('SIGKILL') } catch { /* ignore */ }
        resolve({ title: userTitle || lastTitle, cwd })
      }
      const timer = setTimeout(finish, 20000)
      timer.unref?.()
      child.stdout.setEncoding('utf8')
      child.stdout.on('data', (chunk) => {
        buf += chunk
        let idx
        while ((idx = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, idx)
          buf = buf.slice(idx + 1)
          if (line === '' || !line.includes('"type":"')) continue
          if (!cwd && line.includes('"cwd":"')) {
            const mc = line.match(/"cwd":"((?:[^"\\]|\\.)*)"/)
            if (mc) { try { cwd = JSON.parse(`"${mc[1]}"`) } catch { /* ignore */ } }
          }
          if (line.includes('"type":"session/title"')) {
            const m = line.match(/"title":"((?:[^"\\]|\\.)*)"/)
            if (m) {
              let t = ''
              try { t = JSON.parse(`"${m[1]}"`) } catch { t = m[1] }
              t = t.replace(/^[#>*\-\s]+/, '').trim()
              if (t) {
                lastTitle = t                                   // 后出现的覆盖前面的（重命名）
                if (line.includes('"kind":"user"')) userTitle = t
              }
            }
          }
        }
        if (buf.length > 4_000_000) buf = buf.slice(-100_000)   // 防御超长单行
      })
      child.on('error', finish)
      child.on('close', finish)
    })
  }

  /** DSH 官方投影缓存（最新标题 + 会话 cwd），仅作兜底，按 mtime 缓存 */
  let projCacheState = { at: -1, map: new Map() }
  function readProjCache() {
    const file = path.join(dshHome(), 'storages', 'session_projcache.json')
    try {
      const st = fs.statSync(file)
      if (projCacheState.at === st.mtimeMs) return projCacheState.map
      const raw = JSON.parse(fs.readFileSync(file, 'utf8'))
      const map = new Map()
      for (const [sid, v] of Object.entries(raw?.tables?.sessions ?? {})) {
        map.set(sid, {
          title: String(v?.rows?.title?.val ?? ''),
          cwd: String(v?.identity?.cwd ?? ''),
        })
      }
      projCacheState = { at: st.mtimeMs, map }
      return map
    } catch { return projCacheState.map }
  }

  /** 解析某会话的准确标题与工作目录（metaCache 按 size+mtime 失效） */
  async function resolveSessionMeta(sid, file) {
    let st = null
    try { st = fs.statSync(file) } catch { /* ignore */ }
    const mc = st ? metaCache.get(sid) : undefined
    if (mc && mc.size === st.size && mc.mtime === st.mtimeMs) return mc
    let title = ''
    let cwd = ''
    try {
      const full = await scanSessionMetaFull(file)
      title = full.title || ''
      cwd = full.cwd || ''
    } catch (e) { logger.warn(`会话元数据扫描失败 ${sid}: ${e.message}`) }
    if (!title || !cwd) {
      const pc = readProjCache().get(sid)
      if (pc) { if (!title) title = pc.title || ''; if (!cwd) cwd = pc.cwd || '' }
    }
    if (!title) {
      // 兜底：首条用户消息
      try { title = parseSessionMeta(await decodeSessionHead(file)).firstUser || '' } catch { /* ignore */ }
    }
    if (TITLE_PLACEHOLDERS.has(title)) title = ''
    const rec = { size: st ? st.size : 0, mtime: st ? st.mtimeMs : 0, title, cwd }
    metaCache.set(sid, rec)
    return rec
  }

  async function buildFullCatalog() {
    const items = buildSessionCatalog(0)
    const have = new Set(items.map(i => i.sessionId))
    let hiddenMissing = 0   // 会话目录已被删除的编号：不再列出，只计数
    const fallbackProject = workspacePath ? path.basename(workspacePath) : ''
    // 先挑出需要展示的历史会话（已删除的跳过）
    const pending = []
    for (const sid of sessionNumbers.keys()) {
      if (have.has(sid)) continue
      const file = findSessionFileSync(sid)
      if (!file) { hiddenMissing++; continue }
      pending.push({ sid, file })
    }
    // 并发解析（最多 6 个同时解压），避免串行等待
    const resolved = new Map()
    let cursor = 0
    const worker = async () => {
      while (cursor < pending.length) {
        const job = pending[cursor++]
        try { resolved.set(job.sid, await resolveSessionMeta(job.sid, job.file)) }
        catch (e) { logger.warn(`会话元数据解析失败 ${job.sid}: ${e.message}`) }
      }
    }
    await Promise.all(Array.from({ length: Math.min(6, pending.length) }, () => worker()))
    for (const { sid } of pending) {
      const rec = resolved.get(sid) ?? { title: '', cwd: '' }
      const title = rec.title || ''
      const project = rec.cwd ? path.basename(String(rec.cwd)) : fallbackProject
      if (title) diskTitleCache.set(sid, title)
      else diskTitleCache.delete(sid)   // 不缓存占位符，下次继续尝试
      items.push({
        sessionId: sid,
        title: title || '（空会话）',
        project,
        live: false,
        weixin: sid.startsWith('weixin-'),
        failures: 0,
        at: 0,
      })
    }
    items.sort((a, b) => (b.live - a.live) || (b.at - a.at))
    persistMetaCache()   // 下次（含重启后）无需再全量解压
    // 附带统计（数组可挂属性），供列表头展示
    items.hiddenMissing = hiddenMissing
    return items
  }

  function resolveTaskIndex(userId, index) {
    const map = taskListByUser.get(userId)
    const sid = map?.get(index)
    return sid
  }

  // ── 4) 会话路由（带 TTL）───────────────────────────────
  function setRoute(sessionId, userId, extra = {}) {
    setCapped(weixinSessions, sessionId, { userId, ...extra }, CAPS.weixinSessions)
    setLastRoute(userId, sessionId)
  }
  function setLastRoute(userId, sessionId) {
    setCapped(weixinSessions, `last:${userId}`, { sessionId, at: Date.now() }, CAPS.weixinSessions)
    persistLastRoutes()
  }
  function lastRouteOf(userId) {
    const key = `last:${userId}`
    const r = weixinSessions.get(key)
    if (!r) return undefined
    if (Date.now() - (r.at ?? 0) > cfg.resumeTtlMs) {
      // 保留记录并打上 expired：调用方需要区分「超时」与「从未有过上文」，
      // 超时后不能再把普通指令静默当成新建任务
      return { ...r, expired: true }
    }
    return r
  }

  // ── 5) 任务创建 / 恢复 ─────────────────────────────────
  /** 例行交代内容：每个会话只在首条指令时注入一次（持久化，跨重启有效） */
  const briefedFile = path.join(stateDir, 'briefed_sessions.json')
  let briefedSessions = new Set()
  function loadBriefed() {
    try {
      const arr = JSON.parse(fs.readFileSync(briefedFile, 'utf8'))
      if (Array.isArray(arr)) briefedSessions = new Set(arr.map(String))
    } catch { /* 忽略 */ }
  }
  function persistBriefed() {
    try {
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      fs.writeFileSync(briefedFile, JSON.stringify([...briefedSessions].slice(-2000)), { mode: 0o600 })
    } catch { /* 忽略 */ }
  }
  function needsBriefing(sid) {
    const k = String(sid ?? '')
    if (!k) return true
    return !briefedSessions.has(k)
  }
  function markBriefed(sid) {
    const k = String(sid ?? '')
    if (!k || briefedSessions.has(k)) return
    briefedSessions.add(k)
    persistBriefed()
  }
  loadBriefed()

  /** 把「例行交代内容」注入到用户指令之前（仅会话首条指令用） */
  function applyBriefing(prompt) {
    return withBriefing(cfg.sessionBriefing, prompt)
  }

  async function submitTask(prompt, msgFromUserId = '') {
    const selected = ctx.agentDefaultModel.currentSelection()
    return submitTaskWithModel(prompt, msgFromUserId, { provider: selected.provider, model: selected.model })
  }

  async function resumeAndFollowup(sessionId, instruction, userId, taskName) {
    const live = ctx.agents.get(sessionId)
    const numTag = sessionNumberTagOf(sessionId)
    if (live) {
      // 接管该会话：之后的结果回推、交互提问都走微信（网页任务也可被微信接管）
      setRoute(sessionId, userId, { failingModel: false })
      await pushText(`🧠 ${numTag ? `${numTag} ` : ''}「${taskName}」执行中`, { userId })
      const liveText = (cfg.briefingOnResume && needsBriefing(sessionId)) ? applyBriefing(instruction) : instruction
      markBriefed(sessionId)
      live.followup(createUserMessage({
        content: [{ type: 'text', text: liveText }],
        source: { kind: 'user' },
      }))
      setLastRoute(userId, sessionId)
      return
    }
    // 恢复已有会话：它的 cwd 可能属于**别的工作区**（如 <workspace-b>），
    // 必须按会话自己的 cwd 定位工作区，否则 attachSession 会因
    // 「its cwd resolves to '<其它路径>'」抛错（表现为首轮失败、再发一次才成功）
    let cwdOfSession = ''
    try {
      const file = findSessionFileSync(sessionId)
      if (file) cwdOfSession = String((await resolveSessionMeta(sessionId, file)).cwd || '')
    } catch (e) { logger.warn(`解析会话工作目录失败 ${sessionId}: ${e.message}`) }
    let workspace = null
    if (cwdOfSession) {
      try { workspace = await ctx.workspaceRegistry.create(path.resolve(cwdOfSession)) }
      catch (e) { logger.warn(`按会话 cwd 建工作区失败 ${sessionId}(${cwdOfSession}): ${e.message}`) }
    }
    if (!workspace) workspace = await ctx.workspaceRegistry.create(workspacePath)
    const preset = await ctx.agentPresets.resolve(cfg.agentPreset)
    await ctx.agentPresets.standingKeyFor(preset.id)
    const sel = ctx.agentDefaultModel.currentSelection()
    const handle = await ctx.agents.resume({
      resumeSessionId: sessionId,
      agentOptions: { provider: sel.provider, model: sel.model },
      setup: async (agentCtx) => {
        await ctx.agentPresets.mount(agentCtx, preset.id)
        ensureAnswerer()
      },
    })
    handles.set(handle.agent.id, handle)
    // 先接管路由再登记工作区：登记失败也不影响本次执行
    setRoute(String(sessionId), userId, { failingModel: false })
    try {
      await workspace.attachSession(sessionId)
    } catch (e) {
      logger.warn(`会话 ${sessionId} 登记到工作区 ${workspace.path ?? workspacePath} 失败（不影响执行）: ${e.message}`)
    }
    await pushText(`🧠 ${numTag ? `${numTag} ` : ''}「${taskName}」已恢复并执行`, { userId })
    const resumeText = (cfg.briefingOnResume && needsBriefing(sessionId)) ? applyBriefing(instruction) : instruction
    markBriefed(sessionId)
    handle.agent.followup(createUserMessage({
      content: [{ type: 'text', text: resumeText }],
      source: { kind: 'user' },
    }))
  }

  async function submitTaskWithModel(prompt, msgFromUserId = '', modelSel = null) {
    const preset = await ctx.agentPresets.resolve(cfg.agentPreset)
    await ctx.agentPresets.standingKeyFor(preset.id)
    const workspace = await ctx.workspaceRegistry.create(workspacePath)
    const sessionId = brandString(`weixin-${randomUUID()}`)

    const handle = await ctx.agents.create({
      sessionId,
      meta: { cwd: workspace.path, agentPreset: preset.id },
      ...(modelSel ? { agentOptions: { provider: modelSel.provider, model: modelSel.model } } : {}),
      setup: async (agentCtx) => {
        await ctx.agentPresets.mount(agentCtx, preset.id)
        ensureAnswerer()
      },
    })
    handles.set(handle.agent.id, handle)
    await workspace.attachSession(sessionId)
    ctx.permissionPresets.set(handle.agent.session, cfg.permissionPreset)
    ctx.sessionTitle.rename(handle.agent.session, prompt.slice(0, 40))
    handle.agent.followup(createUserMessage({
      content: [{ type: 'text', text: needsBriefing(sessionId) ? applyBriefing(prompt) : prompt }],
      source: { kind: 'user' },
    }))
    markBriefed(sessionId)
    setRoute(String(sessionId), msgFromUserId, { failingModel: modelSel?.model === 'no-such-model-dsh-xyz' })
    const n = assignSessionNumber(String(sessionId))
    logger.info(`新任务已创建: ${handle.agent.id}（编号 ${sessionNumberTag(n)}）`)
    return handle
  }

  // ── 6) 指令处理 ───────────────────────────────────────
  const pad2 = (n) => String(n).padStart(2, '0')
  const clockOf = (ms) => { const d = new Date(ms); return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}` }
  const fullTimeOf = (ms) => { const d = new Date(ms); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${clockOf(ms)}` }
  const durText = (ms) => {
    const sec = Math.max(0, Math.floor(ms / 1000))
    if (sec < 60) return `${sec} 秒`
    const min = Math.floor(sec / 60)
    if (min < 60) return sec % 60 ? `${min} 分 ${sec % 60} 秒` : `${min} 分`
    const hr = Math.floor(min / 60)
    if (hr < 24) return min % 60 ? `${hr} 小时 ${min % 60} 分` : `${hr} 小时`
    const day = Math.floor(hr / 24)
    return hr % 24 ? `${day} 天 ${hr % 24} 小时` : `${day} 天`
  }

  /** 单个任务的运行状态（04#状态）：开始时间 / 总运行时长 / 过程消息及时间 / 当前状态 */
  async function taskStatusText(num) {
    const tag = sessionNumberTag(num)
    const sid = findSessionByNumber(num)
    if (!sid) return [`❌ 未找到编号 ${tag} 的任务`, '', '发「任务编号」查看列表。'].join('\n')
    const agent = ctx.agents.get(sid)
    const live = Boolean(agent)
    const title = titleOfSessionId(sid)
    const project = agent ? projectOf(agent.session) : (tr?.cwd ? path.basename(String(tr.cwd)) : '')
    const stt = agent ? agentState.get(agent.id) : undefined

    let tr = taskTrace.get(sid)
    if (!tr || tr.msgs.length === 0) {
      const disk = await readTraceFromDisk(sid)
      if (disk) tr = disk
    }
    if (!tr) tr = { startedAt: 0, lastAt: 0, turn: 0, turnStartedAt: 0, lastTurnEndAt: 0, lastEndReason: '', msgs: [] }

    const pending = [...pendingAsks.values()].some(p => p.sessionId === sid)
    const running = live && tr.turnStartedAt > (tr.lastTurnEndAt ?? 0)
    let stateLabel
    if (pending) stateLabel = '等待你的确认'
    else if (running) stateLabel = `运行中（第 ${tr.turn || 1} 轮）`
    else if (live) stateLabel = '空闲（等待指令）'
    else if (tr.lastEndReason === 'completed') stateLabel = '已停止（正常完成）'
    else if (tr.lastEndReason === 'aborted') stateLabel = '已停止（被中止）'
    else if (tr.lastEndReason === 'error') stateLabel = '已停止（出错终止）'
    else stateLabel = '已停止'
    if (stt && stt.failures > 0) stateLabel += ` · 自动重试中 ${stt.failures}/${cfg.maxAutoRetries}`
    if (trackedSessions.has(sid)) stateLabel += ' · 过程跟踪中'

    const now = Date.now()
    // 「当前任务」= 最近一次下发的指令（最后一轮 turn），只统计这一轮
    const turnStart = Number(tr.turnStartedAt) || 0
    const turnEnd = running ? now : (Number(tr.lastTurnEndAt) || Number(tr.lastAt) || 0)
    const turnMs = turnStart && turnEnd > turnStart ? turnEnd - turnStart : 0

    const lines = [
      `📊 ${tag}${title ? `「${title}」` : ''} 运行状态`,
      '',
      `状态：${stateLabel}`,
      project ? `项目：${project}` : '',
      turnStart ? `指令时间：${fullTimeOf(turnStart)}` : '指令时间：—',
      turnMs ? `运行时间：${durText(turnMs)}${running ? '（进行中）' : '（已结束）'}` : '运行时间：—',
      tr.lastAt ? `最后活动：${clockOf(tr.lastAt)}（${durText(Math.max(0, now - tr.lastAt))}前）` : '',
    ].filter(x => x !== '')

    const allMsgs = Array.isArray(tr.msgs) ? tr.msgs : []
    // 只取最近一轮的过程消息；turn 号缺失时退回全部
    const curMsgs = allMsgs.filter(m => !Number(m.turn) || Number(m.turn) === Number(tr.turn))
    const msgs = curMsgs.length > 0 ? curMsgs : allMsgs
    if (msgs.length === 0) {
      lines.push('', '本次指令的过程消息：暂无')
    } else {
      const show = msgs.slice(-12)
      lines.push('', `本次指令的过程消息：共 ${msgs.length} 条${msgs.length > show.length ? `（显示最近 ${show.length} 条）` : ''}`)
      for (const m of show) lines.push(`· ${clockOf(Number(m.t) || now)} ${String(m.text || '').slice(0, 46)}`)
    }
    if (!live) lines.push('', '（任务已结束，过程数据来自会话日志）')
    lines.push('', `「${tag}插话 指令」可即时干预 · 「${tag}跟踪」可开实时推送`)
    return lines.join('\n')
  }

  function statusText() {
    const live = ctx.agents.list()
    const weixinLive = live.filter(a => String(a.session?.id ?? '').startsWith('weixin-'))
    const lines = [
      '📊 DSH 状态',
      '',
      `服务：${client.loggedIn ? '已登录' : '未登录'}`,
      `运行时长：${humanAge(Date.now() - startedAt)}`,
      `微信任务：运行中 ${weixinLive.length} · 已知 ${sessionIndex.size}`,
      `待确认交互：${pendingAsks.size} · 待审批：${pendingApprovals.size}`,
      `过程跟踪：${trackedSessions.size} 个任务`,
    ]
    if (weixinLive.length > 0) {
      lines.push('', '运行中的微信任务：')
      for (const a of weixinLive.slice(0, 10)) {
        const s = agentState.get(a.id)
        const tag = sessionNumberTagOf(a.session?.id)
        lines.push(`• ${tag ? `${tag} ` : ''}${safeTitle(a.session)} — 失败 ${s?.failures ?? 0} 次`)
      }
    }
    if (lastError) lines.push('', `最近错误：${lastError}`)
    lines.push('', '「任务」查看列表 ·「停止 N」终止 ·「帮助」查看全部指令')
    return lines.join('\n')
  }

  function helpText() {
    return [
      'DSH 微信助手指令：',
      '',
      '【发起任务】',
      '· 直接发文字 → 续聊最近任务（10 分钟内），否则新建',
      '· 新任务：指令 → 强制新建任务',
      '',
      '【按编号操作】',
      '· 任务 / 任务编号 → 列出全部任务编号（自动过滤已删除会话）',
      '· 05# 指令 → 给该任务下指令（运行中排队）',
      '· 05#插话 指令 → 打断当前 turn 立即插入',
      '· 05#状态 → 查看该任务的运行状态（开始时间/时长/过程消息）',
      '· 05#跟踪 → 开启该任务的中间过程推送',
      '· 05#关闭跟踪 → 停止该任务的过程推送',
      '· 在「任务名」中执行：指令 → 按标题操作（自动恢复）',
      '· 在 2 号任务中执行：指令 / #2 指令 → 按序号操作',
      '',
      '【控制与查询】',
      '· 03#停止 → 终止该任务（兼容：停止 / 停止 2 / 停止 03#）',
      '· 继续 → 给失败任务补发「继续」',
      '· 允许 / 拒绝 → 答复沙箱提权等审批请求',
      '· 跳过 → 放弃待确认交互（交回网页端）',
      '· 状态 → 运行状态',
      '· 重置 → 清零失败计数',
      '· 重载 → 重新读取 config.json',
      '· 帮助 → 本说明',
      '',
      '任务失败会自动恢复；需要确认时会把选项发给你，回复序号即可。',
    ].join('\n')
  }

  /** 「任务编号」指令：列出全部项目与任务会话（含历史，不限数量） */
  async function cmdSessionIds(userId) {
    await ensureIndex({ force: true })
    const items = await buildFullCatalog()
    if (items.length === 0) {
      await pushText(['📇 暂无任务编号', '', '新建任务后会自动分配编号。'].join('\n'), { userId })
      return
    }
    const hidden = Number(items.hiddenMissing) || 0
    const lines = [`📇 任务编号（共 ${items.length}${hidden ? `，另有 ${hidden} 个已删除` : ''}）`, '']
    const seqMap = new Map()
    items.forEach((it, i) => {
      seqMap.set(i + 1, it.sessionId)
      const n = assignSessionNumber(it.sessionId)
      const tag = sessionNumberTag(n) || '—'
      const state = it.live ? (it.failures > 0 ? `运行中·失败${it.failures}` : '运行中') : '已结束'
      const proj = it.project ? ` · ${it.project}` : ''
      const rawTitle = String(it.title ?? '').replace(/\s+/g, ' ').trim() || '（未命名会话）'
      const title = rawTitle.length > 24 ? `${rawTitle.slice(0, 24)}…` : rawTitle
      lines.push(`${tag} ${title}${proj} — ${state}`)
    })
    lines.push('', `用法：「${sessionNumberTag(1)} 指令」下发；「${sessionNumberTag(1)}插话 指令」立即插入；「${sessionNumberTag(1)}停止」终止。`)
    taskListByUser.set(userId, seqMap)   // 让「#2 指令」的序号与本次列表一致
    await sendLongText(lines.join('\n'), { userId })
  }

  /** 「任务」与「任务编号」已合并：统一列出全部编号（自动过滤已删除会话） */
  async function cmdTasks(userId) {
    return cmdSessionIds(userId)
  }

  async function cmdStop(userId, index, number) {
    const live = ctx.agents.list().filter(a => String(a.session?.id ?? '').startsWith('weixin-'))
    let targets = live
    if (number !== undefined) {
      const sid = findSessionByNumber(number)
      if (!sid) {
        await pushText([`❌ 未找到编号 ${sessionNumberTag(number)} 的任务`, '', '发「任务编号」查看列表。'].join('\n'), { userId })
        return
      }
      const agent = ctx.agents.get(sid)
      if (!agent) {
        await pushText(`编号 ${sessionNumberTag(number)} 的任务未在运行中，无需停止。`, { userId })
        return
      }
      targets = [agent]
    } else if (index !== undefined) {
      const sid = resolveTaskIndex(userId, index)
      if (!sid) {
        await pushText([`❌ 未找到 ${index} 号任务`, '', '发「任务」查看列表。'].join('\n'), { userId })
        return
      }
      const agent = ctx.agents.get(sid)
      if (!agent) {
        await pushText(`任务 ${index} 未在运行中，无需停止。`, { userId })
        return
      }
      targets = [agent]
    }
    if (targets.length === 0) {
      await pushText('当前没有运行中的微信任务。', { userId })
      return
    }
    const stopped = []
    for (const a of targets) {
      const s = st(a.id)
      s.stoppedByUser = true
      s.failures = 0
      clearTimer(s)
      try {
        a.cancel?.({ kind: 'user' })
        const tag = sessionNumberTagOf(a.session?.id)
        stopped.push(`${tag ? `${tag} ` : ''}${safeTitle(a.session)}`)
      } catch (e) {
        logger.warn(`停止任务失败: ${e.message}`)
      }
    }
    await pushText(
      stopped.length > 0
        ? `⏹ 已停止 ${stopped.length} 个任务\n\n${stopped.map(t => `• ${t}`).join('\n')}`
        : '❌ 停止失败，请查看日志。',
      { userId },
    )
  }

  async function cmdSkip(userId) {
    const entry = [...pendingAsks.entries()].find(([, p]) => p.userId === userId || p.userId === '')
    if (!entry) {
      await pushText('当前没有待确认的交互。', { userId })
      return
    }
    const [qid, p] = entry
    clearTimeout(p.timer)
    pendingAsks.delete(qid)
    persistAsks()
    try {
      p.resolve(p.webP ?? (p.next ? p.next() : { answers: [] }))
      const skipTag = sessionNumberTagOf(p.sessionId)
      await pushText([`⏭ ${skipTag ? `${skipTag} ` : ''}已跳过该交互`, '', '已交回网页端继续处理。'].join('\n'), { userId })
    } catch (e) {
      logger.warn(`跳过交互失败: ${e.message}`)
      await pushText(`❌ 跳过失败：${e.message}`, { userId })
    }
  }

  async function handleInbound(msg) {
    // 用户发来消息说明 context_token 已刷新，立即解除退避并补发积压通知
    outboxBlockedUntil = 0
    flushOutbox().catch(() => {})
    const text = String(msg.text ?? '').trim()
    logger.info(`收到微信消息: ${text.slice(0, 80)}`)
    const cmd = parseCommand(text)

    // ── 指令优先（交互待答时也能用）──
    switch (cmd.kind) {
      case 'taskStatus': {
        await sendLongText(await taskStatusText(cmd.number), { userId: msg.fromUserId })
        return
      }
      case 'status':
        await sendLongText(statusText(), { userId: msg.fromUserId })
        return
      case 'help':
        await sendLongText(helpText(), { userId: msg.fromUserId })
        return
      case 'reset':
        for (const s of agentState.values()) { clearTimer(s); s.failures = 0; s.stoppedByUser = false }
        await pushText('✅ 失败计数已重置', { userId: msg.fromUserId })
        return
      case 'tasks':
        await cmdTasks(msg.fromUserId)
        return
      case 'sessionids':
        await cmdSessionIds(msg.fromUserId)
        return
      case 'stop':
        await cmdStop(msg.fromUserId, cmd.index, cmd.number)
        return
      case 'skip':
        await cmdSkip(msg.fromUserId)
        return
      case 'reload': {
        const r = reloadConfig({ manual: true })
        await pushText([`${r.ok ? '✅' : '❌'} ${r.ok ? '配置已重载' : '重载失败'}`, '', r.note].join('\n'), { userId: msg.fromUserId })
        return
      }
      case 'continue': {
        const list = ctx.agents.list()
        const targets = list.filter(a => {
          const s = agentState.get(a.id)
          return s && s.failures > 0 && !s.failTest
        })
        if (targets.length === 0) {
          await pushText(['✅ 没有处于失败状态的任务', '', '无需补发「继续」。'].join('\n'), { userId: msg.fromUserId })
          return
        }
        for (const a of targets) {
          const s = st(a.id)
          try {
            a.followup(createUserMessage({
              content: [{ type: 'text', text: cfg.continueText }],
              source: { kind: 'user' },
            }))
            s.failures = 0
            s.stoppedByUser = false
          } catch { /* 忽略单个失败 */ }
        }
        const tags = targets.map(a => sessionNumberTagOf(a.session?.id)).filter(Boolean)
        await pushText([`✅ 已向 ${targets.length} 个失败任务补发「继续」`, '', tags.join('\n')].filter(Boolean).join('\n'), { userId: msg.fromUserId })
        return
      }
      case 'failtest': {
        if (!cfg.enableFailureTest) {
          await pushText(['❌ 失败测试未启用', '', '需在配置中开启 enableFailureTest。'].join('\n'), { userId: msg.fromUserId })
          return
        }
        await pushText('🧪 正在创建注定失败的任务（用于验证失败告警链路）…', { userId: msg.fromUserId })
        try {
          const sel = ctx.agentDefaultModel.currentSelection()
          await submitTaskWithModel(text, msg.fromUserId, {
            provider: sel.provider,
            model: 'no-such-model-dsh-xyz',
          })
        } catch (e) {
          logger.error(`失败测试任务创建失败: ${e.message}`)
          await pushText(`❌ 失败测试任务创建失败：${e.message}`, { userId: msg.fromUserId })
        }
        return
      }
      case 'inTask': {
        try {
          const matched = await findSessionByTitle(cmd.taskName)
          if (!matched) {
            await pushText([`❌ 未找到标题包含「${cmd.taskName}」的任务`, '', '发「任务编号」查看列表。'].join('\n'), { userId: msg.fromUserId })
            return
          }
          await resumeAndFollowup(matched.sessionId, cmd.instruction, msg.fromUserId, cmd.taskName)
        } catch (e) {
          logger.error(`指定任务操作失败: ${e.message}`)
          await pushText(`❌ 指定任务操作失败：${e.message}`, { userId: msg.fromUserId })
        }
        return
      }
      case 'inTaskIndex': {
        const sid = resolveTaskIndex(msg.fromUserId, cmd.index) ?? (await (async () => {
          await ensureIndex({ force: true })
          const items = await buildFullCatalog()   // 与「任务编号」列表顺序一致
          const map = new Map()
          items.forEach((it, i) => map.set(i + 1, it.sessionId))
          taskListByUser.set(msg.fromUserId, map)
          return map.get(cmd.index)
        })())
        if (!sid) {
          await pushText([`❌ 未找到 ${cmd.index} 号任务`, '', '发「任务」查看列表。'].join('\n'), { userId: msg.fromUserId })
          return
        }
        try {
          const title = titleOfSessionId(sid)
          await resumeAndFollowup(sid, cmd.instruction, msg.fromUserId, title)
        } catch (e) {
          logger.error(`按序号操作任务失败: ${e.message}`)
          await pushText(`❌ 操作失败：${e.message}`, { userId: msg.fromUserId })
        }
        return
      }
      case 'stableNumber': {
        const sid = findSessionByNumber(cmd.number)
        if (!sid) {
          await pushText([`❌ 未找到编号 ${sessionNumberTag(cmd.number)} 的任务`, '', '发「任务编号」查看列表。'].join('\n'), { userId: msg.fromUserId })
          return
        }
        if (cmd.instruction === '') {
          const title = titleOfSessionId(sid)
          await pushText(`编号 ${sessionNumberTag(cmd.number)} = 「${title}」。用法：${sessionNumberTag(cmd.number)} 指令`, { userId: msg.fromUserId })
          return
        }
        try {
          const title = titleOfSessionId(sid)
          await resumeAndFollowup(sid, cmd.instruction, msg.fromUserId, title)
        } catch (e) {
          logger.error(`按编号操作任务失败: ${e.message}`)
          await pushText(`❌ 操作失败：${e.message}`, { userId: msg.fromUserId })
        }
        return
      }
      case 'track': {
        const sidT = findSessionByNumber(cmd.number)
        const tagT = sessionNumberTag(cmd.number)
        if (!sidT) {
          await pushText([`❌ 未找到编号 ${tagT} 的任务`, '', '发「任务编号」查看列表。'].join('\n'), { userId: msg.fromUserId })
          return
        }
        const titleT = titleOfSessionId(sidT)
        if (cmd.on) {
          trackedSessions.add(sidT)
          persistTracked()
          logger.info(`过程跟踪开启 ${tagT}「${titleT}」`)
          const runningT = Boolean(ctx.agents.get(sidT))
          await pushText([
            `👁 ${tagT}「${titleT}」已开启过程跟踪`,
            '',
            runningT ? '后续中间过程会实时推送。' : '任务当前未运行，恢复后会实时推送。',
            `发「${tagT}关闭跟踪」可停止。`,
          ].join('\n'), { userId: msg.fromUserId })
        } else {
          trackedSessions.delete(sidT)
          persistTracked()
          logger.info(`过程跟踪关闭 ${tagT}「${titleT}」`)
          await pushText([
            `🙈 ${tagT}「${titleT}」已关闭过程跟踪`,
            '',
            '仅推送交互提问、异常与完成报告。',
          ].join('\n'), { userId: msg.fromUserId })
        }
        return
      }
      case 'interject': {
        const sid = findSessionByNumber(cmd.number)
        const tagI = sessionNumberTag(cmd.number)
        if (!sid) {
          await pushText([`❌ 未找到编号 ${tagI} 的任务`, '', '发「任务编号」查看列表。'].join('\n'), { userId: msg.fromUserId })
          return
        }
        if (cmd.instruction === '') {
          await pushText([`💡 ${tagI} 插话用法`, '', `${tagI}插话 要插入的内容`].join('\n'), { userId: msg.fromUserId })
          return
        }
        const titleI = titleOfSessionId(sid)
        const liveI = ctx.agents.get(sid)
        if (!liveI) {
          await pushText(`⚠️ ${tagI}「${titleI}」未在运行，已按普通指令发送。`, { userId: msg.fromUserId })
          await resumeAndFollowup(sid, cmd.instruction, msg.fromUserId, titleI).catch(e => {
            logger.error(`插话回退失败: ${e.message}`)
          })
          return
        }
        setRoute(sid, msg.fromUserId, { failingModel: false })
        setLastRoute(msg.fromUserId, sid)
        const steerMsg = createUserMessage({
          content: [{ type: 'text', text: cmd.instruction }],
          source: { kind: 'user' },
        })
        let steered = false
        try {
          if (typeof liveI.steer === 'function') { liveI.steer(steerMsg); steered = true }
        } catch (e) {
          logger.warn(`插话失败，回退排队: ${e.message}`)
        }
        if (steered) {
          logger.info(`插话发送 ${tagI}「${titleI}」: ${cmd.instruction.slice(0, 40)}`)
          await pushText(`⚡ ${tagI}「${titleI}」已插话发送`, { userId: msg.fromUserId })
        } else {
          liveI.followup(steerMsg)
          await pushText(`🧠 ${tagI}「${titleI}」无法插话，已排队`, { userId: msg.fromUserId })
        }
        return
      }
      case 'newTask': {
        try {
          const h = await submitTask(cmd.body, msg.fromUserId)
          const n = sessionNumbers.get(String(h?.agent?.session?.id ?? ''))
          await pushText(`🧠 已提交新任务 ${sessionNumberTag(n)}`, { userId: msg.fromUserId })
        } catch (e) {
          logger.error(`任务创建失败: ${e.message}`)
          await pushText(`❌ 任务创建失败：${e.message}`, { userId: msg.fromUserId })
        }
        return
      }
      default:
        break
    }

    // ── 待审批（沙箱提权等）作答：优先于普通文字与交互 ──
    const apEntry = [...pendingApprovals.entries()].find(([, p]) => p.userId === msg.fromUserId || p.userId === '')
    if (apEntry) {
      const decision = parseApprovalReply(text)
      if (decision !== '') {
        const [qid, p] = apEntry
        clearTimeout(p.timer)
        pendingApprovals.delete(qid)
        const tagAp2 = sessionNumberTagOf(p.sessionId)
        const prefix = tagAp2 ? `${tagAp2} ` : ''
        if (decision === 'skip') {
          p.resolve('unavailable')
          logger.info(`审批已跳过，回落网页端 ${tagAp2}`)
          await pushText([`⏭ ${prefix}已跳过该审批`, '', '已交回网页端处理。'].join('\n'), { userId: msg.fromUserId })
        } else {
          p.resolve(decision)
          logger.info(`审批已由微信答复 ${tagAp2}: ${decision}`)
          await pushText(decision === 'allowed-once'
            ? `✅ ${prefix}已允许一次，任务继续`
            : `⛔ ${prefix}已拒绝该操作`, { userId: msg.fromUserId })
        }
        return
      }
      const tagAp3 = sessionNumberTagOf(apEntry[1].sessionId)
      await pushText([
        `⏳ ${tagAp3 ? `${tagAp3} ` : ''}等待你的审批`,
        '',
        '回复「允许」或「拒绝」',
        '回「跳过」交回网页端',
      ].join('\n'), { userId: msg.fromUserId })
      return
    }

    // ── 待确认交互作答（逐题推进：答完一题才发下一题）──
    const pendingEntry = [...pendingAsks.entries()].find(([, p]) => p.userId === msg.fromUserId || p.userId === '')
    if (pendingEntry) {
      const [qid, p] = pendingEntry
      const questions = Array.isArray(p.questions) ? p.questions : (p.request?.questions ?? [])
      const qi = Number(p.qIndex) || 0
      const q = questions[qi] ?? questions[0] ?? {}
      const opts = Array.isArray(q.options) ? q.options : []
      const trimmed = String(text ?? '').trim()
      const pTag = sessionNumberTagOf(p.sessionId)
      const pre = pTag ? `${pTag} ` : ''

      if (/^(跳过|skip)$/i.test(trimmed)) {
        clearTimeout(p.timer)
        pendingAsks.delete(qid)
        persistAsks()
        p.resolve(p.webP)
        logger.info(`交互 ${qid} 已跳过，回退网页端`)
        await pushText([`⏭ ${pre}已跳过`, '', '已交回网页端处理。'].join('\n'), { userId: msg.fromUserId })
        return
      }

      if (!looksLikeStepReply(trimmed, q)) {
        await pushText([
          `⏳ ${pre}等待你的选择（第 ${qi + 1}/${Math.max(1, questions.length)} 题）`,
          '',
          opts.length
            ? `回复序号作答（1-${opts.length}，超出范围了）；也可直接回复文字作为自定义答案`
            : '回复你的答案',
          '回「跳过」交回网页端',
        ].join('\n'), { userId: msg.fromUserId })
        return
      }

      const ans = parseQuestionAnswer(q, trimmed)
      if (!Array.isArray(p.answers)) p.answers = new Array(questions.length).fill(null)
      p.answers[qi] = ans
      const nextIdx = qi + 1
      const pickedText = ans.selected?.length ? ans.selected.join('、') : ans.custom
      const pickedKind = ans.selected?.length ? '选项' : '自定义答案'
      logger.info(`交互 ${qid} 第 ${qi + 1}/${Math.max(1, questions.length)} 题已答（${pickedKind}）: ${String(pickedText ?? '').slice(0, 60)}`)

      if (nextIdx < questions.length) {
        p.qIndex = nextIdx
        clearTimeout(p.timer)
        p.timer = armAskTimer(qid, p)   // 每题单独计时
        persistAsks()
        await pushText(renderQuestionStep(questions[nextIdx], {
          index: nextIdx + 1,
          total: questions.length,
          title: p.askTitle,
          timeoutMin: p.timeoutMin ?? Math.round(cfg.askTimeoutMs / 60000),
        }), { userId: msg.fromUserId })
        return
      }

      clearTimeout(p.timer)
      pendingAsks.delete(qid)
      persistAsks()
      p.resolve({ answers: p.answers.filter(Boolean) })
      logger.info(`交互 ${qid} 全部 ${questions.length} 题已由微信答完`)
      await pushText(`✅ ${pre}已提交 ${Math.max(1, questions.length)} 项选择，任务继续`, { userId: msg.fromUserId })
      return
    }

    // ── 普通文字：上文 ≤ 有效期 → 续聊；超时 → 明确提示（绝不静默新建） ──
    const body = cmd.body ?? text
    const last = lastRouteOf(msg.fromUserId)
    const ttlMs = Number(cfg.resumeTtlMs) || DEFAULTS.resumeTtlMs
    const ttlMin = Math.max(1, Math.round(ttlMs / 60000))
    const snippet = body.length > 30 ? `${body.slice(0, 30)}…` : body
    let routeKind = decideTextRoute({
      last,
      ttlMs,
      hasLiveAgent: Boolean(last?.sessionId && ctx.agents.get(last.sessionId)),
    })
    // 会话日志已不存在（被删除/归档）→ 等同于没有上文，直接新建，避免永远卡在「超时提示」
    if (routeKind !== 'new' && last?.sessionId) {
      let exists = true
      try { exists = Boolean(findSessionFileSync(last.sessionId)) } catch { exists = true }
      if (!exists) {
        logger.info(`上次上文对应的会话已不存在（${last.sessionId}），视为新任务`)
        routeKind = 'new'
      }
    }

    // ① 已有上文但已超时：提示超时，不新建、不续接
    if (routeKind === 'expired') {
      const lastTag = sessionNumberTagOf(last.sessionId)
      const idle = humanAge(Date.now() - (last.at ?? 0))
      logger.info(`普通指令已超时（距上次 ${idle} > ${ttlMin} 分钟），仅提示未执行`)
      await pushText([
        '⏰ 已经超时，无法继续执行任务',
        '',
        `距上次指令已过去 ${idle}，超过续聊有效期（${ttlMin} 分钟）。`,
        `为避免误把新指令当成建任务，本条未执行。`,
        `原任务：${lastTag ? `${lastTag} ` : ''}「${titleOfSessionId(last.sessionId) || '（未知）'}」`,
        '',
        `· 新建任务：发「新任务：${snippet}」`,
        `· 接着原任务：发「${lastTag || '01#'} ${snippet}」`,
        '· 查看全部任务：发「任务」',
      ].join('\n'), { userId: msg.fromUserId })
      return
    }

    // ② 有效期内的上文：优先续聊
    const liveAgent = routeKind === 'live' ? ctx.agents.get(last.sessionId) : undefined
    if (liveAgent) {
      try {
        liveAgent.followup(createUserMessage({
          content: [{ type: 'text', text: body }],
          source: { kind: 'user' },
        }))
        setLastRoute(msg.fromUserId, last.sessionId)
        return
      } catch (e) {
        logger.warn(`续聊失败，改走恢复/新建: ${e.message}`)
      }
    }
    if (routeKind === 'resume') {
      // agent 已结束但仍在有效期内：自动恢复该会话继续（不再默认新建）
      try {
        await resumeAndFollowup(
          last.sessionId,
          body,
          msg.fromUserId,
          titleOfSessionId(last.sessionId) || '原任务',
        )
        return
      } catch (e) {
        logger.warn(`恢复会话续聊失败，改为新建任务: ${e.message}`)
      }
    }

    // ③ 没有上文（首次使用）→ 新建任务
    try {
      const h = await submitTask(body, msg.fromUserId)
      const n = sessionNumbers.get(String(h?.agent?.session?.id ?? ''))
      await pushText(`🧠 已提交新任务 ${sessionNumberTag(n)}`, { userId: msg.fromUserId })
    } catch (e) {
      logger.error(`任务创建失败: ${e.message}`)
      await pushText(`❌ 任务创建失败：${e.message}`, { userId: msg.fromUserId })
    }
  }

  // ── 7) 交互应答器（只注册一路：userQuestions 服务 ctx）──
  let answererRegistered = false
  let answererRetryTimer = null

  /** 交互超时计时（逐题作答时每题重新计时） */
  function armAskTimer(qid, entry) {
    const timer = setTimeout(() => {
      pendingAsks.delete(qid)
      persistAsks()
      const tg = sessionNumberTagOf(entry.sessionId)
      logger.warn(`交互 ${qid} 超时，回退到网页端`)
      notify(`${tg ? `${tg} ` : ''}⌛ 交互超时未回复，已回退到网页端`).catch(() => {})
      entry.resolve(entry.webP)
    }, cfg.askTimeoutMs)
    timer.unref?.()
    return timer
  }

  const answererHandler = async (request, next) => {
    try {
      if (!request?.agent || !client.loggedIn || client.knownUsers().length === 0) return next()
      const sessId = request.agent?.session?.id ? String(request.agent.session.id) : ''
      const route = sessId ? weixinSessions.get(sessId) : undefined
      // 来源守卫：默认只接管微信发起的任务，网页任务的提问不受影响
      if (!route && !cfg.interceptAllSessions) return next()

      const qid = `q${++seq}`
      const qSess = request.agent?.session
      const qTag = sessionNumberTagOf(qSess?.id)
      const qTitle = qTag
        ? `❓ ${qTag}「${qSess ? safeTitle(qSess) : ''}」需要你的确认`
        : '❓ DSH 需要你的确认'
      const questions = Array.isArray(request?.questions) ? request.questions : []
      const timeoutMin = Math.round(cfg.askTimeoutMs / 60000)
      // 逐题推送：先只发第一题，用户答完再发下一题（多问题不再一次性全部推送）
      const firstText = questions.length > 0
        ? renderQuestionStep(questions[0], { index: 1, total: questions.length, title: qTitle, timeoutMin })
        : renderQuestion(request, { timeoutMin, title: qTitle })
      const delivered = await notify(firstText)
      if (delivered === 0) return next()

      // 双通道：网页端照常弹框（next() 走默认实现），微信同时等待；
      // 任一渠道先回答即生效，另一渠道的提问自然失效。
      const webP = Promise.resolve().then(() => next())
      const wxP = new Promise(resolve => {
        const entry = {
          resolve,
          next,
          webP,
          request,
          timer: null,
          userId: route?.userId ?? '',
          sessionId: sessId,
          title: sessId ? (sessionIndex.get(sessId)?.title ?? '') : '',
          createdAt: Date.now(),
          // 逐题作答状态
          questions,
          answers: new Array(questions.length).fill(null),
          qIndex: 0,
          askTitle: qTitle,
          timeoutMin,
        }
        pendingAsks.set(qid, entry)
        entry.timer = armAskTimer(qid, entry)
        persistAsks()
      })
      const raced = Promise.race([webP, wxP])
      raced.finally?.(() => {
        const p = pendingAsks.get(qid)
        if (p) {
          clearTimeout(p.timer)
          pendingAsks.delete(qid)
          persistAsks()
        }
      })
      return raced
    } catch (e) {
      logger.warn(`应答器异常: ${e.message}`)
      return next()
    }
  }

  let approvalForwarderRegistered = false

  /** 审批请求转发器：沙箱提权/危险操作等 approval/request 事件转发微信 */
  const approvalHandler = async (req, next) => {
    try {
      if (!client.loggedIn || client.knownUsers().length === 0) return next()
      const sessId = String(req?.agent?.session?.id ?? '')
      const route = sessId ? weixinSessions.get(sessId) : undefined
      // 审批会阻塞任务，无论网页/微信任务都推送（不依赖 interceptAllSessions）
      const tagAp = sessionNumberTagOf(sessId)
      const titleAp = req?.agent?.session ? safeTitle(req.agent.session) : ''
      const qid = `a${++seq}`
      const delivered = await notify(renderApproval({
        title: tagAp ? `🔐 ${tagAp}「${titleAp}」等待审批` : '🔐 DSH 等待审批',
        toolName: req?.toolName ?? '',
        reason: req?.reason ?? '',
        timeoutMin: Math.round(cfg.askTimeoutMs / 60000),
      }))
      if (delivered === 0) return next()
      if (req?.signal?.aborted) return 'cancelled'
      const userId = route?.userId || client.knownUsers()[0] || ''
      logger.info(`审批请求已转发微信 ${tagAp}「${titleAp}」: ${String(req?.toolName ?? '').slice(0, 40)}`)

      const webP = Promise.resolve().then(() => next())
      const wxP = new Promise((resolve) => {
        const timer = setTimeout(() => {
          pendingApprovals.delete(qid)
          logger.warn(`审批微信超时，回落网页端 ${tagAp}`)
          resolve('unavailable')
        }, cfg.askTimeoutMs)
        timer.unref?.()
        pendingApprovals.set(qid, { resolve, userId, sessionId: sessId, timer, toolName: req?.toolName ?? '' })
      })
      const onAbort = () => {
        const p = pendingApprovals.get(qid)
        if (p) { clearTimeout(p.timer); pendingApprovals.delete(qid) }
      }
      req?.signal?.addEventListener?.('abort', onAbort, { once: true })
      try {
        return await Promise.race([webP, wxP])
      } finally {
        req?.signal?.removeEventListener?.('abort', onAbort)
        const p = pendingApprovals.get(qid)
        if (p) { clearTimeout(p.timer); pendingApprovals.delete(qid) }
      }
    } catch (e) {
      logger.warn(`审批转发失败: ${e.message}`)
      return next()
    }
  }

  let approvalInjected = false

  function registerApprovalOn(svc, how) {
    try {
      const target = svc?.ctx ?? svc
      if (!target?.on) {
        logger.warn(`审批转发器注册跳过（${how}）：服务无 on 方法`)
        return false
      }
      target.on('approval/request', approvalHandler, { global: true, prepend: true })
      approvalForwarderRegistered = true
      logger.info(`审批转发器已注册（${how}，prepend）`)
      return true
    } catch (e) {
      logger.warn(`审批转发器注册失败（${how}）: ${e.message}`)
      return false
    }
  }

  function ensureApprovalForwarder() {
    if (approvalForwarderRegistered) return true
    let svc
    try { svc = ctx.get('approval') } catch { svc = undefined }
    if (svc) return registerApprovalOn(svc, 'get')
    // 服务晚于插件就绪时用 inject 等待（cordis 标准依赖回调）
    if (!approvalInjected) {
      approvalInjected = true
      try {
        ctx.inject(['approval'], (scope) => {
          let s2
          try { s2 = scope.get('approval') ?? scope.approval } catch { s2 = undefined }
          if (!registerApprovalOn(s2, 'inject')) logger.warn('审批 inject 回调中仍未拿到 approval 服务')
        })
        logger.info('审批转发器：approval 服务尚未就绪，已挂 inject 等待')
      } catch (e) { logger.warn(`审批 inject 失败: ${e.message}`) }
    }
    return false
  }

  function ensureAnswerer() {
    if (answererRegistered) return true
    try {
      const svc = ctx.get('userQuestions')
      const target = svc?.ctx
      if (target?.on) {
        target.on('user-questions/request', answererHandler, { global: true, prepend: true })
        answererRegistered = true
        logger.info('交互应答器已注册到 userQuestions 服务 ctx（prepend）')
        if (answererRetryTimer) { clearInterval(answererRetryTimer); answererRetryTimer = null }
        return true
      }
    } catch (e) { logger.warn(`应答器注册失败: ${e.message}`) }
    return false
  }

  // ── 8) 本地网页配置端 + 状态端点 ──────────────────────
  const escapeHtml = (s) => String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')

  function statusSnapshot() {
    const live = ctx.agents.list()
    const weixinLive = live.filter(a => String(a.session?.id ?? '').startsWith('weixin-'))
    return {
      updatedAt: new Date().toISOString(),
      uptimeMs: Date.now() - startedAt,
      loggedIn: client.loggedIn,
      knownUsers: client.knownUsers().length,
      liveTasks: live.length,
      weixinTasks: weixinLive.map(a => ({
        sessionId: String(a.session?.id ?? ''),
        title: safeTitle(a.session),
        project: projectOf(a.session),
        failures: agentState.get(a.id)?.failures ?? 0,
        stoppedByUser: Boolean(agentState.get(a.id)?.stoppedByUser),
      })),
      pendingAsks: pendingAsks.size,
      knownSessions: sessionIndex.size,
      indexedAt: lastIndexBuiltAt ? new Date(lastIndexBuiltAt).toISOString() : null,
      sessionsRoot: resolveSessionsRoot(),
      lastError: lastError || null,
      answererRegistered,
      config: currentConfig(),
    }
  }

  function writeStatusFile() {
    try {
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
      fs.writeFileSync(statusFile, JSON.stringify(statusSnapshot(), null, 2), { mode: 0o600 })
    } catch { /* 尽力 */ }
  }

  function currentConfig() {
    return {
      sessionBriefing: cfg.sessionBriefing ?? '',
      briefingOnResume: Boolean(cfg.briefingOnResume),
      maxAutoRetries: cfg.maxAutoRetries,
      retryDelayMs: cfg.retryDelayMs,
      askTimeoutMs: cfg.askTimeoutMs,
      resumeTtlMs: cfg.resumeTtlMs,
      interceptAllSessions: Boolean(cfg.interceptAllSessions),
      enableFailureTest: Boolean(cfg.enableFailureTest),
      notifyOnRecovery: Boolean(cfg.notifyOnRecovery),
      alwaysSendReport: Boolean(cfg.alwaysSendReport),
      pushProgress: Boolean(cfg.pushProgress),
    }
  }

  // ── 配置页样式（含历史任务弹窗，移动端优先）──
  const CATALOG_CSS = [
    '.tbl-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;border:1px solid #eef1f4;border-radius:10px}',
    'table.cat{border-collapse:collapse;width:100%;font-size:13px;min-width:520px}',
    'table.cat th,table.cat td{padding:9px 8px;border-bottom:1px solid #eef1f4;text-align:left;vertical-align:top}',
    'table.cat thead th{background:#f6f8fa;font-weight:600;white-space:nowrap}',
    'table.cat tr:last-child td{border-bottom:0}',
    '.c-num{font-family:monospace;font-weight:600;white-space:nowrap}',
    '.c-proj,.c-src{color:#57606a;white-space:nowrap}',
    '.st-on{color:#1a7f37;font-weight:600}',
    '.st-off{color:#8b949e}',
    'a.tlink{color:#0969da;text-decoration:none;border-bottom:1px dashed #b6d4f5}',
    'a.tlink:active{opacity:.55}',
    '.modal{position:fixed;inset:0;background:rgba(15,23,42,.5);display:none;z-index:1000}',
    '.modal.open{display:flex;align-items:center;justify-content:center;padding:16px}',
    '.modal-card{background:#fff;width:min(760px,100%);max-height:min(86vh,100%);border-radius:14px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.3)}',
    '.modal-head{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid #eef1f4;background:#fff}',
    '.modal-title{flex:1;min-width:0;font-weight:600;font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.modal-close{border:1px solid #d0d7de;background:#f6f8fa;border-radius:8px;padding:9px 14px;font-size:14px;cursor:pointer}',
    '.modal-body{flex:1;overflow:auto;padding:12px;-webkit-overflow-scrolling:touch;background:#fafbfc}',
    '.item{background:#fff;border:1px solid #e6eaef;border-radius:10px;padding:10px 12px;margin-bottom:10px}',
    '.item-h{display:flex;justify-content:space-between;gap:8px;font-size:12px;color:#6e7781;margin-bottom:6px}',
    '.item-n{font-family:monospace}',
    '.item-t{font-size:13.5px;line-height:1.6;white-space:pre-wrap;word-break:break-word;color:#1f2328}',
    '.modal-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 12px;border-top:1px solid #eef1f4;background:#fff;flex-wrap:wrap}',
    '.pager-btns{display:flex;align-items:center;gap:6px}',
    '.pager-center{display:flex;align-items:center;gap:6px}',
    '.btn{border:1px solid #d0d7de;background:#fff;border-radius:9px;padding:10px 14px;font-size:14px;cursor:pointer;white-space:nowrap}',
    '.btn:disabled{opacity:.4;cursor:default}',
    '.btn-icon{min-width:44px;padding:10px 8px;font-size:16px;line-height:1}',
    '.btn-go{min-width:60px;background:#0969da;border-color:#0969da;color:#fff}',
    '.btn-go:disabled{background:#8ab4e8;border-color:#8ab4e8;color:#fff}',
    '.pagein{width:60px;padding:9px 6px;border:1px solid #d0d7de;border-radius:9px;font-size:14px;text-align:center;font-family:inherit;box-sizing:border-box}',
    '.pagein::-webkit-outer-spin-button,.pagein::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}',
    '.pagein{-moz-appearance:textfield;appearance:textfield}',
    '.pager-total{font-size:13px;color:#57606a;white-space:nowrap}',
    '@media (max-width:640px){',
    '  body{margin:12px auto;padding:0 12px}',
    '  .modal.open{padding:0}',
    '  .modal-card{width:100%;height:100%;max-height:100%;border-radius:0}',
    '  .modal-foot{gap:6px;padding:8px 8px}',
    '  .btn{padding:11px 10px;font-size:14px}',
    '  .btn-icon{min-width:40px;padding:11px 6px}',
    '  .btn-go{min-width:54px}',
    '  .pagein{width:54px;padding:10px 4px;font-size:15px}',
    '  .pager-btns,.pager-center{flex:1 1 auto;justify-content:center}',
    '  .item-t{font-size:14px}',
    '}',
  ].join('\n')

  const TASK_MODAL_HTML = [
    '<div id="taskModal" class="modal" aria-hidden="true">',
    '  <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="tmTitle">',
    '    <div class="modal-head">',
    '      <div class="modal-title" id="tmTitle">历史任务</div>',
    '      <button class="modal-close" id="tmClose" type="button">关闭</button>',
    '    </div>',
    '    <div class="modal-body" id="tmBody"><p class="hint">加载中…</p></div>',
    '    <div class="modal-foot">',
    '      <div class="pager-btns">',
    '        <button class="btn btn-icon" id="tmFirst" type="button" title="第一页" aria-label="第一页">«</button>',
    '        <button class="btn" id="tmPrev" type="button">上一页</button>',
    '      </div>',
    '      <div class="pager-center">',
    '        <input class="pagein" id="tmInput" type="number" min="1" inputmode="numeric" aria-label="页码">',
    '        <span class="pager-total" id="tmTotal">/ 1 页</span>',
    '        <button class="btn btn-go" id="tmGo" type="button">跳转</button>',
    '      </div>',
    '      <div class="pager-btns">',
    '        <button class="btn" id="tmNext" type="button">下一页</button>',
    '        <button class="btn btn-icon" id="tmLast" type="button" title="最后一页" aria-label="最后一页">»</button>',
    '      </div>',
    '    </div>',
    '  </div>',
    '</div>',
  ].join('\n')

  const TASK_MODAL_JS = [
    '(function(){',
    '  var modal = document.getElementById("taskModal");',
    '  if (!modal) return;',
    '  var token = (new URLSearchParams(location.search)).get("token") || "";',
    '  var elTitle = document.getElementById("tmTitle");',
    '  var elBody = document.getElementById("tmBody");',
    '  var elInput = document.getElementById("tmInput");',
    '  var elTotal = document.getElementById("tmTotal");',
    '  var btnGo = document.getElementById("tmGo");',
    '  var btnPrev = document.getElementById("tmPrev");',
    '  var btnNext = document.getElementById("tmNext");',
    '  var btnFirst = document.getElementById("tmFirst");',
    '  var btnLast = document.getElementById("tmLast");',
    '  var curSid = "", curPage = 1, curPages = 1, loading = false;',
    '  function pad(n){ return n < 10 ? "0" + n : "" + n; }',
    '  function fmt(ms){',
    '    if (!ms) return "时间未知";',
    '    var d = new Date(ms);',
    '    return d.getFullYear() + "-" + pad(d.getMonth()+1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes());',
    '  }',
    '  function esc(v){ var d = document.createElement("div"); d.textContent = (v === null || v === undefined) ? "" : String(v); return d.innerHTML; }',
    '  function syncPager(){',
    '    elInput.value = String(curPage);',
    '    elInput.max = String(curPages);',
    '    elTotal.textContent = "/ 共 " + curPages + " 页";',
    '    var atFirst = curPage <= 1, atLast = curPage >= curPages;',
    '    btnPrev.disabled = atFirst; btnFirst.disabled = atFirst;',
    '    btnNext.disabled = atLast; btnLast.disabled = atLast;',
    '    btnGo.disabled = false;',
    '  }',
    '  function goTo(v){',
    '    var n = parseInt(v, 10);',
    '    if (!isFinite(n) || isNaN(n)) { syncPager(); return; }',
    '    n = Math.min(Math.max(1, n), curPages);',
    '    if (n === curPage) { syncPager(); return; }',
    '    load(curSid, n);',
    '  }',
    '  async function load(sid, page){',
    '    if (loading) return;',
    '    loading = true;',
    '    curSid = sid;',
    '    elBody.innerHTML = \'<p class="hint">加载中…</p>\';',
    '    try {',
    '      var u = "/session-tasks?sid=" + encodeURIComponent(sid) + "&page=" + page + "&size=10" + (token ? "&token=" + encodeURIComponent(token) : "");',
    '      var r = await fetch(u, { headers: { accept: "application/json" } });',
    '      var d = await r.json();',
    '      if (!r.ok || !d || !d.ok) throw new Error((d && d.error) || ("HTTP " + r.status));',
    '      curPages = d.pages || 1; curPage = d.page || 1;',
    '      elTitle.textContent = (d.number ? d.number + " " : "") + (d.title || "历史任务") + " · 共 " + d.total + " 条";',
    '      if (!d.items || d.items.length === 0) {',
    '        elBody.innerHTML = \'<p class="hint">该会话还没有用户任务记录。</p>\';',
    '      } else {',
    '        var start = (curPage - 1) * 10;',
    '        elBody.innerHTML = d.items.map(function(it, i){',
    '          var no = d.total - start - i;',
    '          return \'<div class="item"><div class="item-h"><span class="item-n">#\' + no + \'</span><span>\' + esc(fmt(it.at)) + \'</span></div><div class="item-t">\' + esc(it.text) + \'</div></div>\';',
    '        }).join("");',
    '        elBody.scrollTop = 0;',
    '      }',
    '      syncPager();',
    '    } catch (e) {',
    '      elBody.innerHTML = \'<p class="hint" style="color:#b91c1c">加载失败：\' + esc(e.message) + \'</p>\';',
    '    } finally {',
    '      loading = false;',
    '    }',
    '  }',
    '  function open(sid, title){',
    '    modal.classList.add("open");',
    '    elTitle.textContent = title || "历史任务";',
    '    elInput.value = "1"; elTotal.textContent = "/ 共 — 页";',
    '    btnPrev.disabled = true; btnNext.disabled = true;',
    '    btnFirst.disabled = true; btnLast.disabled = true; btnGo.disabled = true;',
    '    document.body.style.overflow = "hidden";',
    '    load(sid, 1);',
    '  }',
    '  function close(){',
    '    modal.classList.remove("open");',
    '    document.body.style.overflow = "";',
    '  }',
    '  document.addEventListener("click", function(e){',
    '    var a = e.target.closest ? e.target.closest("a.tlink") : null;',
    '    if (a) { e.preventDefault(); open(a.getAttribute("data-sid"), a.getAttribute("data-title") || a.textContent.trim()); return; }',
    '    if (e.target === modal) close();',
    '  });',
    '  document.getElementById("tmClose").addEventListener("click", close);',
    '  btnPrev.addEventListener("click", function(){ if (curPage > 1) load(curSid, curPage - 1); });',
    '  btnNext.addEventListener("click", function(){ if (curPage < curPages) load(curSid, curPage + 1); });',
    '  btnFirst.addEventListener("click", function(){ if (curPage > 1) load(curSid, 1); });',
    '  btnLast.addEventListener("click", function(){ if (curPage < curPages) load(curSid, curPages); });',
    '  btnGo.addEventListener("click", function(){ goTo(elInput.value); });',
    '  elInput.addEventListener("keydown", function(e){',
    '    if (e.key === "Enter") { e.preventDefault(); goTo(elInput.value); }',
    '  });',
    '  elInput.addEventListener("blur", function(){ if (parseInt(elInput.value, 10) !== curPage) goTo(elInput.value); });',
    '  document.addEventListener("keydown", function(e){ if (e.key === "Escape") close(); });',
    '})();',
  ].join('\n')

  // ── 配置页：查看某会话的历史任务（发给 Agent 的用户指令）──
  const taskHistoryCache = new Map()   // sid -> { size, mtime, title, items }

  /** 清洗单条任务文本：剥离例行交代前缀；纯系统注入内容返回空串 */
  function cleanTaskText(raw) {
    let s = String(raw ?? '')
    if (s.trim() === '') return ''
    // 例行交代（sessionBriefing）与指令拼接在同一条消息里：以结束标记为准精确切分
    const marker = /例行交代内容结束[^\n]*\n+/
    if (marker.test(s)) {
      s = s.split(marker).slice(1).join('\n')
    } else if (/以下信息为每次新建任务例行的交代内容|^<system-reminder>|Current runtime context\.|^A skill is a reusable set/i.test(s.slice(0, 300))) {
      // 纯注入内容（没有用户指令），整条丢弃
      return ''
    }
    return s.trim()
  }

  /** 解析一行会话日志，若是用户任务则返回 { at, text } */
  function parseUserTaskLine(line) {
    let ev
    try { ev = JSON.parse(line) } catch { return null }
    if (ev?.type !== 'user/message') return null
    // 只要真正的用户输入：plugin（自动补发的「继续」）、agent-instructions（AGENTS.md 提醒）、
    // skill-catalog（技能清单）、system-prompt（运行时上下文）等注入内容一律不计入
    const kind = ev?.data?.source?.kind
    if (kind !== undefined && kind !== 'user') return null
    const content = ev?.data?.content
    const segs = []
    if (Array.isArray(content)) {
      for (const c of content) if (c?.type === 'text' && typeof c.text === 'string') segs.push(c.text)
    } else if (typeof ev?.data?.text === 'string') segs.push(ev.data.text)
    const text = cleanTaskText(segs.join('\n\n'))
    if (text === '') return null
    const at = Number(ev?.time ?? 0)
    return { at: Number.isFinite(at) && at > 0 ? at : 0, text }
  }

  /** 流式扫描会话日志，取出全部用户任务（大文件不整体载入内存） */
  function scanSessionTasks(file, { maxItems = 5000, maxChars = 4_000_000, timeoutMs = 40_000 } = {}) {
    return new Promise((resolve) => {
      const items = []
      let chars = 0
      let child
      try { child = spawn('zstd', ['-dc', file], { stdio: ['ignore', 'pipe', 'ignore'] }) }
      catch { resolve(items); return }
      const dec = new StringDecoder('utf8')
      let buf = ''
      let done = false
      const finish = () => {
        if (done) return
        done = true
        clearTimeout(timer)
        resolve(items)
      }
      const timer = setTimeout(() => { try { child.kill('SIGKILL') } catch { /* ignore */ } finish() }, timeoutMs)
      timer.unref?.()
      child.stdout.on('data', (chunk) => {
        buf += dec.write(chunk)
        let idx
        while ((idx = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, idx)
          buf = buf.slice(idx + 1)
          if (!line.includes('"type":"user/message"')) continue
          const it = parseUserTaskLine(line)
          if (it) { items.push(it); chars += it.text.length }
        }
        if (items.length >= maxItems || chars >= maxChars) { try { child.kill('SIGKILL') } catch { /* ignore */ } }
      })
      child.on('error', finish)
      child.on('close', finish)
    })
  }

  /** 取某会话的历史任务（时间倒序，带 size+mtime 缓存） */
  async function sessionTaskHistory(sid) {
    const key = String(sid ?? '')
    const title = key ? (titleOfSessionId(key) || '') : ''
    const file = key ? findSessionFileSync(key) : ''
    if (!file) return { items: [], title }
    let size = 0
    let mtime = 0
    try { const st = fs.statSync(file); size = st.size; mtime = st.mtimeMs } catch { /* ignore */ }
    const cached = taskHistoryCache.get(key)
    if (cached && cached.size === size && cached.mtime === mtime) return { items: cached.items, title: title || cached.title || '' }
    const items = await scanSessionTasks(file)
    items.sort((a, b) => b.at - a.at)
    if (taskHistoryCache.size >= 12) taskHistoryCache.clear()   // 只留最近若干个会话，控制内存
    taskHistoryCache.set(key, { size, mtime, title, items })
    return { items, title }
  }

  function renderSessionCatalogHtml(items = buildSessionCatalog(200)) {
    try {
      if (items.length === 0) return '<p>暂无会话。新建任务或发送微信指令后会自动分配编号。</p>'
      const rows = items.map((it) => {
        const n = assignSessionNumber(it.sessionId)
        const tag = sessionNumberTag(n) || '—'
        const state = it.live ? (it.failures > 0 ? `运行中（失败 ${it.failures} 次）` : '运行中') : '已结束'
        const src = it.weixin ? '微信' : '网页'
        return [
          '<tr>',
          `<td class="c-num">${tag}</td>`,
          `<td><a href="#" class="tlink" data-sid="${escapeHtml(it.sessionId)}" data-title="${escapeHtml(it.title)}">${escapeHtml(it.title)}</a></td>`,
          `<td class="c-proj">${escapeHtml(it.project || '')}</td>`,
          `<td class="c-src">${src}</td>`,
          `<td><span class="${it.live ? 'st-on' : 'st-off'}">${state}</span></td>`,
          '</tr>',
        ].join('')
      }).join('')
      return `<div class="tbl-wrap"><table class="cat">
<thead><tr><th>编号</th><th>标题（点击看历史任务）</th><th>项目</th><th>来源</th><th>状态</th></tr></thead>
<tbody>${rows}</tbody></table></div>
<p class="hint">点会话标题可查看该会话的全部历史任务（每页 10 条，按时间倒序）。</p>`
    } catch (e) {
      return `<p>会话列表加载失败：${escapeHtml(e.message)}</p>`
    }
  }

  function configFormHtml(saveNote = '', catalogHtml = '') {
    const c = currentConfig()
    const noteHtml = saveNote
      ? `<div style="padding:10px;background:#e6ffe6;border:1px solid #4caf50;border-radius:4px;margin-bottom:14px">${escapeHtml(saveNote)}</div>`
      : ''
    const field = (label, input) => `<div style="margin-bottom:12px"><label style="display:block;font-weight:600;margin-bottom:4px">${label}</label>${input}</div>`
    const num = (key, val, attrs = '') => `<input type="number" name="${key}" value="${val}" ${attrs} style="width:160px;padding:6px;border:1px solid #ccc;border-radius:4px">`
    const check = (key, val, label) => `<label style="display:inline-flex;align-items:center;gap:6px;margin-right:18px"><input type="hidden" name="${key}" value="off"><input type="checkbox" name="${key}" value="on" ${val ? 'checked' : ''}> ${label}</label>`
    const token = cfg.configToken ?? ''
    const tokenQuery = token ? `?token=${encodeURIComponent(token)}` : ''
    return `<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>DSH 微信桥接配置</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:system-ui,-apple-system,'Segoe UI',sans-serif;max-width:760px;margin:24px auto;padding:0 16px;color:#1f2328}
h1{font-size:20px;border-bottom:2px solid #eee;padding-bottom:8px}
textarea,button{font-family:inherit}
.save{background:#0969da;color:#fff;border:0;padding:10px 22px;border-radius:6px;font-size:15px;cursor:pointer}
.save:hover{background:#0753aa}
.hint{color:#666;font-size:12px;margin-top:4px}
${CATALOG_CSS}</style></head>
<body>
<h1>DSH ↔ 微信 ClawBot 桥接 · 配置</h1>
${noteHtml}
<form method="POST" action="/config">
<input type="hidden" name="token" value="${escapeHtml(token)}">
${field('访问令牌（configToken，留空则免鉴权）',
  `<input type="text" name="configToken" value="${escapeHtml(token)}" placeholder="局域网访问强烈建议设置" style="width:100%;padding:6px;border:1px solid #ccc;border-radius:4px;box-sizing:border-box">`
  + `<div class="hint">设置后访问本页与 /weixin-status 需带 <code>?token=…</code>；修改令牌保存后立即生效。</div>`)}
${field('例行交代内容（每次新建会话自动注入，含服务器密码/存储路径等）',
  `<textarea name="sessionBriefing" rows="9" placeholder="例：&#10;服务器 SSH 密码：xxx&#10;常用存储路径：/home/<user>/xxx" style="width:100%;padding:8px;border:1px solid #ccc;border-radius:4px;box-sizing:border-box">${escapeHtml(c.sessionBriefing)}</textarea>`
  + `<div class="hint">新建任务时该内容会放在你的指令之前，一并交给 Agent；留空则关闭注入。</div>`)}
${field('接管/恢复已有会话时补一次例行内容（仅该会话首次；新建会话首条指令始终附带）', check('briefingOnResume', c.briefingOnResume, '启用'))}
${field('自动重试次数上限', num('maxAutoRetries', c.maxAutoRetries, 'min="1" max="20"'))}
${field('重试基础间隔（毫秒）', num('retryDelayMs', c.retryDelayMs, 'min="1000" step="1000"'))}
${field('交互等待超时（分钟）', num('askTimeoutMinutes', Math.round(c.askTimeoutMs / 60000), 'min="1" max="1440"'))}
${field('续聊最近会话有效期（分钟）', num('resumeTtlMinutes', Math.round(c.resumeTtlMs / 60000), 'min="1" max="1440"'))}
<div style="margin-bottom:12px">
${check('interceptAllSessions', c.interceptAllSessions, '也接管网页任务的问题')}
${check('enableFailureTest', c.enableFailureTest, '启用失败测试指令')}
${check('notifyOnRecovery', c.notifyOnRecovery, '恢复尝试时通知')}
${check('alwaysSendReport', c.alwaysSendReport, '完成后总是再发完整报告')}
${check('pushProgress', c.pushProgress, '推送中间过程消息（默认关闭，只保留交互/异常/报告）')}
</div>
<button class="save" type="submit">保存配置</button>
<a href="/weixin-status${tokenQuery}" style="margin-left:14px;color:#0969da">查看状态 JSON</a>
</form>
<p class="hint">保存后立即生效（无需重启）。<code>statusPort</code> / <code>statusHost</code> 需在 cordis.patch.yml 或 config.json 修改并重启生效。配置保存于 <code>${escapeHtml(configFile)}</code>（权限 0600）。</p>
<h2>DSH 项目与任务会话编号</h2>
${catalogHtml}
${TASK_MODAL_HTML}
<script>${TASK_MODAL_JS}</script>
</body></html>`
  }

  function parseFormUrlencoded(body) {
    const out = {}
    for (const pair of String(body).split('&')) {
      if (pair === '') continue
      const [k, v] = pair.split('=')
      out[decodeURIComponent(k)] = decodeURIComponent((v ?? '').replace(/\+/g, ' '))
    }
    return out
  }

  function saveConfigFromForm(form) {
    const next = {}
    const base = fs.existsSync(configFile) ? JSON.parse(fs.readFileSync(configFile, 'utf8')) : {}
    Object.assign(next, base)
    if (form.sessionBriefing !== undefined) next.sessionBriefing = form.sessionBriefing
    if (form.configToken !== undefined) next.configToken = form.configToken
    next.briefingOnResume = form.briefingOnResume === 'on'
    next.interceptAllSessions = form.interceptAllSessions === 'on'
    next.enableFailureTest = form.enableFailureTest === 'on'
    next.notifyOnRecovery = form.notifyOnRecovery === 'on'
    next.alwaysSendReport = form.alwaysSendReport === 'on'
    next.pushProgress = form.pushProgress === 'on'
    const toNum = (v, min, max, fallback) => {
      const n = Number(v)
      if (!Number.isFinite(n)) return fallback
      return Math.min(max, Math.max(min, Math.round(n)))
    }
    next.maxAutoRetries = toNum(form.maxAutoRetries, 1, 20, base.maxAutoRetries ?? DEFAULTS.maxAutoRetries)
    next.retryDelayMs = toNum(form.retryDelayMs, 1000, 600_000, base.retryDelayMs ?? DEFAULTS.retryDelayMs)
    next.askTimeoutMs = toNum(form.askTimeoutMinutes, 1, 1440, Math.round((base.askTimeoutMs ?? DEFAULTS.askTimeoutMs) / 60000)) * 60000
    next.resumeTtlMs = toNum(form.resumeTtlMinutes, 1, 1440, Math.round((base.resumeTtlMs ?? DEFAULTS.resumeTtlMs) / 60000)) * 60000
    fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 })
    fs.writeFileSync(configFile, JSON.stringify(next, null, 2), { mode: 0o600 })
    const r = reloadConfig({ manual: true })
    return r
  }

  function requestAuthorized(req) {
    const token = String(cfg.configToken ?? '')
    if (token === '') return true
    try {
      const u = new URL(req.url ?? '/', 'http://localhost')
      if (u.searchParams.get('token') === token) return true
    } catch { /* fallthrough */ }
    return false
  }

  ctx.effect(() => {
    const port = Number(cfg.statusPort) || 0
    if (port <= 0) return () => {}
    const server = http.createServer((req, res) => {
      const url = (req.url ?? '').split('?')[0]
      if (req.method === 'GET') {
        if (!requestAuthorized(req)) {
          res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
          res.end('401 需要访问令牌：请在 URL 后加 ?token=…')
          return
        }
        if (url === '/' || url === '/config') {
          (async () => {
            try {
              const items = await buildFullCatalog()
              const body = configFormHtml('', renderSessionCatalogHtml(items))
              res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'content-length': Buffer.byteLength(body) })
              res.end(body)
            } catch (e) {
              const body = configFormHtml('', `<p>会话列表加载失败：${escapeHtml(e.message)}</p>`)
              res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'content-length': Buffer.byteLength(body) })
              res.end(body)
            }
          })()
          return
        }
        if (url === '/weixin-status') {
          const body = JSON.stringify(statusSnapshot(), null, 2)
          res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) })
          res.end(body)
          return
        }
        if (url === '/config.json') {
          const body = JSON.stringify(currentConfig(), null, 2)
          res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) })
          res.end(body)
          return
        }
        if (url === '/session-tasks') {
          (async () => {
            try {
              const q = new URLSearchParams(String(req.url ?? '').split('?')[1] ?? '')
              const sid = String(q.get('sid') ?? '')
              const page = Math.max(1, Number(q.get('page') ?? 1) || 1)
              const size = Math.min(50, Math.max(1, Number(q.get('size') ?? 10) || 10))
              const { items, title } = await sessionTaskHistory(sid)
              const total = items.length
              const pages = Math.max(1, Math.ceil(total / size))
              const cur = Math.min(page, pages)
              const slice = items.slice((cur - 1) * size, cur * size)
              const body = JSON.stringify({
                ok: true,
                sessionId: sid,
                number: sessionNumberTagOf(sid),
                title,
                total,
                pages,
                page: cur,
                size,
                items: slice,
              })
              res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) })
              res.end(body)
            } catch (e) {
              const body = JSON.stringify({ ok: false, error: e.message })
              res.writeHead(500, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) })
              res.end(body)
            }
          })()
          return
        }
      }
      if (req.method === 'POST' && url === '/config') {
        let chunks = ''
        req.on('data', d => { chunks += d })
        req.on('end', () => {
          (async () => {
            try {
              const form = parseFormUrlencoded(chunks)
              const token = String(cfg.configToken ?? '')
              if (token !== '' && form.token !== token) {
                res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' })
                res.end('401 访问令牌错误')
                return
              }
              const r = saveConfigFromForm(form)
              const items = await buildFullCatalog()
              const body = configFormHtml(`✅ 已保存：${r.note}`, renderSessionCatalogHtml(items))
              res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'content-length': Buffer.byteLength(body) })
              res.end(body)
            } catch (e) {
              const body = configFormHtml(`❌ 保存失败：${e.message}`, renderSessionCatalogHtml())
              res.writeHead(500, { 'content-type': 'text/html; charset=utf-8', 'content-length': Buffer.byteLength(body) })
              res.end(body)
            }
          })()
        })
        return
      }
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' })
      res.end('not found: try /（配置页）或 /weixin-status（状态 JSON）')
    })
    server.on('error', e => logger.warn(`配置/状态端口 ${port} 启动失败: ${e.message}`))
    server.listen(port, cfg.statusHost || '127.0.0.1', () => {
      logger.info(`配置页: http://${cfg.statusHost || '127.0.0.1'}:${port}/ · 状态: /weixin-status`)
    })
    return () => { try { server.close() } catch { /* 忽略 */ } }
  }, 'weixin-bridge config/status endpoint')

  // ── 生命周期 ──────────────────────────────────────────
  ctx.effect(() => {
    const abort = new AbortController()
    let running = true

    const loop = async () => {
      while (running && !abort.signal.aborted) {
        if (!client.loggedIn) {
          logger.info('尚未登录，开始扫码流程')
          try {
            await client.login({ signal: abort.signal })
          } catch (e) {
            if (abort.signal.aborted) return
            logger.warn(`登录失败: ${e.message}，30 秒后重试`)
            await sleep(30_000)
            continue
          }
        }
        await client.notifyStart()
        await sendRestoreNoticeIfNeeded()
        ensureIndex().catch(() => {})
        backfillSessionNumbers().catch(e => logger.warn(`编号回填失败: ${e.message}`))
        try {
          await client.poll(handleInbound, { signal: abort.signal })
        } catch (e) {
          if (e instanceof ILinkError && e.isTokenExpired) {
            logger.warn('token 失效，清除并重新扫码')
            await notify(['⚠️ 微信 ClawBot 登录已失效', '', '请重新扫码登录。'].join('\n')).catch(() => {})
            client.reset()
            continue
          }
          if (abort.signal.aborted) return
          logger.error(`轮询异常退出: ${e.message}`)
          await sleep(5_000)
        }
      }
    }

    loop().catch(e => logger.error(`启动失败: ${e.message}`))

    return async () => {
      running = false
      abort.abort()
      client.stop()
      for (const [, p] of pendingAsks) { clearTimeout(p.timer); p.resolve?.({ answers: [] }) }
      pendingAsks.clear()
      for (const s of agentState.values()) clearTimer(s)
      await client.notifyStop().catch(() => {})
    }
  }, 'weixin-bridge lifecycle')

  // 应答器引导：服务可能晚于插件就绪，最多每 5 秒重试
  ctx.effect(() => {
    ensureAnswerer()
    ensureApprovalForwarder()
    // 服务可能晚于插件就绪：两者都持续轮询直到注册成功（已注册时立即返回）
    answererRetryTimer = setInterval(() => {
      ensureAnswerer()
      ensureApprovalForwarder()
    }, 5_000)
    answererRetryTimer.unref?.()
    return () => {
      if (answererRetryTimer) {
        clearInterval(answererRetryTimer)
        answererRetryTimer = null
      }
    }
  }, 'weixin-bridge answerer bootstrap')

  // 配置热重载 + 状态快照 + 周期性清理
  ctx.effect(() => {
    const configTimer = setInterval(() => {
      try {
        if (!fs.existsSync(configFile)) return
        const mtime = fs.statSync(configFile).mtimeMs
        if (mtime !== lastConfigMtime) reloadConfig()
      } catch { /* 忽略 */ }
    }, Math.max(5_000, cfg.configReloadMs))
    configTimer.unref?.()

    const statusTimer = setInterval(() => writeStatusFile(), 30_000)
    statusTimer.unref?.()

    const outboxTimer = setInterval(() => { flushOutbox().catch(() => {}) }, 5_000)
    outboxTimer.unref?.()

    const sweepTimer = setInterval(() => {
      // 清理已结束 agent 的失败计数
      const liveIds = new Set(ctx.agents.list().map(a => a.id))
      for (const id of [...agentState.keys()]) if (!liveIds.has(id)) agentState.delete(id)
      // 清理过期的 last 路由
      for (const key of [...weixinSessions.keys()]) {
        if (!key.startsWith('last:')) continue
        const v = weixinSessions.get(key)
        // 保留 24 小时内的「上次上文」记忆：超时也要能提示，不能因过期被清掉而静默新建
        if (Date.now() - (v?.at ?? 0) > Math.max(cfg.resumeTtlMs * 4, 24 * 3600_000)) {
          weixinSessions.delete(key)
          lastRoutesDirty = true
        }
      }
      if (lastRoutesDirty) {
        lastRoutesDirty = false
        persistLastRoutes({ force: true })
      }
      // 收敛上限
      while (notifiedTurns.size > CAPS.notifiedTurns) notifiedTurns.delete(notifiedTurns.keys().next().value)
      while (lastPushed.size > CAPS.lastPushed) lastPushed.delete(lastPushed.keys().next().value)
      while (turnReports.size > CAPS.turnReports) turnReports.delete(turnReports.keys().next().value)
      writeStatusFile()
    }, 600_000)
    sweepTimer.unref?.()

    return () => { clearInterval(configTimer); clearInterval(statusTimer); clearInterval(outboxTimer); clearInterval(sweepTimer) }
  }, 'weixin-bridge maintenance')

  // session 事件：结果回推 / 完成报告累积 / turn 结束处理
  // 串行队列：确保同一会话的 assistant/message 回推先于 turn/end 完成，
  // 否则「完成报告 vs 最近回推」去重会因网络 await 的时序竞态而失效（重复推送）。
  const sessionQueues = new Map()
  function enqueueSessionEvent(sessionId, fn) {
    const prev = sessionQueues.get(sessionId) ?? Promise.resolve()
    const run = prev.catch(() => {}).then(fn)
    sessionQueues.set(sessionId, run.catch(() => {}))
    if (sessionQueues.size > 256) {
      const first = sessionQueues.keys().next().value
      if (first !== undefined) sessionQueues.delete(first)
    }
    return run
  }

  function traceOf(sid) {
    let tr = taskTrace.get(sid)
    if (!tr) {
      tr = { startedAt: 0, lastAt: 0, turn: 0, turnStartedAt: 0, lastTurnEndAt: 0, lastEndReason: '', accMs: 0, msgs: [] }
      taskTrace.set(sid, tr)
      while (taskTrace.size > CAPS.taskTrace) taskTrace.delete(taskTrace.keys().next().value)
    }
    return tr
  }

  /** 记录任务轨迹（不受推送开关影响，仅内存） */
  function recordTrace(session, event) {
    try {
      const sid = String(session?.id ?? '')
      if (!sid || !event?.type) return
      const at = Number(event.time) || Date.now()
      if (event.type === 'turn/start') {
        const tr = traceOf(sid)
        if (!tr.startedAt) tr.startedAt = at
        tr.turn = Number(event.data?.turn) || tr.turn + 1
        tr.turnStartedAt = at
        tr.lastAt = at
        return
      }
      if (event.type === 'turn/end') {
        const tr = traceOf(sid)
        if (tr.turnStartedAt && at > tr.turnStartedAt) tr.accMs = (tr.accMs || 0) + (at - tr.turnStartedAt)
        tr.lastAt = at
        tr.lastTurnEndAt = at
        tr.lastEndReason = String(event.data?.reason?.kind ?? '')
        return
      }
      if (event.type === 'assistant/message' && !event.data?.interrupted) {
        const text = assistantText(event.data?.message)
        if (text === '') return
        const tr = traceOf(sid)
        if (!tr.startedAt) tr.startedAt = at
        tr.lastAt = at
        tr.msgs.push({ t: at, turn: Number(event.data?.turn) || 0, text: inlineTitle(text).slice(0, 200) })
        while (tr.msgs.length > CAPS.traceMsgs) tr.msgs.shift()
      }
    } catch { /* 轨迹记录失败不影响主流程 */ }
  }

  /** 从会话日志回溯轨迹（已结束任务） */
  async function readTraceFromDisk(sid) {
    const file = findSessionFileSync(sid)
    if (!file) return undefined
    try {
      const head = await decodeSessionHead(file)
      const tail = await decodeSessionTail(file)
      const tr = { startedAt: 0, lastAt: 0, turn: 0, turnStartedAt: 0, lastTurnEndAt: 0, lastEndReason: '', accMs: 0, msgs: [] }
      for (const text of [head, tail]) {
        for (const line of text.split('\n')) {
          if (!line.startsWith('{')) continue
          let ev
          try { ev = JSON.parse(line) } catch { continue }
          const t = Number(ev.time) || 0
          if (ev.type === 'turn/start') {
            if (!tr.startedAt) tr.startedAt = t
            tr.turn = Number(ev.data?.turn) || tr.turn
            tr.turnStartedAt = t
            tr.lastTurnEndAt = 0
          } else if (ev.type === 'turn/end') {
            if (tr.turnStartedAt && t > tr.turnStartedAt) tr.accMs = (tr.accMs || 0) + (t - tr.turnStartedAt)
            tr.lastTurnEndAt = t
            tr.lastEndReason = String(ev.data?.reason?.kind ?? '')
          } else if (ev.type === 'assistant/message' && !ev.data?.interrupted) {
            const txt = assistantText(ev.data?.message)
            if (txt) tr.msgs.push({ t, turn: Number(ev.data?.turn) || 0, text: inlineTitle(txt).slice(0, 200) })
          }
        }
      }
      const mCwd = head.match(/"cwd":"((?:[^"\\]|\\.)*)"/)
      if (mCwd) { try { tr.cwd = JSON.parse(`"${mCwd[1]}"`) } catch { /* ignore */ } }
      const seen = new Set()
      tr.msgs = tr.msgs.filter(m => {
        const k = `${m.t}|${m.text}`
        if (seen.has(k)) return false
        seen.add(k)
        return true
      }).sort((a, b) => a.t - b.t)
      if (tr.msgs.length > CAPS.traceMsgs) tr.msgs = tr.msgs.slice(-CAPS.traceMsgs)
      tr.lastAt = tr.msgs.length ? tr.msgs[tr.msgs.length - 1].t : (tr.lastTurnEndAt || tr.turnStartedAt || tr.startedAt)
      return tr
    } catch (e) {
      logger.warn(`任务轨迹读取失败 ${sid}: ${e.message}`)
      return undefined
    }
  }

  async function handleSessionEvent(session, event) {
    recordTrace(session, event)
    if (event?.type === 'assistant/message' && !event.data?.interrupted) {
      const data = event.data
      const text = assistantText(data?.message)
      if (text !== '') {
        const cur = turnReports.get(session.id)
        if (!cur || cur.turn !== data.turn) {
          setCapped(turnReports, session.id, { turn: data.turn, parts: [], bytes: 0 }, CAPS.turnReports)
        }
        const rec = turnReports.get(session.id)
        rec.parts.push(text)
        rec.bytes += text.length
        while (rec.parts.length > 20 || (rec.bytes > cfg.maxReportBytes && rec.parts.length > 1)) {
          rec.bytes -= rec.parts[0].length
          rec.parts.shift()
        }
      }
      const route = weixinSessions.get(session.id)
      if (route && text !== '') {
        // 过程消息默认不推送（cfg.pushProgress=false）：只保留交互提问、异常/失败告警与完成报告；
        // 单个任务可用「04#跟踪」单独开启
        if (cfg.pushProgress || trackedSessions.has(session.id)) {
          const pushTag = sessionNumberTagOf(session.id)
          await pushText(`${pushTag ? `${pushTag} ` : ''}${text}`, { userId: route.userId })
            .then(() => { setCapped(lastPushed, session.id, text, CAPS.lastPushed) })
            .catch(e => logger.warn(`结果回推失败: ${e.message}`))
        } else {
          setCapped(lastPushed, session.id, text, CAPS.lastPushed)
        }
      }
      return
    }
    if (event?.type !== 'turn/end') return
    const agent = ctx.agents.get(session.id)
    if (!agent || agent.session !== session) return
    const reason = event.data?.reason
    const s = agentState.get(agent.id)
    if (reason?.kind === 'error') {
      turnReports.delete(session.id)
      await onTurnError(agent, session, reason)
    } else if (reason?.kind === 'completed') {
      if (s) { s.failures = 0; clearTimer(s); s.failTest = false; s.stoppedByUser = false }
      await onTaskCompleted(agent, session, event.data?.turn ?? 0)
    } else if (reason?.kind === 'aborted') {
      turnReports.delete(session.id)
      if (s) {
        clearTimer(s)
        s.failures = 0
        if (s.stoppedByUser) {
          s.stoppedByUser = false
          logger.info(`任务已停止「${safeTitle(session)}」`)
        }
      }
    } else {
      if (s) { s.failures = 0; clearTimer(s) }
    }
  }

  ctx.effect(() => ctx.on('session/event', (session, event) => {
    enqueueSessionEvent(String(session?.id ?? 'unknown'), () => handleSessionEvent(session, event))
  }), 'weixin-bridge turn watcher')

  ctx.on('agent/created', ({ agent }) => {
    ensureAnswerer()
    const sid = agent.session?.id ? String(agent.session.id) : ''
    if (sid) {
      const n = assignSessionNumber(sid)
      logger.info(`会话编号: ${sessionNumberTag(n)} -> ${safeTitle(agent.session) || sid}`)
    }
  }, { global: true })

  ctx.on('agent/disposed', ({ agent }) => {
    const s = agentState.get(agent.id)
    if (s) { clearTimer(s); agentState.delete(agent.id) }
    const sid = agent.session?.id ? String(agent.session.id) : ''
    const route = sid ? weixinSessions.get(sid) : undefined
    if (route?.userId) {
      const lastKey = `last:${route.userId}`
      const last = weixinSessions.get(lastKey)
      if (last?.sessionId === sid) weixinSessions.delete(lastKey)
    }
    if (sid) weixinSessions.delete(sid)
    handles.delete(agent.id)
  }, { global: true })

  markRestoreNotice()
  writeStatusFile()
  logger.info(`插件已加载 (工作区 ${workspacePath}, 最大重试 ${cfg.maxAutoRetries}, 状态端口 ${cfg.statusPort})`)
}
