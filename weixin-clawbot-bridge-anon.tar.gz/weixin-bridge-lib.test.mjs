/**
 * weixin-bridge-lib 单元测试（node:test）
 * 运行：node --test weixin-bridge-lib.test.mjs
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import {
  backoffDelay,
  classifyError,
  decideTextRoute,
  humanAge,
  looksLikeOptionReply,
  looksLikeStepReply,
  parseAnswer,
  parseApprovalReply,
  parseCommand,
  parseQuestionAnswer,
  renderApproval,
  renderQuestion,
  renderQuestionStep,
  sessionNumberTag,
  splitText,
  withBriefing,
} from './weixin-bridge-lib.mjs'

test('splitText: 短文本单段', () => {
  assert.deepEqual(splitText('短文本', 1800), ['短文本'])
})

test('splitText: 空文本返回空数组', () => {
  assert.deepEqual(splitText('', 1800), [])
  assert.deepEqual(splitText(null, 1800), [])
})

test('splitText: 超长单行硬切且不丢内容', () => {
  const t = 'x'.repeat(5000)
  const segs = splitText(t, 1800)
  assert.equal(segs.length, 3)
  assert.ok(segs.every(s => s.length <= 1800))
  assert.equal(segs.join(''), t)
})

test('splitText: 多行按换行积聚，每段不超限', () => {
  const t = Array.from({ length: 50 }, (_, i) => `行${i} ${'字'.repeat(100)}`).join('\n')
  const segs = splitText(t, 1800)
  assert.ok(segs.length >= 3)
  assert.ok(segs.every(s => s.length <= 1800))
  assert.equal(segs.join('\n'), t)
})

test('splitText: 保留换行结构', () => {
  const t = 'a\nb\nc'
  assert.deepEqual(splitText(t, 1800), ['a\nb\nc'])
})

test('renderQuestion: 含标题、选项、超时提示', () => {
  const out = renderQuestion({
    questions: [{
      id: 'q1', header: '确认', question: '选哪个季节？',
      options: [{ label: 'A 春天', description: '花开' }, { label: 'B 夏天' }],
    }],
  }, { timeoutMin: 15 })
  assert.match(out, /DSH 需要你的确认/)
  assert.match(out, /【确认】选哪个季节？/)
  assert.match(out, /1\) A 春天 — 花开/)
  assert.match(out, /2\) B 夏天/)
  assert.match(out, /15 分钟/)
  assert.match(out, /跳过/)
})

test('renderQuestion: 空请求不抛错', () => {
  const out = renderQuestion({})
  assert.match(out, /DSH 需要你的确认/)
})

test('parseAnswer: 单选序号', () => {
  const req = { questions: [{ id: 'q1', options: [{ label: 'A' }, { label: 'B' }] }] }
  assert.deepEqual(parseAnswer(req, '2'), { answers: [{ id: 'q1', selected: ['B'] }] })
})

test('parseAnswer: 多选序号', () => {
  const req = { questions: [{ id: 'q1', multiSelect: true, options: [{ label: 'A' }, { label: 'B' }, { label: 'C' }] }] }
  assert.deepEqual(parseAnswer(req, '1,3'), { answers: [{ id: 'q1', selected: ['A', 'C'] }] })
})

test('parseAnswer: 非序号按自定义答案', () => {
  const req = { questions: [{ id: 'q1', options: [{ label: 'A' }] }] }
  assert.deepEqual(parseAnswer(req, '我要春天'), { answers: [{ id: 'q1', selected: [], custom: '我要春天' }] })
})

test('parseAnswer: 自由文本问题直接作为答案', () => {
  const req = { questions: [{ id: 'q1', options: [] }] }
  assert.deepEqual(parseAnswer(req, '随便写点什么'), { answers: [{ id: 'q1', selected: [], custom: '随便写点什么' }] })
})

test('looksLikeOptionReply: 有选项时只认序号', () => {
  const req = { questions: [{ options: [{ label: 'A' }, { label: 'B' }] }] }
  assert.equal(looksLikeOptionReply('2', req), true)
  assert.equal(looksLikeOptionReply('1,2', req), true)
  assert.equal(looksLikeOptionReply('3', req), false)
  assert.equal(looksLikeOptionReply('状态', req), false)
})

test('looksLikeOptionReply: 无选项时任何文本都算答案', () => {
  assert.equal(looksLikeOptionReply('你好', { questions: [{ options: [] }] }), false)
  assert.equal(looksLikeOptionReply('你好', { questions: [] }), false)
})

test('classifyError: 502 属于瞬时错误', () => {
  const r = classifyError({ kind: 'error', error: { message: '502: {"message":"Upstream service temporarily unavailable"}', code: 'SERVER' } })
  assert.equal(r.transient, true)
  assert.equal(r.label, '瞬时错误')
})

test('classifyError: 429/超时/ECONNRESET 属于瞬时错误', () => {
  assert.equal(classifyError({ error: { message: '429 rate limit' } }).transient, true)
  assert.equal(classifyError({ error: { message: 'request timeout' } }).transient, true)
  assert.equal(classifyError({ error: { message: 'read ECONNRESET' } }).transient, true)
  assert.equal(classifyError({ error: { code: 'UPSTREAM' } }).transient, true)
  assert.equal(classifyError({ error: { message: 'no adapter registered for provider "dpdns"' } }).transient, true)
})

test('classifyError: 参数/鉴权错误属于确定性错误', () => {
  assert.equal(classifyError({ error: { message: '400 invalid argument', code: 'INVALID_ARGUMENT' } }).transient, false)
  assert.equal(classifyError({ error: { message: '401 unauthorized', code: 'AUTH' } }).transient, false)
  assert.equal(classifyError({ error: { message: 'model not found' } }).transient, false)
})

test('classifyError: 空值不抛错', () => {
  const r = classifyError(undefined)
  assert.equal(typeof r.message, 'string')
  assert.equal(r.transient, false)
})

test('backoffDelay: 指数增长并受上限约束', () => {
  const d1 = backoffDelay(8000, 1, { jitter: 0 })
  const d2 = backoffDelay(8000, 2, { jitter: 0 })
  const d3 = backoffDelay(8000, 3, { jitter: 0 })
  assert.equal(d1, 8000)
  assert.equal(d2, 16000)
  assert.equal(d3, 32000)
  assert.equal(backoffDelay(8000, 10, { jitter: 0, maxMs: 60000 }), 60000)
})

test('backoffDelay: 抖动保持在范围内', () => {
  for (let i = 0; i < 50; i++) {
    const d = backoffDelay(1000, 1, { jitter: 0.2 })
    assert.ok(d >= 800 && d <= 1200, `抖动越界: ${d}`)
  }
})

test('parseCommand: 基础指令', () => {
  assert.equal(parseCommand('状态').kind, 'status')
  assert.equal(parseCommand('/status').kind, 'status')
  assert.equal(parseCommand('帮助').kind, 'help')
  assert.equal(parseCommand('重置').kind, 'reset')
  assert.equal(parseCommand('继续').kind, 'continue')
  assert.equal(parseCommand('任务').kind, 'tasks')
  assert.equal(parseCommand('任务编号').kind, 'sessionids')
  const iv = parseCommand('04#插话 保存报告到 report 目录')
  assert.equal(iv.kind, 'interject')
  assert.equal(iv.number, 4)
  assert.equal(iv.instruction, '保存报告到 report 目录')
  assert.equal(parseCommand('04#插话：立即检查').kind, 'interject')
  assert.equal(parseCommand('04#插话内容').instruction, '内容')
  assert.equal(parseCommand('04# 普通指令').kind, 'stableNumber')
  const tr = parseCommand('04#跟踪')
  assert.equal(tr.kind, 'track')
  assert.equal(tr.number, 4)
  assert.equal(tr.on, true)
  assert.equal(parseCommand('04#关闭跟踪').on, false)
  assert.equal(parseCommand('04# 跟踪').on, true)
  assert.equal(parseCommand('04#跟踪 检查进度').kind, 'stableNumber')
  const ts1 = parseCommand('04#状态')
  assert.equal(ts1.kind, 'taskStatus'); assert.equal(ts1.number, 4)
  assert.equal(parseCommand('04# 状态').kind, 'taskStatus')
  assert.equal(parseCommand('12#运行状态').number, 12)
  assert.equal(parseCommand('状态').kind, 'status')
  assert.equal(parseCommand('04#状态 顺便看看').kind, 'stableNumber')
  assert.equal(parseApprovalReply('允许'), 'allowed-once')
  assert.equal(parseApprovalReply('允许一次'), 'allowed-once')
  assert.equal(parseApprovalReply('拒绝'), 'rejected')
  assert.equal(parseApprovalReply('跳过'), 'skip')
  assert.equal(parseApprovalReply('状态'), '')
  const ap = renderApproval({ toolName: 'escalate sandbox', reason: '写工作区外路径', timeoutMin: 15, title: '🔐 04#「测试」等待审批' })
  assert.match(ap, /等待审批/)
  assert.match(ap, /escalate sandbox/)
  assert.match(ap, /允许/)
  assert.match(ap, /拒绝/)
  assert.equal(parseCommand('会话编号').kind, 'sessionids')
  assert.equal(parseCommand('编号').kind, 'sessionids')
  assert.equal(parseCommand('/sessions').kind, 'sessionids')
  assert.equal(parseCommand('跳过').kind, 'skip')
  assert.equal(parseCommand('重载').kind, 'reload')
  assert.equal(parseCommand('测试失败').kind, 'failtest')
})

test('parseCommand: 停止/取消带编号', () => {
  assert.deepEqual(parseCommand('停止'), { kind: 'stop', index: undefined })
  assert.deepEqual(parseCommand('取消'), { kind: 'stop', index: undefined })
  assert.deepEqual(parseCommand('停止 2'), { kind: 'stop', index: 2 })
  assert.deepEqual(parseCommand('取消 3'), { kind: 'stop', index: 3 })
  assert.deepEqual(parseCommand('停止 03#'), { kind: 'stop', number: 3 })
  assert.deepEqual(parseCommand('停止 12#'), { kind: 'stop', number: 12 })
  // 新格式：编号在前
  assert.deepEqual(parseCommand('03#停止'), { kind: 'stop', number: 3 })
  assert.deepEqual(parseCommand('03# 停止'), { kind: 'stop', number: 3 })
  assert.deepEqual(parseCommand('12#终止'), { kind: 'stop', number: 12 })
  // 「任务」与「任务编号」都返回全量目录
  assert.equal(parseCommand('任务').kind, 'tasks')
  assert.equal(parseCommand('任务编号').kind, 'sessionids')
})

test('parseCommand: 在「任务名」中执行', () => {
  const r = parseCommand('在「继续任务」中执行：写个文件')
  assert.equal(r.kind, 'inTask')
  assert.equal(r.taskName, '继续任务')
  assert.equal(r.instruction, '写个文件')
})

test('parseCommand: 在 N 号任务中执行 / #N', () => {
  const a = parseCommand('在 2 号任务中执行：跑测试')
  assert.equal(a.kind, 'inTaskIndex')
  assert.equal(a.index, 2)
  assert.equal(a.instruction, '跑测试')

  const b = parseCommand('#3 看看日志')
  assert.equal(b.kind, 'inTaskIndex')
  assert.equal(b.index, 3)
  assert.equal(b.instruction, '看看日志')
})

test('parseCommand: 新任务前缀强制新建', () => {
  const r = parseCommand('新任务：写个文件')
  assert.equal(r.kind, 'newTask')
  assert.equal(r.body, '写个文件')
})

test('parseCommand: 普通文字保持 text', () => {
  const r = parseCommand('帮我写一个文件')
  assert.equal(r.kind, 'text')
  assert.equal(r.body, '帮我写一个文件')
})

test('humanAge: 基本单位换算', () => {
  assert.equal(humanAge(1000), '1 秒')
  assert.equal(humanAge(120_000), '2 分钟')
  assert.equal(humanAge(2 * 3600_000), '2 小时')
  assert.equal(humanAge(3 * 86400_000), '3 天')
})

test('withBriefing: 空内容原样返回', () => {
  assert.equal(withBriefing('', '任务'), '任务')
  assert.equal(withBriefing('   ', '任务'), '任务')
  assert.equal(withBriefing(null, '任务'), '任务')
})

test('withBriefing: 前置注入例行内容', () => {
  const b = '服务器密码：xyz\n存储路径：/home/<user>'
  const out = withBriefing(b, '帮我写文件')
  assert.equal(out, `${b}\n\n帮我写文件`)
})

test('withBriefing: 可关闭注入', () => {
  assert.equal(withBriefing('例行内容', '任务', { enabled: false }), '任务')
})

test('parseCommand: 稳定会话编号 05# 指令 / 在 05# 中执行', () => {
  const a = parseCommand('05# 测试运行')
  assert.equal(a.kind, 'stableNumber')
  assert.equal(a.number, 5)
  assert.equal(a.instruction, '测试运行')

  const b = parseCommand('12# 看看日志')
  assert.equal(b.kind, 'stableNumber')
  assert.equal(b.number, 12)
  assert.equal(b.instruction, '看看日志')

  const c = parseCommand('在 03# 中执行：继续')
  assert.equal(c.kind, 'stableNumber')
  assert.equal(c.number, 3)
  assert.equal(c.instruction, '继续')

  // 仅编号不带指令
  const d = parseCommand('05#')
  assert.equal(d.kind, 'stableNumber')
  assert.equal(d.number, 5)
  assert.equal(d.instruction, '')
})

test('parseCommand: #3 动态列表序号与稳定编号不冲突', () => {
  const a = parseCommand('#3 看看日志')
  assert.equal(a.kind, 'inTaskIndex')
  assert.equal(a.index, 3)
  const b = parseCommand('3# 看看日志')
  assert.equal(b.kind, 'stableNumber')
  assert.equal(b.number, 3)
})

test('sessionNumberTag: 补零两位', () => {
  assert.equal(sessionNumberTag(5), '05#')
  assert.equal(sessionNumberTag(12), '12#')
  assert.equal(sessionNumberTag(100), '100#')
  assert.equal(sessionNumberTag(0), '')
  assert.equal(sessionNumberTag('abc'), '')
})

test('renderQuestionStep: 单题带序号选项与题号', () => {
  const q = { id: 'a', header: '字符上限', question: '要不要调高？', options: [{ label: '调高', description: '更稳' }, { label: '不动' }] }
  const one = renderQuestionStep(q, { title: '❓ 33#「测试」需要你的确认', timeoutMin: 15 })
  assert.match(one, /33#/)
  assert.match(one, /【字符上限】要不要调高？/)
  assert.match(one, /1\) 调高 — 更稳/)
  assert.match(one, /2\) 不动/)
  assert.doesNotMatch(one, /第 1\/1 题/)
  const two = renderQuestionStep(q, { index: 2, total: 3, title: 'T' })
  assert.match(two, /第 2\/3 题/)
})

test('parseQuestionAnswer: 序号/多选/自由文本', () => {
  const q = { id: 'x', options: [{ label: 'A' }, { label: 'B' }, { label: 'C' }] }
  assert.deepEqual(parseQuestionAnswer(q, '2'), { id: 'x', selected: ['B'] })
  assert.deepEqual(parseQuestionAnswer(q, '自定义'), { id: 'x', selected: [], custom: '自定义' })
  const multi = { id: 'm', multiSelect: true, options: [{ label: 'A' }, { label: 'B' }] }
  assert.deepEqual(parseQuestionAnswer(multi, '1,2'), { id: 'm', selected: ['A', 'B'] })
  const free = { id: 'f' }
  assert.deepEqual(parseQuestionAnswer(free, '随便写'), { id: 'f', selected: [], custom: '随便写' })
})

test('looksLikeStepReply: 序号、选项原文、自定义文字都接受，越界数字才拒绝', () => {
  const q = { options: [{ label: 'A' }, { label: 'B' }] }
  assert.equal(looksLikeStepReply('1', q), true)
  assert.equal(looksLikeStepReply('2,1', q), true)
  assert.equal(looksLikeStepReply('9', q), false)          // 纯数字但越界 → 重新提示
  assert.equal(looksLikeStepReply('0', q), false)
  assert.equal(looksLikeStepReply('我觉得不行', q), true)   // 非数字 → 自定义答案
  assert.equal(looksLikeStepReply('https://example.com/', q), true)
  assert.equal(looksLikeStepReply('', q), false)
  const free = { options: [] }
  assert.equal(looksLikeStepReply('任何文字', free), true)
})

test('parseQuestionAnswer: 贴网址等自定义答案原样保留', () => {
  const q = {
    id: 'tpl',
    options: [
      { label: '我在回复里贴具体网址（推荐）' },
      { label: '就克隆旧站 https://example.com（老树天空）' },
    ],
  }
  assert.deepEqual(parseQuestionAnswer(q, 'https://www.mpyit.com/'), {
    id: 'tpl', selected: [], custom: 'https://www.mpyit.com/',
  })
  assert.deepEqual(parseQuestionAnswer(q, 'https://demo.example.com/x 就用这个'), {
    id: 'tpl', selected: [], custom: 'https://demo.example.com/x 就用这个',
  })
  assert.deepEqual(parseQuestionAnswer(q, '就克隆旧站 https://example.com（老树天空）'), {
    id: 'tpl', selected: ['就克隆旧站 https://example.com（老树天空）'],
  })
  assert.deepEqual(parseQuestionAnswer(q, '9'), { id: 'tpl', selected: [], custom: '9' })
})

test('decideTextRoute: 超时只提示，不静默新建', () => {
  const now = 1_700_000_000_000
  const ttl = 900_000                       // 15 分钟
  // 从未有过上文 → 新建
  assert.equal(decideTextRoute({ last: undefined, ttlMs: ttl, now }), 'new')
  // 5 分钟前 + agent 还活着 → 续聊
  assert.equal(decideTextRoute({ last: { sessionId: 's1', at: now - 5 * 60_000 }, ttlMs: ttl, now, hasLiveAgent: true }), 'live')
  // 5 分钟前 + agent 已结束 → 恢复会话
  assert.equal(decideTextRoute({ last: { sessionId: 's1', at: now - 5 * 60_000 }, ttlMs: ttl, now, hasLiveAgent: false }), 'resume')
  // 20 分钟前 → 超时（即便 agent 还在跑，也提示而不续接）
  assert.equal(decideTextRoute({ last: { sessionId: 's1', at: now - 20 * 60_000 }, ttlMs: ttl, now, hasLiveAgent: true }), 'expired')
  // 显式 expired 标记（lastRouteOf 已判定过期）
  assert.equal(decideTextRoute({ last: { sessionId: 's1', at: now - 60_000, expired: true }, ttlMs: ttl, now, hasLiveAgent: true }), 'expired')
  // 刚好 15 分钟整 → 仍算有效
  assert.equal(decideTextRoute({ last: { sessionId: 's1', at: now - ttl }, ttlMs: ttl, now, hasLiveAgent: true }), 'live')
})
