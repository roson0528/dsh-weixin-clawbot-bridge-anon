# DSH ↔ 微信 ClawBot 桥接插件（weixin-bridge）

> DeepSeek Harness（DSH）官方微信接入插件，基于微信 ClawBot（iLink 协议）。
> 无需公网入站端口、无需域名映射——iLink 采用**出站长轮询**。
>
> 适用仓库目录：`~/apps/weixin-clawbot-bridge/`
> 生产部署位置：`~/.dsh/profiles/web/`（DSH profile 插件目录）

---

## 一、功能一览

| # | 功能 | 说明 |
|---|------|------|
| 1 | **任务失败自动恢复（智能分级）** | 监控所有运行任务，检测到"本轮运行失败"自动补发「继续」。瞬时错误（5xx/超时/限流）按指数退避重试；确定性错误（参数/鉴权）直接告警不空转；连续失败超 `maxAutoRetries` 次停止并微信告警 |
| 2 | **交互选择转发** | 任务调用 `ask_user_question` 需要确认/选择时，把问题与选项转发微信，回复序号即选择。默认只接管微信发起的任务，网页任务不受影响（`interceptAllSessions` 可放开） |
| 3 | **微信 → DSH 指令** | 新任务 / 续聊（10 分钟 TTL）/ 状态 / 任务列表 / 停止 / 跳过 / 重载 / 失败测试 |
| 4 | **任务完成通知 + 完成报告** | 完成后推送「项目」中的「任务」已经完成，并附该轮最终报告（交付清单/验证情况等，长文本自动分段；与已回推内容相同时自动去重） |
| 5 | **指定任务操作** | 「在「任务名」中执行：指令」或稳定编号「05# 指令」或「在 2 号任务中执行：指令」，agent 已结束则自动恢复会话 |
| 6 | **例行内容自动注入** 🆕 | 新建会话时自动把可配置的例行交代（服务器密码、存储路径等）注入到指令前，省去每次重复输入；恢复会话时也可注入 |
| 7 | **网页配置端** 🆕 | `http://<server-ip>:19998/?token=…` 可视化编辑例行内容与运行参数，保存即热生效（需 `statusHost: 0.0.0.0`，支持令牌鉴权） |

---

## 二、文件清单

| 文件 | 说明 |
|------|------|
| `weixin-bridge.mjs` | 插件主体：失败监控、交互转发、微信指令、完成通知、例行内容注入、网页配置端 |
| `weixin-bridge-lib.mjs` | 纯函数库（无 DSH 依赖）：长文分段、问题渲染、答案解析、指令解析、错误分级、退避计算——便于单测 |
| `weixin-bridge-lib.test.mjs` | node:test 单元测试（29 例） |
| `ilink-client.mjs` | iLink 协议客户端（零外部依赖，仅用 `node:` 内置模块） |
| `cordis.patch.yml.example` | DSH profile 注册配置示例 |
| `install.sh` | 一键安装（`--no-restart` / `--with-nginx`） |
| `README.md` | 本使用说明 |
| `技术备档.md` | 架构、协议、关键实现与调试记录 |

---

## 三、安装与部署

### 方式 A：一键脚本（推荐）

```bash
cd ~/apps/weixin-clawbot-bridge/
chmod +x install.sh
./install.sh                  # 复制 + 重启
# 可选：./install.sh --with-nginx   # 自动配置 nginx /weixin-qr 静态路由
```

脚本执行内容：

1. 复制 `weixin-bridge.mjs`、`weixin-bridge-lib.mjs`、`ilink-client.mjs` 到 `~/.dsh/profiles/web/`
2. 若目标 `cordis.patch.yml` 不存在，复制示例配置（**不覆盖已有配置**）
3. 重启 dsh-web（需 sudo）；`--with-nginx` 额外写入 `/etc/nginx/conf.d/dsh-weixin-qr.conf`

### 方式 B：手动部署

```bash
cp weixin-bridge.mjs weixin-bridge-lib.mjs ilink-client.mjs ~/.dsh/profiles/web/
cp cordis.patch.yml.example ~/.dsh/profiles/web/cordis.patch.yml   # 首次
sudo systemctl restart dsh-web
```

### 配置项

`cordis.patch.yml` 提供静态配置；**运行参数优先推荐在网页配置端修改**（保存到 `~/.dsh/weixin/config.json`，热生效）。两者字段一致，config.json 覆盖 cordis 同名项。

```yaml
- insert:
    - id: weixin-bridge
      name: ./weixin-bridge.mjs
      config:
        continueText: 继续          # 自动恢复时补发的指令文本
        maxAutoRetries: 3           # 连续瞬时失败超过 3 次停止重试并告警
        retryDelayMs: 8000          # 首次重试延迟（毫秒），之后指数退避
        retryBackoffMaxMs: 120000   # 退避上限
        askTimeoutMs: 900000        # 交互等待超时（15 分钟），超时回退网页端
        resumeTtlMs: 600000         # 「续聊最近会话」有效期（10 分钟）
        notifyOnRecovery: true      # 恢复尝试时微信通知（🔁 n/3）
        workspacePath: /home/<user>  # 任务工作目录
        agentPreset: standard       # DSH agent 预设
        permissionPreset: workspace-write
        stateDir: ''                # 状态目录（默认 ~/.dsh/weixin）
        sessionsDir: ''             # 会话目录（默认自动推导）
        enableFailureTest: false    # 生产关闭；true 后微信发「测试失败」可验证告警链路
        interceptAllSessions: false # true = 也接管网页任务的问题
        sessionBriefing: ''         # 例行交代内容（多行文本），新建会话自动注入
        briefingOnResume: true      # 恢复会话时是否也注入例行内容
        alwaysSendReport: true      # 完成后总是再发一次完整报告（即使与过程回推相同）
        statusPort: 19998           # 配置/状态端口（0 = 关闭）
        statusHost: 127.0.0.1       # 监听地址（局域网访问设 0.0.0.0，重启生效）
        configToken: ''             # 配置/状态端点访问令牌（局域网访问强烈建议设置，重启或热重载生效）
        maxLogBytes: 1000000        # bridge.log 单文件上限（自动轮转 3 份）
```

---

## 四、网页配置端 🆕

插件内置极简配置页。默认监听 `127.0.0.1`；把 `statusHost` 设为 `0.0.0.0` 后即可局域网访问（**务必设置 `configToken` 令牌**，否则配置页裸奔）：

| 端点 | 说明 |
|------|------|
| `GET http://<服务器IP>:19998/?token=…` | 配置表单：例行交代内容、重试次数/间隔、交互超时、续聊有效期、开关项、访问令牌 |
| `GET /weixin-status?token=…` | 运行状态 JSON（登录态/任务/待答交互/最近错误/配置） |
| `GET /config.json?token=…` | 当前生效配置 JSON（不含令牌） |
| `POST /config` | 保存表单到 `config.json` 并立即热生效（body 需带 `token` 字段） |

**局域网直接访问：**

```
http://<server-ip>:19998/?token=dsh-xxxxxxxx
```

**本机 / SSH 隧道访问：**

```bash
ssh -L 19998:127.0.0.1:19998 user@<server-ip>
# 浏览器打开 http://127.0.0.1:19998/（statusHost=127.0.0.1 且 configToken 为空时无需 token）
```

**例行内容示例**（写入「例行交代内容」文本框）：

```
服务器 SSH 密码：<SSH密码>
常用存储路径：/home/<user>
验证方式：完成后给出交付清单与验证结果
```

保存后，之后每一条微信新任务都会自动变成：`例行内容` + `你的指令`，一并交给 Agent。

> `statusPort` / `statusHost` 修改需重启生效；`configToken` 与其余项保存即热生效。

---

## 五、微信指令表

| 你发的 | 插件行为 |
|--------|---------|
| 任意文字（无待确认交互） | 续聊最近会话（10 分钟内）；否则新建任务 |
| `新任务：指令` | 强制新建任务（不续聊） |
| 数字/序号（有待确认交互） | 作为交互答案提交，任务继续 |
| `任务` 或 `/tasks` | 列出任务（稳定编号 + 标题 + 状态 + 更新时间） |
| `任务编号` 或 `/sessions` | 列出全部任务编号（含历史，不限数量；`会话编号`/`编号` 亦可用） |
| `05# 指令` | 按稳定编号给会话下达指令（如 `03# 测试运行`） |
| `05#插话 指令` | 打断当前 turn 立即插入这条指令（不等当前步骤结束）；任务未运行时自动按普通指令发送 |
| `05#状态` | 查看**该任务的运行状态**：本轮开始/首次开始时间、本次指令运行时长、该指令的中间过程消息及时间、当前状态（运行中/空闲/等待确认/已停止）。注意与全局 `状态`（整机概况）区分 |
| `05#跟踪` | 开启该任务的**中间过程推送**（即使全局 `pushProgress` 关闭），用于单独跟踪某个任务 |
| `05#关闭跟踪` | 停止该任务的过程推送，恢复只推重要信息 |
| `在「任务名」中执行：指令` | 按标题/首条消息匹配已有任务并执行 |
| `在 2 号任务中执行：指令` / `#2 指令` | 按任务列表序号执行 |
| `03#停止` | 终止该编号的任务（也可用 `停止`、`停止 2`、`停止 03#`、`取消`） |
| `允许` / `拒绝` | 答复**审批请求**（沙箱提权、危险操作等）；也接受 `允许一次`、`同意`、`不允许`、`no` |
| `跳过` | 放弃当前待确认交互，交回网页端 |
| `状态` 或 `/status` | 运行状态（登录/运行时长/任务/待答交互/最近错误） |
| `重置` 或 `/reset` | 清零所有失败计数 |
| `继续` | 给所有失败过的任务补发「继续」 |
| `重载` 或 `/reload` | 重新读取 config.json |
| `帮助` 或 `/help` | 显示指令说明 |
| `测试失败` | 受控失败测试（需 `enableFailureTest: true`） |

---

## 六、首次接入（扫码）

1. 部署并重启后，插件自动发起 iLink 扫码登录
2. 登录二维码写入 `~/.dsh/weixin/qr.png`，局域网访问：
   `http://<服务器IP>:23600/weixin-qr`（`install.sh --with-nginx` 自动配置；否则 nginx 手动指向该文件）
3. 用微信扫码（**个人微信**即可，非公众号）
4. 扫码后 **先给 Bot 发一条消息**——iLink 需要 context_token 才能主动外发消息

状态文件：`~/.dsh/weixin/weixin_state.json`（bot_token、用户、context_tokens）——**勿删，删了要重新扫码**。

---

## 七、日志

| 位置 | 说明 |
|------|------|
| `~/.dsh/weixin/bridge.log` | 插件运行日志（按 1MB × 3 份自动轮转） |
| `~/.dsh/weixin/status.json` | 运行状态快照（每 30 秒刷新） |
| `~/.dsh/weixin/config.json` | 网页配置端保存的运行参数（热生效） |
| `~/.dsh/weixin/asks.json` | 待答交互持久化（重启后提示恢复） |
| `journalctl -u dsh-web` | dsh-web 服务日志（含插件 stderr） |

---

## 八、常见问题

**Q：微信 Bot 收不到主动通知？**
A：需先给 Bot 发过至少一条消息（iLink context_token 机制）。

**Q：任务全部"本轮运行失败"？**
A：多为模型上游 502（瞬时错误），插件会自动指数退避重试并告警；确定性错误（参数/鉴权）会直接告警不空转。

**Q：dsh-web 重启后要重新扫码吗？**
A：不需要。登录态持久化在 `weixin_state.json`；重启导致的未答复交互会微信提示并给出恢复方法。

**Q：恢复旧会话时弹出残留交互？**
A：可回复「跳过」交回网页端，或新建任务（`新任务：`前缀）。

**Q：例行内容没生效？**
A：确认配置页已保存（`config.json` 存在且 `sessionBriefing` 非空），或微信发「重载」后再试。

---

## 九、卸载

```bash
# 1. 从 cordis.patch.yml 移除 weixin-bridge 的 insert 段
# 2. 删除插件文件
rm ~/.dsh/profiles/web/weixin-bridge.mjs ~/.dsh/profiles/web/weixin-bridge-lib.mjs ~/.dsh/profiles/web/ilink-client.mjs
# 3. 重启
sudo systemctl restart dsh-web
# 4. （可选）删除状态与日志
rm -rf ~/.dsh/weixin
```

---

*更多技术细节见同目录《技术备档.md》。*

## 通知可靠性

推送失败（iLink `ret=-2 prepare failed`、context_token 过期、无已知用户等）的消息会自动重试 3 次（1s/2s 退避），仍失败则落盘到 `outbox.json`；链路恢复后每 5 秒自动补发，用户再给 Bot 发消息时立即补发。完成通知与完成报告之间保留 1.5s 间隔、长报告分段间 0.7s 间隔，避免被 iLink 连续发送限流。

## 双通道（网页端 + 微信）

交互提问（ask_user_question）采用双通道：网页端提问框照常弹出，同时转发微信；任一渠道先回答即生效。其余推送（过程回推、完成通知、完成报告、失败告警、状态）均为只读旁路，不影响网页端任何展示。

微信下发的指令以 `source: { kind: 'user' }` 注入会话，网页端会作为**用户消息气泡正常显示**（与网页端直接输入一致，含自动注入的例行内容）。插件自动补发的「继续」仍标记为插件注入，不伪装成用户输入。

### 例行内容的注入时机

`sessionBriefing` 只在该会话的**首条指令**时附带注入一次，之后同会话的指令不再重复附加。已注入的会话记录在 `briefed_sessions.json`（跨重启有效）。新建会话首条指令始终附带；`briefingOnResume` 控制接管/恢复历史会话时是否补一次（每个会话仍只注入一次）。

| `pushProgress` | 推送中间过程消息。默认 `false`（只发交互提问、异常/失败告警、完成通知与完成报告）；如需逐条回推 AI 输出设为 `true` |
