/**
 * iLink (微信 ClawBot) HTTP 客户端 —— 无外部依赖，仅用 node: 内置模块。
 *
 * 协议基线：@tencent-weixin/openclaw-weixin 2.4.6
 * 入口域名：https://ilinkai.weixin.qq.com
 *
 * 设计要点：
 *  - 出站长轮询（getupdates），不需要任何公网入站端口或域名
 *  - 扫码登录后把 bot_token / baseurl 持久化，重启自动复用
 *  - ret=-14 表示 token 失效，进入受控重新扫码
 */

import fs from 'node:fs'
import path from 'node:path'
import { randomUUID, randomBytes, createHash } from 'node:crypto'

const FIXED_ENTRY = 'https://ilinkai.weixin.qq.com'
const CHANNEL_VERSION = '2.4.6'
const CLIENT_VERSION = String((2 << 16) | (4 << 8) | 6) // 132102
const BOT_AGENT = 'dsh-weixin-bridge/1.0.0 (node)'
const QR_TIMEOUT_MS = 480_000
const QR_TTL_MS = 300_000
const MAX_QR_REFRESH = 3
const LONGPOLL_DEFAULT_MS = 35_000

function uin() {
  // 随机 uint32 -> 十进制字符串 -> base64
  return Buffer.from(String(randomBytes(4).readUInt32BE(0))).toString('base64')
}

function baseInfo() {
  return { channel_version: CHANNEL_VERSION, bot_agent: BOT_AGENT }
}

function commonHeaders(token) {
  const h = {
    'Content-Type': 'application/json',
    AuthorizationType: 'ilink_bot_token',
    'X-WECHAT-UIN': uin(),
    'iLink-App-Id': 'bot',
    'iLink-App-ClientVersion': CLIENT_VERSION,
  }
  if (token) h.Authorization = `Bearer ${token}`
  return h
}

function appHeaders() {
  return {
    'iLink-App-Id': 'bot',
    'iLink-App-ClientVersion': CLIENT_VERSION,
  }
}

/** 三层成功条件：网络 OK + HTTP 2xx + JSON + ret/errcode 为 0 */
class ILinkError extends Error {
  constructor(message, { ret, errcode, status } = {}) {
    super(message)
    this.name = 'ILinkError'
    this.ret = ret
    this.errcode = errcode
    this.status = status
  }
  get isTokenExpired() {
    return this.ret === -14 || this.errcode === -14
  }
}

async function request(url, { method = 'POST', headers, body, timeoutMs = 40_000, signal } = {}) {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(new Error('timeout')), timeoutMs)
  if (signal) signal.addEventListener('abort', () => ctrl.abort(signal.reason), { once: true })
  let res
  try {
    res = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctrl.signal,
    })
  } finally {
    clearTimeout(timer)
  }
  const text = await res.text()
  let json
  try {
    json = text === '' ? {} : JSON.parse(text)
  } catch {
    throw new ILinkError(`非 JSON 响应 (HTTP ${res.status})`, { status: res.status })
  }
  if (!res.ok) throw new ILinkError(`HTTP ${res.status}: ${text.slice(0, 200)}`, { status: res.status })
  const ret = json.ret
  const errcode = json.errcode
  if ((ret !== undefined && ret !== 0) || (errcode !== undefined && errcode !== 0)) {
    throw new ILinkError(`业务错误 ret=${ret} errcode=${errcode} ${json.errmsg ?? ''}`.trim(), { ret, errcode, status: res.status })
  }
  return json
}

export class ILinkClient {
  #stateDir
  #stateFile
  #state
  #log
  #onQR
  #onVerifyCode
  #typingTickets = new Map()
  #contextTokens = new Map()
  #stopped = false
  #pollBuf = ''

  constructor({ stateDir, logger, onQRCode, onVerifyCode } = {}) {
    this.#stateDir = stateDir
    this.#stateFile = path.join(stateDir, 'weixin_state.json')
    this.#log = logger ?? console
    this.#onQR = onQRCode
    this.#onVerifyCode = onVerifyCode
    this.#state = this.#load()
  }

  #load() {
    try {
      const raw = fs.readFileSync(this.#stateFile, 'utf8')
      const doc = JSON.parse(raw)
      if (doc && typeof doc.bot_token === 'string' && typeof doc.baseurl === 'string') {
        // 恢复持久化的用户 context_token 到内存 Map
        if (doc.context_tokens && typeof doc.context_tokens === 'object') {
          for (const [uid, tok] of Object.entries(doc.context_tokens)) {
            if (typeof tok === 'string' && tok !== '') this.#contextTokens.set(uid, tok)
          }
        }
        return doc
      }
    } catch { /* 首次运行 */ }
    return { bot_token: '', baseurl: '', ilink_bot_id: '', ilink_user_id: '', get_updates_buf: '', context_tokens: {}, updated_at: '' }
  }

  #save() {
    fs.mkdirSync(this.#stateDir, { recursive: true, mode: 0o700 })
    this.#state.updated_at = new Date().toISOString()
    this.#state.context_tokens = Object.fromEntries(this.#contextTokens)
    const tmp = `${this.#stateFile}.tmp`
    fs.writeFileSync(tmp, JSON.stringify(this.#state, null, 2), { mode: 0o600 })
    fs.renameSync(tmp, this.#stateFile)
  }

  get loggedIn() { return this.#state.bot_token !== '' && this.#state.baseurl !== '' }

  /** 清除失效的登录态（token 过期时调用），保留用户上下文以便重新绑定 */
  reset() {
    this.#state.bot_token = ''
    this.#state.baseurl = ''
    this.#state.ilink_bot_id = ''
    this.#state.get_updates_buf = ''
    this.#typingTickets.clear()
    this.#save()
    this.#log.warn?.('[weixin] 本地登录态已清除')
  }
  get baseurl() { return this.#state.baseurl || FIXED_ENTRY }
  get botId() { return this.#state.ilink_bot_id }

  /** 已知用户 ID（用于主动推送通知） */
  knownUsers() { return [...this.#contextTokens.keys()] }

  // ── 登录 ────────────────────────────────────────────────
  async login({ signal } = {}) {
    let refresh = 0
    let verifyCode
    let qrcode
    let qrAt = 0
    let pollHost = FIXED_ENTRY

    const newQR = async () => {
      if (refresh++ > MAX_QR_REFRESH) throw new ILinkError('二维码刷新次数超限，请重新执行登录')
      const localTokens = this.#state.bot_token ? [this.#state.bot_token] : []
      const json = await request(`${FIXED_ENTRY}/ilink/bot/get_bot_qrcode?bot_type=3`, {
        headers: commonHeaders(null),
        body: { local_token_list: localTokens },
        signal,
      })
      qrcode = json.qrcode
      qrAt = Date.now()
      verifyCode = undefined
      pollHost = FIXED_ENTRY
      if (this.#onQR) await this.#onQR({ qrcode, img: json.qrcode_img_content, url: json.qrcode_img_content })
      this.#log.info?.(`[weixin] 二维码已生成: ${json.qrcode_img_content}`)
    }

    await newQR()
    const deadline = Date.now() + QR_TIMEOUT_MS

    while (Date.now() < deadline) {
      if (signal?.aborted) throw new ILinkError('登录已取消')
      if (Date.now() - qrAt > QR_TTL_MS) { await newQR(); continue }

      const qs = new URLSearchParams({ qrcode })
      if (verifyCode) qs.set('verify_code', verifyCode)
      let status
      try {
        status = await request(`${pollHost}/ilink/bot/get_qrcode_status?${qs}`, {
          method: 'GET', headers: appHeaders(), timeoutMs: 40_000, signal,
        })
      } catch (e) {
        // 网络超时/524 按 wait 处理
        if (e instanceof ILinkError && (e.status === 524 || /timeout/i.test(e.message))) continue
        throw e
      }

      switch (status.status) {
        case 'wait': break
        case 'scaned':
          this.#log.info?.('[weixin] 已扫码，请在手机上确认')
          verifyCode = undefined
          break
        case 'need_verifycode': {
          // 需要手机端配对码：由调用方提供（终端交互或网页输入）
          const code = this.#onVerifyCode ? await this.#onVerifyCode() : undefined
          if (code) verifyCode = String(code)
          else this.#log.warn?.('[weixin] 手机要求配对码，但未提供输入通道')
          break
        }
        case 'verify_code_blocked':
          this.#log.warn?.('[weixin] 配对码多次错误，刷新二维码')
          verifyCode = undefined
          await newQR()
          break
        case 'scaned_but_redirect':
          if (status.redirect_host) pollHost = `https://${status.redirect_host}`
          break
        case 'binded_redirect':
          if (this.loggedIn) { this.#log.info?.('[weixin] 账号已绑定，复用本地 token'); return this.#state }
          await newQR()
          break
        case 'expired':
          await newQR()
          break
        case 'confirmed': {
          if (!status.ilink_bot_id) throw new ILinkError('登录确认缺少 ilink_bot_id')
          if (!status.bot_token) throw new ILinkError('登录确认缺少 bot_token')
          this.#state.bot_token = status.bot_token
          this.#state.baseurl = status.baseurl || FIXED_ENTRY
          this.#state.ilink_bot_id = status.ilink_bot_id
          this.#state.ilink_user_id = status.ilink_user_id ?? ''
          this.#save()
          this.#log.info?.(`[weixin] 登录成功 bot=${status.ilink_bot_id}`)
          return this.#state
        }
        default:
          this.#log.warn?.(`[weixin] 未知扫码状态: ${status.status}`)
      }
    }
    throw new ILinkError('扫码登录超时')
  }

  async notifyStart() {
    try { await request(`${this.baseurl}/ilink/bot/msg/notifystart`, { headers: commonHeaders(this.#state.bot_token), body: { base_info: baseInfo() }, timeoutMs: 10_000 }) }
    catch (e) { this.#log.warn?.(`[weixin] notifystart 失败: ${e.message}`) }
  }

  async notifyStop() {
    try { await request(`${this.baseurl}/ilink/bot/msg/notifystop`, { headers: commonHeaders(this.#state.bot_token), body: { base_info: baseInfo() }, timeoutMs: 5_000 }) }
    catch (e) { this.#log.warn?.(`[weixin] notifystop 失败: ${e.message}`) }
  }

  // ── 收消息（长轮询） ────────────────────────────────────
  /**
   * 持续长轮询。onMessage({ fromUserId, text, contextToken, raw }) 返回 Promise。
   * token 失效时抛出 ILinkError(isTokenExpired)。
   */
  async poll(onMessage, { signal } = {}) {
    let backoff = 1_000
    let timeout = LONGPOLL_DEFAULT_MS
    this.#pollBuf = this.#state.get_updates_buf || ''

    while (!this.#stopped && !signal?.aborted) {
      let res
      try {
        res = await request(`${this.baseurl}/ilink/bot/getupdates`, {
          headers: commonHeaders(this.#state.bot_token),
          body: { get_updates_buf: this.#pollBuf, base_info: baseInfo() },
          timeoutMs: timeout + 10_000,
          signal,
        })
        backoff = 1_000
      } catch (e) {
        if (signal?.aborted) return
        if (e instanceof ILinkError && e.isTokenExpired) throw e
        // 客户端超时属正常控制流：保留游标继续
        if (e?.name === 'AbortError' || /timeout/i.test(e?.message ?? '')) continue
        this.#log.warn?.(`[weixin] getupdates 失败，${backoff}ms 后重试: ${e?.message}`)
        await sleep(backoff)
        backoff = Math.min(backoff * 2, 60_000)
        continue
      }

      if (typeof res.longpolling_timeout_ms === 'number' && res.longpolling_timeout_ms > 0) {
        timeout = res.longpolling_timeout_ms
      }
      if (typeof res.get_updates_buf === 'string' && res.get_updates_buf !== '') {
        this.#pollBuf = res.get_updates_buf
        this.#state.get_updates_buf = this.#pollBuf
        this.#save()
      }

      for (const msg of res.msgs ?? []) {
        const parsed = parseInbound(msg)
        if (!parsed) continue
        if (parsed.contextToken) this.#contextTokens.set(parsed.fromUserId, parsed.contextToken)
        try {
          await onMessage(parsed)
        } catch (e) {
          this.#log.warn?.(`[weixin] 处理消息失败: ${e?.message}`)
        }
      }
    }
  }

  stop() { this.#stopped = true }

  // ── 发消息 ──────────────────────────────────────────────
  async #typingTicket(userId, contextToken) {
    const cached = this.#typingTickets.get(userId)
    if (cached) return cached
    const json = await request(`${this.baseurl}/ilink/bot/getconfig`, {
      headers: commonHeaders(this.#state.bot_token),
      body: { ilink_user_id: userId, context_token: contextToken ?? '', base_info: baseInfo() },
    })
    const ticket = json.typing_ticket
    if (ticket) this.#typingTickets.set(userId, ticket)
    return ticket
  }

  async sendTyping(userId, status, contextToken) {
    try {
      const ticket = await this.#typingTicket(userId, contextToken)
      if (!ticket) return
      await request(`${this.baseurl}/ilink/bot/sendtyping`, {
        headers: commonHeaders(this.#state.bot_token),
        body: { ilink_user_id: userId, typing_ticket: ticket, status, base_info: baseInfo() },
        timeoutMs: 10_000,
      })
    } catch (e) {
      this.#log.warn?.(`[weixin] sendtyping 失败: ${e.message}`)
    }
  }

  /**
   * 发送文本。userId 可省略 —— 省略时发给所有已知用户（主动通知场景）。
   * @returns {Promise<number>} 成功发送的用户数
   */
  async sendText(text, { userId, contextToken } = {}) {
    const targets = userId ? [userId] : this.knownUsers()
    // 换行兼容：微信手机端认 \n，电脑端只认 U+2028，故两个一起写（实测 A~E 各组合两端均正常分行）
    const wire = String(text).replace(/\r\n/g, '\n').replace(/\r/g, '\n').replace(/\n/g, '\n\u2028')
    let sent = 0
    for (const uid of targets) {
      const ctxToken = contextToken ?? this.#contextTokens.get(uid) ?? ''
      try {
        await request(`${this.baseurl}/ilink/bot/sendmessage`, {
          headers: commonHeaders(this.#state.bot_token),
          body: {
            msg: {
              from_user_id: '',
              to_user_id: uid,
              client_id: `dsh-weixin-${randomUUID()}`,
              message_type: 2,
              message_state: 2,
              context_token: ctxToken,
              item_list: [{ type: 1, text_item: { text: wire } }],
            },
            base_info: baseInfo(),
          },
          timeoutMs: 20_000,
        })
        sent++
        this.#log.info?.(`[weixin] sendmessage -> ${uid} 成功: ${text.slice(0, 60).replace(/\n/g, ' ')}`)
      } catch (e) {
        if (e instanceof ILinkError && e.isTokenExpired) throw e
        this.#log.warn?.(`[weixin] sendmessage -> ${uid} 失败: ${e.message}`)
      }
    }
    return sent
  }
}

function parseInbound(msg) {
  if (!msg || typeof msg !== 'object') return null
  if (msg.message_type !== 1) return null // 只处理用户消息
  const items = Array.isArray(msg.item_list) ? msg.item_list : []
  const text = items.filter(i => i?.type === 1 && typeof i.text_item?.text === 'string')
    .map(i => i.text_item.text).join('\n').trim()
  if (text === '') return null
  return {
    fromUserId: msg.from_user_id,
    contextToken: msg.context_token,
    messageId: msg.message_id === undefined ? '' : String(msg.message_id),
    text,
    raw: msg,
  }
}

const sleep = ms => new Promise(r => setTimeout(r, ms))
export { ILinkError, sleep }
