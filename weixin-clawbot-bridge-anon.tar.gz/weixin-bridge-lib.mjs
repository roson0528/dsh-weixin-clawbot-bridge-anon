/**
 * weixin-bridge 纯函数库（不依赖 DSH 运行时，便于单元测试）
 *
 * 被 weixin-bridge.mjs 与 weixin-bridge-lib.test.mjs 共用。
 */

/** 长文本分段：优先在换行处积聚到接近上限，超长行硬切。每段长度 ≤ limit。 */
export function splitText(text, limit = 1800) {
  const segs = []
  let cur = ''
  const lines = String(text ?? '').split('\n')
  for (const line of lines) {
    if (line.length > limit) {
      if (cur) { segs.push(cur); cur = '' }
      for (let i = 0; i < line.length; i += limit) segs.push(line.slice(i, i + limit))
      continue
    }
    if (cur.length + line.length + 1 > limit) {
      segs.push(cur)
      cur = line
    } else {
      cur = cur ? `${cur}\n${line}` : line
    }
  }
  if (cur) segs.push(cur)
  return segs
}

/** 渲染交互问题为微信文本 */
export function renderQuestion(request, { timeoutMin = 15, title } = {}) {
  const lines = [title || '❓ DSH 需要你的确认', '']
  const questions = Array.isArray(request?.questions) ? request.questions : []
  questions.forEach((q, qi) => {
    lines.push(`${qi + 1}. ${q.header ? `【${q.header}】` : ''}${q.question}`)
    if (q.detail) {
      const d = String(q.detail).split('\n').slice(0, 15).map(l => `   ${l}`).join('\n')
      lines.push(d)
    }
    ;(q.options ?? []).forEach((o, oi) => {
      lines.push(`   ${oi + 1}) ${o.label}${o.description ? ` — ${o.description}` : ''}`)
    })
    if (q.multiSelect) lines.push('   （可多选，回复多个序号用逗号分隔）')
    lines.push('')
  })
  lines.push('回复序号作答；其他文字视为自定义答案。')
  lines.push('回「跳过」交回网页端。')
  lines.push(`（${timeoutMin} 分钟未回复将自动回退网页端）`)
  return lines.join('\n')
}

/** 把用户回复解析成 userQuestions 需要的答案结构 */
export function parseAnswer(request, text) {
  const raw = String(text ?? '').trim()
  const parts = raw.split(/[,，\s、]+/).filter(Boolean)
  const questions = Array.isArray(request?.questions) ? request.questions : []
  const answers = questions.map(q => {
    const opts = q.options ?? []
    if (opts.length === 0) return { id: q.id, selected: [], custom: raw }
    const picked = []
    for (const p of parts) {
      const n = Number(p)
      if (Number.isInteger(n) && n >= 1 && n <= opts.length) picked.push(opts[n - 1].label)
    }
    if (picked.length === 0) return { id: q.id, selected: [], custom: raw }
    return { id: q.id, selected: q.multiSelect ? picked : [picked[0]] }
  })
  return { answers }
}

/** 判断回复是否是"选项序号"（用于交互期间区分答案与命令） */
export function looksLikeOptionReply(text, request) {
  const questions = Array.isArray(request?.questions) ? request.questions : []
  const maxOpts = Math.max(0, ...questions.map(q => (q.options ?? []).length))
  if (maxOpts === 0) return false // 自由文本问题：任何文本都是答案
  const parts = String(text ?? '').trim().split(/[,，\s、]+/).filter(Boolean)
  if (parts.length === 0) return false
  return parts.every(p => {
    const n = Number(p)
    return Number.isInteger(n) && n >= 1 && n <= maxOpts
  })
}

/** 瞬时错误码白名单 */
const TRANSIENT_CODES = new Set([
  'SERVER', 'UPSTREAM', 'UPSTREAM_ERROR', 'RATE_LIMIT', 'RATE_LIMITED',
  'TIMEOUT', 'NETWORK', 'OVERLOADED', 'UNAVAILABLE', 'BAD_GATEWAY', 'GATEWAY_TIMEOUT',
])

/**
 * 错误分级：区分「值得重试的瞬时错误」与「重试也没用的确定性错误」。
 * @returns {{transient: boolean, code: string, message: string, label: string}}
 */
export function classifyError(reason) {
  const err = reason?.error ?? reason ?? {}
  const code = String(err.code ?? reason?.code ?? '')
  const message = String(err.message ?? err.detail ?? reason?.message ?? '未知错误')
  const codeUp = code.toUpperCase()
  const transient = TRANSIENT_CODES.has(codeUp)
    || /\b(429|5\d{2})\b/.test(message)
    || /timeout|timed out|ETIMEDOUT|ECONNRESET|ECONNREFUSED|EPIPE|socket hang up|upstream[_ ]error|temporarily unavailable|rate limit|overloaded|service unavailable/i.test(message)
    || /no adapter registered/i.test(message) // DSH 启动竞态：模型 adapter 尚未注册完成，重试可恢复
  const label = transient ? '瞬时错误' : '确定性错误'
  return { transient, code, message, label }
}

/** 指数退避（含抖动），failures 从 1 开始 */
export function backoffDelay(baseMs, failures, { maxMs = 120_000, jitter = 0.2 } = {}) {
  const exp = Math.min(maxMs, Math.max(1, baseMs) * 2 ** Math.max(0, failures - 1))
  const j = exp * Math.max(0, Math.min(1, jitter))
  return Math.round(exp - j + Math.random() * 2 * j)
}

/** 指令种类（供 parseCommand 返回） */
export const COMMANDS = [
  'status', 'help', 'reset', 'continue', 'tasks', 'skip', 'reload', 'failtest', 'stop', 'sessionids',
]

/**
 * 解析微信指令。
 * @returns {{kind: string, index?: number, number?: number, taskName?: string, instruction?: string, body?: string}}
 *   kind: status|help|reset|continue|tasks|sessionids|skip|reload|failtest|stop|taskStatus|track|interject|inTask|inTaskIndex|stableNumber|newTask|text
 */
export function parseCommand(text) {
  const t = String(text ?? '').trim()
  if (t === '') return { kind: 'text', body: '' }
  const low = t.toLowerCase()

  if (t === '状态' || low === '/status' || low === 'status') return { kind: 'status' }
  if (t === '帮助' || low === '/help' || low === 'help' || t === '?') return { kind: 'help' }
  if (t === '重置' || low === '/reset' || low === 'reset') return { kind: 'reset' }
  if (t === '继续' || t === '继续任务' || low === '/continue' || low === 'continue') return { kind: 'continue' }
  if (t === '任务' || t === '任务列表' || low === '/tasks' || low === 'tasks' || low === 'ls') return { kind: 'tasks' }
  if (t === '任务编号' || t === '编号' || t === '会话编号' || low === '/sessions' || low === 'sessions' || low === '/ids') return { kind: 'sessionids' }
  if (t === '跳过' || low === '/skip' || low === 'skip') return { kind: 'skip' }
  if (t === '重载' || low === '/reload' || low === 'reload') return { kind: 'reload' }
  if (t === '测试失败' || low === '/fail-test' || low === 'failtest') return { kind: 'failtest' }

  const stop = t.match(/^(?:停止|取消|stop|kill)(?:\s*(\d{1,3}))?$/i)
  if (stop) return { kind: 'stop', index: stop[1] ? Number(stop[1]) : undefined }

  const stopByNum = t.match(/^(?:停止|取消|stop|kill)\s*(\d{1,4})#$/i)
  if (stopByNum) return { kind: 'stop', number: Number(stopByNum[1]) }

  const inTask = t.match(/^在[「"'](.+?)[」"']中执行[:：]?\s*([\s\S]+)$/)
  if (inTask) return { kind: 'inTask', taskName: inTask[1].trim(), instruction: inTask[2].trim() }

  // 单任务运行状态：04#状态 / 04#运行状态 / 04#进度（整条消息即为命令）
  const taskStatus = t.match(/^(\d{1,4})#\s*(?:运行状态|状态|进度)\s*$/i)
  if (taskStatus) return { kind: 'taskStatus', number: Number(taskStatus[1]) }

  // 过程跟踪开关：04#跟踪 / 04#关闭跟踪（整条消息即为命令，避免与指令正文冲突）
  const track = t.match(/^(\d{1,4})#\s*(关闭跟踪|取消跟踪|停止跟踪|开启跟踪|跟踪)\s*$/i)
  if (track) {
    const off = /^(关闭|取消|停止)/.test(track[2])
    return { kind: 'track', number: Number(track[1]), on: !off }
  }

  // 停止指定任务：03#停止 / 03# 终止（编号在前；旧的「停止 03#」继续兼容）
  const stopByPrefix = t.match(/^(\d{1,4})#\s*(?:停止|终止|结束|stop|kill)\s*$/i)
  if (stopByPrefix) return { kind: 'stop', number: Number(stopByPrefix[1]) }

  // 插话发送：04#插话 内容 / 04#插话：内容 / 04#插话内容（打断当前 turn 立即插入）
  const interject = t.match(/^(\d{1,4})#\s*(?:插话|插嘴|steer)\s*[:：]?\s*([\s\S]+)$/i)
  if (interject) {
    return { kind: 'interject', number: Number(interject[1]), instruction: interject[2].trim() }
  }

  // 稳定会话编号：05# 指令 / 05#  （数字在前，# 在后；对齐「新建会话分配 01#」的约定）
  const byNumber = t.match(/^(\d{1,4})#\s*([\s\S]*)$/)
  if (byNumber) {
    return { kind: 'stableNumber', number: Number(byNumber[1]), instruction: (byNumber[2] ?? '').trim() }
  }
  const byNumber2 = t.match(/^在\s*(\d{1,4})#\s*中执行[:：]?\s*([\s\S]+)$/)
  if (byNumber2) {
    return { kind: 'stableNumber', number: Number(byNumber2[1]), instruction: byNumber2[2].trim() }
  }

  const inIdx = t.match(/^在\s*(\d{1,3})\s*号任务中执行[:：]?\s*([\s\S]+)$/)
    || t.match(/^#(\d{1,3})\s+([\s\S]+)$/)
  if (inIdx) return { kind: 'inTaskIndex', index: Number(inIdx[1]), instruction: inIdx[2].trim() }

  const newTask = t.match(/^(?:新任务|新建任务)[:：]\s*([\s\S]+)$/)
  if (newTask) return { kind: 'newTask', body: newTask[1].trim() }

  return { kind: 'text', body: t }
}

/** 会话稳定编号格式：01#、12#、100# */
export function sessionNumberTag(n) {
  const num = Number(n)
  if (!Number.isInteger(num) || num <= 0) return ''
  return `${String(num).padStart(2, '0')}#`
}

/** 人类可读的时间差 */
export function humanAge(ms) {
  const s = Math.max(0, Math.round(ms / 1000))
  if (s < 60) return `${s} 秒`
  const m = Math.round(s / 60)
  if (m < 60) return `${m} 分钟`
  const h = Math.round(m / 60)
  if (h < 24) return `${h} 小时`
  return `${Math.round(h / 24)} 天`
}

/**
 * 把「例行交代内容」前置注入到用户指令前。
 * 新建/恢复会话时调用，内容可配置（如服务器密码、存储路径）。
 */
export function withBriefing(briefing, prompt, { enabled = true } = {}) {
  if (!enabled) return prompt
  const b = String(briefing ?? '').trim()
  if (b === '') return prompt
  return `${b}\n\n${prompt}`
}

/**
 * 渲染审批请求（沙箱提权、危险操作等）为微信消息。
 * @param {{toolName?: string, reason?: string, timeoutMin?: number, title?: string}} opts
 * @returns {string}
 */
export function renderApproval({ toolName = '', reason = '', timeoutMin = 15, title } = {}) {
  const lines = [title || '🔐 DSH 等待审批', '']
  if (toolName) lines.push(`操作：${toolName}`)
  if (reason) lines.push(`原因：${String(reason).slice(0, 400)}`)
  lines.push('')
  lines.push('回复「允许」或「拒绝」')
  lines.push('回「跳过」交回网页端')
  lines.push(`（${timeoutMin} 分钟未回复将回到网页端）`)
  return lines.join('\n')
}

/**
 * 解析审批回复。
 * @param {string} text - 用户回复
 * @returns {'allowed-once'|'rejected'|'skip'|''} 空串表示不是审批答复
 */
export function parseApprovalReply(text) {
  const t = String(text ?? '').trim().toLowerCase()
  if (t === '') return ''
  if (/^(跳过|skip)$/.test(t)) return 'skip'
  if (/^(允许|同意|批准|可以|确认|确定|好的|行|ok|okay|yes|y|allow|allowed)$/.test(t)) return 'allowed-once'
  if (/^允许(一次|本次|这条|当前)$/.test(t)) return 'allowed-once'
  if (/^(拒绝|不允许|不同意|不行|否|不用|no|n|deny|denied|reject|rejected)$/.test(t)) return 'rejected'
  return ''
}

/**
 * 渲染单个问题（多问题交互时逐个推送，便于针对性回答）。
 * @param {any} question - 单条 question（{ id, header?, question, detail?, options?, multiSelect? }）
 * @param {{index?: number, total?: number, title?: string, timeoutMin?: number}} opts
 * @returns {string}
 */
export function renderQuestionStep(question, { index = 1, total = 1, title, timeoutMin = 15 } = {}) {
  const q = question ?? {}
  const opts = Array.isArray(q.options) ? q.options : []
  const lines = [title || '❓ DSH 需要你的确认', '']
  if (total > 1) lines.push(`第 ${index}/${total} 题`)
  lines.push(`${q.header ? `【${q.header}】` : ''}${q.question ?? ''}`)
  if (q.detail) {
    const d = String(q.detail).split('\n').slice(0, 15).map(l => `   ${l}`).join('\n')
    lines.push(d)
  }
  opts.forEach((o, oi) => {
    lines.push(`${oi + 1}) ${o.label}${o.description ? ` — ${o.description}` : ''}`)
  })
  if (q.multiSelect) lines.push('（可多选，用逗号分隔序号）')
  lines.push('')
  lines.push(opts.length ? `回复序号作答（1-${opts.length}）；其他文字视为自定义答案。` : '回复你的答案（文字）。')
  lines.push('回「跳过」交回网页端。')
  lines.push(`（${timeoutMin} 分钟未回复将回退网页端）`)
  return lines.join('\n')
}

/**
 * 解析单个问题的答复（用于逐题作答）。
 * 支持三种形式：① 纯序号（含多选 `1,3`）② 选项 label 原文 ③ 其它任意文字 → 自定义答案。
 */
export function parseQuestionAnswer(question, text) {
  const raw = String(text ?? '').trim()
  const opts = Array.isArray(question?.options) ? question.options : []
  const id = question?.id
  if (opts.length === 0) return { id, selected: [], custom: raw }

  // ① 纯序号（可多选，逗号/空格/顿号分隔）
  const parts = raw.split(/[,，\s、]+/).filter(Boolean)
  const allNumeric = parts.length > 0 && parts.every(p => /^\d+$/.test(p))
  if (allNumeric) {
    const nums = parts.map(Number).filter(n => n >= 1 && n <= opts.length)
    if (nums.length > 0) {
      const labels = nums.map(n => opts[n - 1].label)
      return { id, selected: question?.multiSelect ? labels : [labels[0]] }
    }
    // 序号全部越界：按自定义文字处理（下方兜底）
  }

  // ② 整条等于某个选项 label（或用户回的是 label 的明确前缀，长度 ≥3）
  const norm = (v) => String(v ?? '').trim().replace(/\s+/g, ' ')
  const hit = opts.find(o => norm(o.label) === norm(raw))
    || opts.find(o => norm(raw).length >= 3 && norm(o.label).startsWith(norm(raw)))
  if (hit) return { id, selected: [hit.label] }

  // ③ 其它任意文字 → 自定义答案（如直接贴网址）
  return { id, selected: [], custom: raw }
}

/**
 * 判断回复是否可作为当前题的答案。
 * - 空回复 → false（继续等待）
 * - 自由文本题 → 任何非空文字都是答案
 * - 选择题 → 序号合法即合法；**非数字的自定义文字同样接受**（如直接贴网址）；
 *   仅当回复是纯数字但全部越界（如「9」而只有 3 个选项）时判为无效，提示重新作答
 */
export function looksLikeStepReply(text, question) {
  const t = String(text ?? '').trim()
  if (t === '') return false
  const opts = Array.isArray(question?.options) ? question.options : []
  if (opts.length === 0) return true
  const parts = t.split(/[,，\s、]+/).filter(Boolean)
  if (parts.length === 0) return false
  const allNumeric = parts.every(p => /^\d+$/.test(p))
  if (!allNumeric) return true          // 含非数字内容 → 视为自定义答案
  return parts.every(p => {
    const n = Number(p)
    return Number.isInteger(n) && n >= 1 && n <= opts.length
  })
}

/**
 * 普通文字指令的路由决策（纯函数，便于测试）。
 * - `new`     ：没有上文（首次使用）→ 新建任务
 * - `live`    ：上文有效且 agent 还活着 → 直接续聊
 * - `resume`  ：上文有效但 agent 已结束 → 恢复该会话继续
 * - `expired` ：上文已超时 → 只提示「已经超时」，不新建、不续接
 * @param {{last?: {sessionId?: string, at?: number, expired?: boolean}, ttlMs?: number, now?: number, hasLiveAgent?: boolean}} opts
 * @returns {'new'|'live'|'resume'|'expired'}
 */
export function decideTextRoute({ last, ttlMs = 900_000, now = Date.now(), hasLiveAgent = false } = {}) {
  if (!last?.sessionId) return 'new'
  const age = now - Number(last.at ?? 0)
  const ttl = Number(ttlMs) > 0 ? Number(ttlMs) : 900_000
  if (last.expired || !(age <= ttl)) return 'expired'
  return hasLiveAgent ? 'live' : 'resume'
}
